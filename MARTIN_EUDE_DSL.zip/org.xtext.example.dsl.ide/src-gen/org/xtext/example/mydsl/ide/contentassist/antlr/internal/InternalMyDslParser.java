package org.xtext.example.mydsl.ide.contentassist.antlr.internal;

import java.io.InputStream;
import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.AbstractInternalContentAssistParser;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.DFA;
import org.xtext.example.mydsl.services.MyDslGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalMyDslParser extends AbstractInternalContentAssistParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_STRING", "RULE_ID", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'of title'", "'link'", "'image'", "'text'", "'button'", "'input'", "'combobox'", "'title'", "'url'", "'checkbox'", "'all'", "'open browser on url'", "'change url'", "'contains'", "'click'", "'set'", "'check'", "'uncheck'", "'read'", "'count'", "'equals to'", "'var'", "'='", "'call'", "'parameters'", "'function'", "'{'", "'}'", "'name'", "'value'"
    };
    public static final int RULE_STRING=4;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__37=37;
    public static final int T__16=16;
    public static final int T__38=38;
    public static final int T__17=17;
    public static final int T__39=39;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__33=33;
    public static final int T__12=12;
    public static final int T__34=34;
    public static final int T__13=13;
    public static final int T__35=35;
    public static final int T__14=14;
    public static final int T__36=36;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int T__31=31;
    public static final int T__32=32;
    public static final int RULE_ID=5;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=6;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__23=23;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__40=40;
    public static final int T__20=20;
    public static final int T__21=21;

    // delegates
    // delegators


        public InternalMyDslParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalMyDslParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalMyDslParser.tokenNames; }
    public String getGrammarFileName() { return "InternalMyDsl.g"; }


    	private MyDslGrammarAccess grammarAccess;

    	public void setGrammarAccess(MyDslGrammarAccess grammarAccess) {
    		this.grammarAccess = grammarAccess;
    	}

    	@Override
    	protected Grammar getGrammar() {
    		return grammarAccess.getGrammar();
    	}

    	@Override
    	protected String getValueForTokenName(String tokenName) {
    		return tokenName;
    	}



    // $ANTLR start "entryRuleModel"
    // InternalMyDsl.g:53:1: entryRuleModel : ruleModel EOF ;
    public final void entryRuleModel() throws RecognitionException {
        try {
            // InternalMyDsl.g:54:1: ( ruleModel EOF )
            // InternalMyDsl.g:55:1: ruleModel EOF
            {
             before(grammarAccess.getModelRule()); 
            pushFollow(FOLLOW_1);
            ruleModel();

            state._fsp--;

             after(grammarAccess.getModelRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleModel"


    // $ANTLR start "ruleModel"
    // InternalMyDsl.g:62:1: ruleModel : ( ( ( rule__Model__InstructionsAssignment ) ) ( ( rule__Model__InstructionsAssignment )* ) ) ;
    public final void ruleModel() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:66:2: ( ( ( ( rule__Model__InstructionsAssignment ) ) ( ( rule__Model__InstructionsAssignment )* ) ) )
            // InternalMyDsl.g:67:2: ( ( ( rule__Model__InstructionsAssignment ) ) ( ( rule__Model__InstructionsAssignment )* ) )
            {
            // InternalMyDsl.g:67:2: ( ( ( rule__Model__InstructionsAssignment ) ) ( ( rule__Model__InstructionsAssignment )* ) )
            // InternalMyDsl.g:68:3: ( ( rule__Model__InstructionsAssignment ) ) ( ( rule__Model__InstructionsAssignment )* )
            {
            // InternalMyDsl.g:68:3: ( ( rule__Model__InstructionsAssignment ) )
            // InternalMyDsl.g:69:4: ( rule__Model__InstructionsAssignment )
            {
             before(grammarAccess.getModelAccess().getInstructionsAssignment()); 
            // InternalMyDsl.g:70:4: ( rule__Model__InstructionsAssignment )
            // InternalMyDsl.g:70:5: rule__Model__InstructionsAssignment
            {
            pushFollow(FOLLOW_3);
            rule__Model__InstructionsAssignment();

            state._fsp--;


            }

             after(grammarAccess.getModelAccess().getInstructionsAssignment()); 

            }

            // InternalMyDsl.g:73:3: ( ( rule__Model__InstructionsAssignment )* )
            // InternalMyDsl.g:74:4: ( rule__Model__InstructionsAssignment )*
            {
             before(grammarAccess.getModelAccess().getInstructionsAssignment()); 
            // InternalMyDsl.g:75:4: ( rule__Model__InstructionsAssignment )*
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( ((LA1_0>=22 && LA1_0<=32)||LA1_0==34||LA1_0==36) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // InternalMyDsl.g:75:5: rule__Model__InstructionsAssignment
            	    {
            	    pushFollow(FOLLOW_3);
            	    rule__Model__InstructionsAssignment();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);

             after(grammarAccess.getModelAccess().getInstructionsAssignment()); 

            }


            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleModel"


    // $ANTLR start "entryRuleInstruction"
    // InternalMyDsl.g:85:1: entryRuleInstruction : ruleInstruction EOF ;
    public final void entryRuleInstruction() throws RecognitionException {
        try {
            // InternalMyDsl.g:86:1: ( ruleInstruction EOF )
            // InternalMyDsl.g:87:1: ruleInstruction EOF
            {
             before(grammarAccess.getInstructionRule()); 
            pushFollow(FOLLOW_1);
            ruleInstruction();

            state._fsp--;

             after(grammarAccess.getInstructionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleInstruction"


    // $ANTLR start "ruleInstruction"
    // InternalMyDsl.g:94:1: ruleInstruction : ( ( rule__Instruction__Alternatives ) ) ;
    public final void ruleInstruction() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:98:2: ( ( ( rule__Instruction__Alternatives ) ) )
            // InternalMyDsl.g:99:2: ( ( rule__Instruction__Alternatives ) )
            {
            // InternalMyDsl.g:99:2: ( ( rule__Instruction__Alternatives ) )
            // InternalMyDsl.g:100:3: ( rule__Instruction__Alternatives )
            {
             before(grammarAccess.getInstructionAccess().getAlternatives()); 
            // InternalMyDsl.g:101:3: ( rule__Instruction__Alternatives )
            // InternalMyDsl.g:101:4: rule__Instruction__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Instruction__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getInstructionAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleInstruction"


    // $ANTLR start "entryRuleOpenBrowser"
    // InternalMyDsl.g:110:1: entryRuleOpenBrowser : ruleOpenBrowser EOF ;
    public final void entryRuleOpenBrowser() throws RecognitionException {
        try {
            // InternalMyDsl.g:111:1: ( ruleOpenBrowser EOF )
            // InternalMyDsl.g:112:1: ruleOpenBrowser EOF
            {
             before(grammarAccess.getOpenBrowserRule()); 
            pushFollow(FOLLOW_1);
            ruleOpenBrowser();

            state._fsp--;

             after(grammarAccess.getOpenBrowserRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleOpenBrowser"


    // $ANTLR start "ruleOpenBrowser"
    // InternalMyDsl.g:119:1: ruleOpenBrowser : ( ( rule__OpenBrowser__Group__0 ) ) ;
    public final void ruleOpenBrowser() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:123:2: ( ( ( rule__OpenBrowser__Group__0 ) ) )
            // InternalMyDsl.g:124:2: ( ( rule__OpenBrowser__Group__0 ) )
            {
            // InternalMyDsl.g:124:2: ( ( rule__OpenBrowser__Group__0 ) )
            // InternalMyDsl.g:125:3: ( rule__OpenBrowser__Group__0 )
            {
             before(grammarAccess.getOpenBrowserAccess().getGroup()); 
            // InternalMyDsl.g:126:3: ( rule__OpenBrowser__Group__0 )
            // InternalMyDsl.g:126:4: rule__OpenBrowser__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__OpenBrowser__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getOpenBrowserAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleOpenBrowser"


    // $ANTLR start "entryRuleChangeUrl"
    // InternalMyDsl.g:135:1: entryRuleChangeUrl : ruleChangeUrl EOF ;
    public final void entryRuleChangeUrl() throws RecognitionException {
        try {
            // InternalMyDsl.g:136:1: ( ruleChangeUrl EOF )
            // InternalMyDsl.g:137:1: ruleChangeUrl EOF
            {
             before(grammarAccess.getChangeUrlRule()); 
            pushFollow(FOLLOW_1);
            ruleChangeUrl();

            state._fsp--;

             after(grammarAccess.getChangeUrlRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleChangeUrl"


    // $ANTLR start "ruleChangeUrl"
    // InternalMyDsl.g:144:1: ruleChangeUrl : ( ( rule__ChangeUrl__Group__0 ) ) ;
    public final void ruleChangeUrl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:148:2: ( ( ( rule__ChangeUrl__Group__0 ) ) )
            // InternalMyDsl.g:149:2: ( ( rule__ChangeUrl__Group__0 ) )
            {
            // InternalMyDsl.g:149:2: ( ( rule__ChangeUrl__Group__0 ) )
            // InternalMyDsl.g:150:3: ( rule__ChangeUrl__Group__0 )
            {
             before(grammarAccess.getChangeUrlAccess().getGroup()); 
            // InternalMyDsl.g:151:3: ( rule__ChangeUrl__Group__0 )
            // InternalMyDsl.g:151:4: rule__ChangeUrl__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__ChangeUrl__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getChangeUrlAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleChangeUrl"


    // $ANTLR start "entryRuleContains"
    // InternalMyDsl.g:160:1: entryRuleContains : ruleContains EOF ;
    public final void entryRuleContains() throws RecognitionException {
        try {
            // InternalMyDsl.g:161:1: ( ruleContains EOF )
            // InternalMyDsl.g:162:1: ruleContains EOF
            {
             before(grammarAccess.getContainsRule()); 
            pushFollow(FOLLOW_1);
            ruleContains();

            state._fsp--;

             after(grammarAccess.getContainsRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleContains"


    // $ANTLR start "ruleContains"
    // InternalMyDsl.g:169:1: ruleContains : ( ( rule__Contains__Group__0 ) ) ;
    public final void ruleContains() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:173:2: ( ( ( rule__Contains__Group__0 ) ) )
            // InternalMyDsl.g:174:2: ( ( rule__Contains__Group__0 ) )
            {
            // InternalMyDsl.g:174:2: ( ( rule__Contains__Group__0 ) )
            // InternalMyDsl.g:175:3: ( rule__Contains__Group__0 )
            {
             before(grammarAccess.getContainsAccess().getGroup()); 
            // InternalMyDsl.g:176:3: ( rule__Contains__Group__0 )
            // InternalMyDsl.g:176:4: rule__Contains__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Contains__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getContainsAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleContains"


    // $ANTLR start "entryRuleClick"
    // InternalMyDsl.g:185:1: entryRuleClick : ruleClick EOF ;
    public final void entryRuleClick() throws RecognitionException {
        try {
            // InternalMyDsl.g:186:1: ( ruleClick EOF )
            // InternalMyDsl.g:187:1: ruleClick EOF
            {
             before(grammarAccess.getClickRule()); 
            pushFollow(FOLLOW_1);
            ruleClick();

            state._fsp--;

             after(grammarAccess.getClickRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleClick"


    // $ANTLR start "ruleClick"
    // InternalMyDsl.g:194:1: ruleClick : ( ( rule__Click__Group__0 ) ) ;
    public final void ruleClick() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:198:2: ( ( ( rule__Click__Group__0 ) ) )
            // InternalMyDsl.g:199:2: ( ( rule__Click__Group__0 ) )
            {
            // InternalMyDsl.g:199:2: ( ( rule__Click__Group__0 ) )
            // InternalMyDsl.g:200:3: ( rule__Click__Group__0 )
            {
             before(grammarAccess.getClickAccess().getGroup()); 
            // InternalMyDsl.g:201:3: ( rule__Click__Group__0 )
            // InternalMyDsl.g:201:4: rule__Click__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Click__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getClickAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleClick"


    // $ANTLR start "entryRuleSet"
    // InternalMyDsl.g:210:1: entryRuleSet : ruleSet EOF ;
    public final void entryRuleSet() throws RecognitionException {
        try {
            // InternalMyDsl.g:211:1: ( ruleSet EOF )
            // InternalMyDsl.g:212:1: ruleSet EOF
            {
             before(grammarAccess.getSetRule()); 
            pushFollow(FOLLOW_1);
            ruleSet();

            state._fsp--;

             after(grammarAccess.getSetRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleSet"


    // $ANTLR start "ruleSet"
    // InternalMyDsl.g:219:1: ruleSet : ( ( rule__Set__Group__0 ) ) ;
    public final void ruleSet() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:223:2: ( ( ( rule__Set__Group__0 ) ) )
            // InternalMyDsl.g:224:2: ( ( rule__Set__Group__0 ) )
            {
            // InternalMyDsl.g:224:2: ( ( rule__Set__Group__0 ) )
            // InternalMyDsl.g:225:3: ( rule__Set__Group__0 )
            {
             before(grammarAccess.getSetAccess().getGroup()); 
            // InternalMyDsl.g:226:3: ( rule__Set__Group__0 )
            // InternalMyDsl.g:226:4: rule__Set__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Set__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getSetAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleSet"


    // $ANTLR start "entryRuleCheck"
    // InternalMyDsl.g:235:1: entryRuleCheck : ruleCheck EOF ;
    public final void entryRuleCheck() throws RecognitionException {
        try {
            // InternalMyDsl.g:236:1: ( ruleCheck EOF )
            // InternalMyDsl.g:237:1: ruleCheck EOF
            {
             before(grammarAccess.getCheckRule()); 
            pushFollow(FOLLOW_1);
            ruleCheck();

            state._fsp--;

             after(grammarAccess.getCheckRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleCheck"


    // $ANTLR start "ruleCheck"
    // InternalMyDsl.g:244:1: ruleCheck : ( ( rule__Check__Group__0 ) ) ;
    public final void ruleCheck() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:248:2: ( ( ( rule__Check__Group__0 ) ) )
            // InternalMyDsl.g:249:2: ( ( rule__Check__Group__0 ) )
            {
            // InternalMyDsl.g:249:2: ( ( rule__Check__Group__0 ) )
            // InternalMyDsl.g:250:3: ( rule__Check__Group__0 )
            {
             before(grammarAccess.getCheckAccess().getGroup()); 
            // InternalMyDsl.g:251:3: ( rule__Check__Group__0 )
            // InternalMyDsl.g:251:4: rule__Check__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Check__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getCheckAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleCheck"


    // $ANTLR start "entryRuleUncheck"
    // InternalMyDsl.g:260:1: entryRuleUncheck : ruleUncheck EOF ;
    public final void entryRuleUncheck() throws RecognitionException {
        try {
            // InternalMyDsl.g:261:1: ( ruleUncheck EOF )
            // InternalMyDsl.g:262:1: ruleUncheck EOF
            {
             before(grammarAccess.getUncheckRule()); 
            pushFollow(FOLLOW_1);
            ruleUncheck();

            state._fsp--;

             after(grammarAccess.getUncheckRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleUncheck"


    // $ANTLR start "ruleUncheck"
    // InternalMyDsl.g:269:1: ruleUncheck : ( ( rule__Uncheck__Group__0 ) ) ;
    public final void ruleUncheck() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:273:2: ( ( ( rule__Uncheck__Group__0 ) ) )
            // InternalMyDsl.g:274:2: ( ( rule__Uncheck__Group__0 ) )
            {
            // InternalMyDsl.g:274:2: ( ( rule__Uncheck__Group__0 ) )
            // InternalMyDsl.g:275:3: ( rule__Uncheck__Group__0 )
            {
             before(grammarAccess.getUncheckAccess().getGroup()); 
            // InternalMyDsl.g:276:3: ( rule__Uncheck__Group__0 )
            // InternalMyDsl.g:276:4: rule__Uncheck__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Uncheck__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getUncheckAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleUncheck"


    // $ANTLR start "entryRuleRead"
    // InternalMyDsl.g:285:1: entryRuleRead : ruleRead EOF ;
    public final void entryRuleRead() throws RecognitionException {
        try {
            // InternalMyDsl.g:286:1: ( ruleRead EOF )
            // InternalMyDsl.g:287:1: ruleRead EOF
            {
             before(grammarAccess.getReadRule()); 
            pushFollow(FOLLOW_1);
            ruleRead();

            state._fsp--;

             after(grammarAccess.getReadRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleRead"


    // $ANTLR start "ruleRead"
    // InternalMyDsl.g:294:1: ruleRead : ( ( rule__Read__Group__0 ) ) ;
    public final void ruleRead() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:298:2: ( ( ( rule__Read__Group__0 ) ) )
            // InternalMyDsl.g:299:2: ( ( rule__Read__Group__0 ) )
            {
            // InternalMyDsl.g:299:2: ( ( rule__Read__Group__0 ) )
            // InternalMyDsl.g:300:3: ( rule__Read__Group__0 )
            {
             before(grammarAccess.getReadAccess().getGroup()); 
            // InternalMyDsl.g:301:3: ( rule__Read__Group__0 )
            // InternalMyDsl.g:301:4: rule__Read__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Read__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getReadAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleRead"


    // $ANTLR start "entryRuleCount"
    // InternalMyDsl.g:310:1: entryRuleCount : ruleCount EOF ;
    public final void entryRuleCount() throws RecognitionException {
        try {
            // InternalMyDsl.g:311:1: ( ruleCount EOF )
            // InternalMyDsl.g:312:1: ruleCount EOF
            {
             before(grammarAccess.getCountRule()); 
            pushFollow(FOLLOW_1);
            ruleCount();

            state._fsp--;

             after(grammarAccess.getCountRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleCount"


    // $ANTLR start "ruleCount"
    // InternalMyDsl.g:319:1: ruleCount : ( ( rule__Count__Group__0 ) ) ;
    public final void ruleCount() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:323:2: ( ( ( rule__Count__Group__0 ) ) )
            // InternalMyDsl.g:324:2: ( ( rule__Count__Group__0 ) )
            {
            // InternalMyDsl.g:324:2: ( ( rule__Count__Group__0 ) )
            // InternalMyDsl.g:325:3: ( rule__Count__Group__0 )
            {
             before(grammarAccess.getCountAccess().getGroup()); 
            // InternalMyDsl.g:326:3: ( rule__Count__Group__0 )
            // InternalMyDsl.g:326:4: rule__Count__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Count__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getCountAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleCount"


    // $ANTLR start "entryRuleEqualsTo"
    // InternalMyDsl.g:335:1: entryRuleEqualsTo : ruleEqualsTo EOF ;
    public final void entryRuleEqualsTo() throws RecognitionException {
        try {
            // InternalMyDsl.g:336:1: ( ruleEqualsTo EOF )
            // InternalMyDsl.g:337:1: ruleEqualsTo EOF
            {
             before(grammarAccess.getEqualsToRule()); 
            pushFollow(FOLLOW_1);
            ruleEqualsTo();

            state._fsp--;

             after(grammarAccess.getEqualsToRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleEqualsTo"


    // $ANTLR start "ruleEqualsTo"
    // InternalMyDsl.g:344:1: ruleEqualsTo : ( ( rule__EqualsTo__Group__0 ) ) ;
    public final void ruleEqualsTo() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:348:2: ( ( ( rule__EqualsTo__Group__0 ) ) )
            // InternalMyDsl.g:349:2: ( ( rule__EqualsTo__Group__0 ) )
            {
            // InternalMyDsl.g:349:2: ( ( rule__EqualsTo__Group__0 ) )
            // InternalMyDsl.g:350:3: ( rule__EqualsTo__Group__0 )
            {
             before(grammarAccess.getEqualsToAccess().getGroup()); 
            // InternalMyDsl.g:351:3: ( rule__EqualsTo__Group__0 )
            // InternalMyDsl.g:351:4: rule__EqualsTo__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__EqualsTo__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getEqualsToAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleEqualsTo"


    // $ANTLR start "entryRuleOfTitle"
    // InternalMyDsl.g:360:1: entryRuleOfTitle : ruleOfTitle EOF ;
    public final void entryRuleOfTitle() throws RecognitionException {
        try {
            // InternalMyDsl.g:361:1: ( ruleOfTitle EOF )
            // InternalMyDsl.g:362:1: ruleOfTitle EOF
            {
             before(grammarAccess.getOfTitleRule()); 
            pushFollow(FOLLOW_1);
            ruleOfTitle();

            state._fsp--;

             after(grammarAccess.getOfTitleRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleOfTitle"


    // $ANTLR start "ruleOfTitle"
    // InternalMyDsl.g:369:1: ruleOfTitle : ( 'of title' ) ;
    public final void ruleOfTitle() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:373:2: ( ( 'of title' ) )
            // InternalMyDsl.g:374:2: ( 'of title' )
            {
            // InternalMyDsl.g:374:2: ( 'of title' )
            // InternalMyDsl.g:375:3: 'of title'
            {
             before(grammarAccess.getOfTitleAccess().getOfTitleKeyword()); 
            match(input,11,FOLLOW_2); 
             after(grammarAccess.getOfTitleAccess().getOfTitleKeyword()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleOfTitle"


    // $ANTLR start "entryRuleVariable"
    // InternalMyDsl.g:385:1: entryRuleVariable : ruleVariable EOF ;
    public final void entryRuleVariable() throws RecognitionException {
        try {
            // InternalMyDsl.g:386:1: ( ruleVariable EOF )
            // InternalMyDsl.g:387:1: ruleVariable EOF
            {
             before(grammarAccess.getVariableRule()); 
            pushFollow(FOLLOW_1);
            ruleVariable();

            state._fsp--;

             after(grammarAccess.getVariableRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleVariable"


    // $ANTLR start "ruleVariable"
    // InternalMyDsl.g:394:1: ruleVariable : ( ( rule__Variable__Group__0 ) ) ;
    public final void ruleVariable() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:398:2: ( ( ( rule__Variable__Group__0 ) ) )
            // InternalMyDsl.g:399:2: ( ( rule__Variable__Group__0 ) )
            {
            // InternalMyDsl.g:399:2: ( ( rule__Variable__Group__0 ) )
            // InternalMyDsl.g:400:3: ( rule__Variable__Group__0 )
            {
             before(grammarAccess.getVariableAccess().getGroup()); 
            // InternalMyDsl.g:401:3: ( rule__Variable__Group__0 )
            // InternalMyDsl.g:401:4: rule__Variable__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Variable__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getVariableAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleVariable"


    // $ANTLR start "entryRuleCall"
    // InternalMyDsl.g:410:1: entryRuleCall : ruleCall EOF ;
    public final void entryRuleCall() throws RecognitionException {
        try {
            // InternalMyDsl.g:411:1: ( ruleCall EOF )
            // InternalMyDsl.g:412:1: ruleCall EOF
            {
             before(grammarAccess.getCallRule()); 
            pushFollow(FOLLOW_1);
            ruleCall();

            state._fsp--;

             after(grammarAccess.getCallRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleCall"


    // $ANTLR start "ruleCall"
    // InternalMyDsl.g:419:1: ruleCall : ( ( rule__Call__Group__0 ) ) ;
    public final void ruleCall() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:423:2: ( ( ( rule__Call__Group__0 ) ) )
            // InternalMyDsl.g:424:2: ( ( rule__Call__Group__0 ) )
            {
            // InternalMyDsl.g:424:2: ( ( rule__Call__Group__0 ) )
            // InternalMyDsl.g:425:3: ( rule__Call__Group__0 )
            {
             before(grammarAccess.getCallAccess().getGroup()); 
            // InternalMyDsl.g:426:3: ( rule__Call__Group__0 )
            // InternalMyDsl.g:426:4: rule__Call__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Call__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getCallAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleCall"


    // $ANTLR start "entryRuleFunction"
    // InternalMyDsl.g:435:1: entryRuleFunction : ruleFunction EOF ;
    public final void entryRuleFunction() throws RecognitionException {
        try {
            // InternalMyDsl.g:436:1: ( ruleFunction EOF )
            // InternalMyDsl.g:437:1: ruleFunction EOF
            {
             before(grammarAccess.getFunctionRule()); 
            pushFollow(FOLLOW_1);
            ruleFunction();

            state._fsp--;

             after(grammarAccess.getFunctionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleFunction"


    // $ANTLR start "ruleFunction"
    // InternalMyDsl.g:444:1: ruleFunction : ( ( rule__Function__Group__0 ) ) ;
    public final void ruleFunction() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:448:2: ( ( ( rule__Function__Group__0 ) ) )
            // InternalMyDsl.g:449:2: ( ( rule__Function__Group__0 ) )
            {
            // InternalMyDsl.g:449:2: ( ( rule__Function__Group__0 ) )
            // InternalMyDsl.g:450:3: ( rule__Function__Group__0 )
            {
             before(grammarAccess.getFunctionAccess().getGroup()); 
            // InternalMyDsl.g:451:3: ( rule__Function__Group__0 )
            // InternalMyDsl.g:451:4: rule__Function__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Function__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getFunctionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleFunction"


    // $ANTLR start "entryRuleName"
    // InternalMyDsl.g:460:1: entryRuleName : ruleName EOF ;
    public final void entryRuleName() throws RecognitionException {
        try {
            // InternalMyDsl.g:461:1: ( ruleName EOF )
            // InternalMyDsl.g:462:1: ruleName EOF
            {
             before(grammarAccess.getNameRule()); 
            pushFollow(FOLLOW_1);
            ruleName();

            state._fsp--;

             after(grammarAccess.getNameRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleName"


    // $ANTLR start "ruleName"
    // InternalMyDsl.g:469:1: ruleName : ( ( rule__Name__Group__0 ) ) ;
    public final void ruleName() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:473:2: ( ( ( rule__Name__Group__0 ) ) )
            // InternalMyDsl.g:474:2: ( ( rule__Name__Group__0 ) )
            {
            // InternalMyDsl.g:474:2: ( ( rule__Name__Group__0 ) )
            // InternalMyDsl.g:475:3: ( rule__Name__Group__0 )
            {
             before(grammarAccess.getNameAccess().getGroup()); 
            // InternalMyDsl.g:476:3: ( rule__Name__Group__0 )
            // InternalMyDsl.g:476:4: rule__Name__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Name__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getNameAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleName"


    // $ANTLR start "entryRuleValue"
    // InternalMyDsl.g:485:1: entryRuleValue : ruleValue EOF ;
    public final void entryRuleValue() throws RecognitionException {
        try {
            // InternalMyDsl.g:486:1: ( ruleValue EOF )
            // InternalMyDsl.g:487:1: ruleValue EOF
            {
             before(grammarAccess.getValueRule()); 
            pushFollow(FOLLOW_1);
            ruleValue();

            state._fsp--;

             after(grammarAccess.getValueRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleValue"


    // $ANTLR start "ruleValue"
    // InternalMyDsl.g:494:1: ruleValue : ( ( rule__Value__Group__0 ) ) ;
    public final void ruleValue() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:498:2: ( ( ( rule__Value__Group__0 ) ) )
            // InternalMyDsl.g:499:2: ( ( rule__Value__Group__0 ) )
            {
            // InternalMyDsl.g:499:2: ( ( rule__Value__Group__0 ) )
            // InternalMyDsl.g:500:3: ( rule__Value__Group__0 )
            {
             before(grammarAccess.getValueAccess().getGroup()); 
            // InternalMyDsl.g:501:3: ( rule__Value__Group__0 )
            // InternalMyDsl.g:501:4: rule__Value__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Value__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getValueAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleValue"


    // $ANTLR start "entryRuleParameter"
    // InternalMyDsl.g:510:1: entryRuleParameter : ruleParameter EOF ;
    public final void entryRuleParameter() throws RecognitionException {
        try {
            // InternalMyDsl.g:511:1: ( ruleParameter EOF )
            // InternalMyDsl.g:512:1: ruleParameter EOF
            {
             before(grammarAccess.getParameterRule()); 
            pushFollow(FOLLOW_1);
            ruleParameter();

            state._fsp--;

             after(grammarAccess.getParameterRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleParameter"


    // $ANTLR start "ruleParameter"
    // InternalMyDsl.g:519:1: ruleParameter : ( ( rule__Parameter__Alternatives ) ) ;
    public final void ruleParameter() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:523:2: ( ( ( rule__Parameter__Alternatives ) ) )
            // InternalMyDsl.g:524:2: ( ( rule__Parameter__Alternatives ) )
            {
            // InternalMyDsl.g:524:2: ( ( rule__Parameter__Alternatives ) )
            // InternalMyDsl.g:525:3: ( rule__Parameter__Alternatives )
            {
             before(grammarAccess.getParameterAccess().getAlternatives()); 
            // InternalMyDsl.g:526:3: ( rule__Parameter__Alternatives )
            // InternalMyDsl.g:526:4: rule__Parameter__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Parameter__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getParameterAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleParameter"


    // $ANTLR start "entryRuleTypeElement"
    // InternalMyDsl.g:535:1: entryRuleTypeElement : ruleTypeElement EOF ;
    public final void entryRuleTypeElement() throws RecognitionException {
        try {
            // InternalMyDsl.g:536:1: ( ruleTypeElement EOF )
            // InternalMyDsl.g:537:1: ruleTypeElement EOF
            {
             before(grammarAccess.getTypeElementRule()); 
            pushFollow(FOLLOW_1);
            ruleTypeElement();

            state._fsp--;

             after(grammarAccess.getTypeElementRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleTypeElement"


    // $ANTLR start "ruleTypeElement"
    // InternalMyDsl.g:544:1: ruleTypeElement : ( ( rule__TypeElement__Alternatives ) ) ;
    public final void ruleTypeElement() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:548:2: ( ( ( rule__TypeElement__Alternatives ) ) )
            // InternalMyDsl.g:549:2: ( ( rule__TypeElement__Alternatives ) )
            {
            // InternalMyDsl.g:549:2: ( ( rule__TypeElement__Alternatives ) )
            // InternalMyDsl.g:550:3: ( rule__TypeElement__Alternatives )
            {
             before(grammarAccess.getTypeElementAccess().getAlternatives()); 
            // InternalMyDsl.g:551:3: ( rule__TypeElement__Alternatives )
            // InternalMyDsl.g:551:4: rule__TypeElement__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__TypeElement__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getTypeElementAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleTypeElement"


    // $ANTLR start "entryRuleTypeProperty"
    // InternalMyDsl.g:560:1: entryRuleTypeProperty : ruleTypeProperty EOF ;
    public final void entryRuleTypeProperty() throws RecognitionException {
        try {
            // InternalMyDsl.g:561:1: ( ruleTypeProperty EOF )
            // InternalMyDsl.g:562:1: ruleTypeProperty EOF
            {
             before(grammarAccess.getTypePropertyRule()); 
            pushFollow(FOLLOW_1);
            ruleTypeProperty();

            state._fsp--;

             after(grammarAccess.getTypePropertyRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleTypeProperty"


    // $ANTLR start "ruleTypeProperty"
    // InternalMyDsl.g:569:1: ruleTypeProperty : ( ( rule__TypeProperty__Alternatives ) ) ;
    public final void ruleTypeProperty() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:573:2: ( ( ( rule__TypeProperty__Alternatives ) ) )
            // InternalMyDsl.g:574:2: ( ( rule__TypeProperty__Alternatives ) )
            {
            // InternalMyDsl.g:574:2: ( ( rule__TypeProperty__Alternatives ) )
            // InternalMyDsl.g:575:3: ( rule__TypeProperty__Alternatives )
            {
             before(grammarAccess.getTypePropertyAccess().getAlternatives()); 
            // InternalMyDsl.g:576:3: ( rule__TypeProperty__Alternatives )
            // InternalMyDsl.g:576:4: rule__TypeProperty__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__TypeProperty__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getTypePropertyAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleTypeProperty"


    // $ANTLR start "entryRuleTypeLink"
    // InternalMyDsl.g:585:1: entryRuleTypeLink : ruleTypeLink EOF ;
    public final void entryRuleTypeLink() throws RecognitionException {
        try {
            // InternalMyDsl.g:586:1: ( ruleTypeLink EOF )
            // InternalMyDsl.g:587:1: ruleTypeLink EOF
            {
             before(grammarAccess.getTypeLinkRule()); 
            pushFollow(FOLLOW_1);
            ruleTypeLink();

            state._fsp--;

             after(grammarAccess.getTypeLinkRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleTypeLink"


    // $ANTLR start "ruleTypeLink"
    // InternalMyDsl.g:594:1: ruleTypeLink : ( 'link' ) ;
    public final void ruleTypeLink() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:598:2: ( ( 'link' ) )
            // InternalMyDsl.g:599:2: ( 'link' )
            {
            // InternalMyDsl.g:599:2: ( 'link' )
            // InternalMyDsl.g:600:3: 'link'
            {
             before(grammarAccess.getTypeLinkAccess().getLinkKeyword()); 
            match(input,12,FOLLOW_2); 
             after(grammarAccess.getTypeLinkAccess().getLinkKeyword()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleTypeLink"


    // $ANTLR start "entryRuleTypeImage"
    // InternalMyDsl.g:610:1: entryRuleTypeImage : ruleTypeImage EOF ;
    public final void entryRuleTypeImage() throws RecognitionException {
        try {
            // InternalMyDsl.g:611:1: ( ruleTypeImage EOF )
            // InternalMyDsl.g:612:1: ruleTypeImage EOF
            {
             before(grammarAccess.getTypeImageRule()); 
            pushFollow(FOLLOW_1);
            ruleTypeImage();

            state._fsp--;

             after(grammarAccess.getTypeImageRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleTypeImage"


    // $ANTLR start "ruleTypeImage"
    // InternalMyDsl.g:619:1: ruleTypeImage : ( 'image' ) ;
    public final void ruleTypeImage() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:623:2: ( ( 'image' ) )
            // InternalMyDsl.g:624:2: ( 'image' )
            {
            // InternalMyDsl.g:624:2: ( 'image' )
            // InternalMyDsl.g:625:3: 'image'
            {
             before(grammarAccess.getTypeImageAccess().getImageKeyword()); 
            match(input,13,FOLLOW_2); 
             after(grammarAccess.getTypeImageAccess().getImageKeyword()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleTypeImage"


    // $ANTLR start "entryRuleTypeText"
    // InternalMyDsl.g:635:1: entryRuleTypeText : ruleTypeText EOF ;
    public final void entryRuleTypeText() throws RecognitionException {
        try {
            // InternalMyDsl.g:636:1: ( ruleTypeText EOF )
            // InternalMyDsl.g:637:1: ruleTypeText EOF
            {
             before(grammarAccess.getTypeTextRule()); 
            pushFollow(FOLLOW_1);
            ruleTypeText();

            state._fsp--;

             after(grammarAccess.getTypeTextRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleTypeText"


    // $ANTLR start "ruleTypeText"
    // InternalMyDsl.g:644:1: ruleTypeText : ( 'text' ) ;
    public final void ruleTypeText() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:648:2: ( ( 'text' ) )
            // InternalMyDsl.g:649:2: ( 'text' )
            {
            // InternalMyDsl.g:649:2: ( 'text' )
            // InternalMyDsl.g:650:3: 'text'
            {
             before(grammarAccess.getTypeTextAccess().getTextKeyword()); 
            match(input,14,FOLLOW_2); 
             after(grammarAccess.getTypeTextAccess().getTextKeyword()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleTypeText"


    // $ANTLR start "entryRuleTypeButton"
    // InternalMyDsl.g:660:1: entryRuleTypeButton : ruleTypeButton EOF ;
    public final void entryRuleTypeButton() throws RecognitionException {
        try {
            // InternalMyDsl.g:661:1: ( ruleTypeButton EOF )
            // InternalMyDsl.g:662:1: ruleTypeButton EOF
            {
             before(grammarAccess.getTypeButtonRule()); 
            pushFollow(FOLLOW_1);
            ruleTypeButton();

            state._fsp--;

             after(grammarAccess.getTypeButtonRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleTypeButton"


    // $ANTLR start "ruleTypeButton"
    // InternalMyDsl.g:669:1: ruleTypeButton : ( 'button' ) ;
    public final void ruleTypeButton() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:673:2: ( ( 'button' ) )
            // InternalMyDsl.g:674:2: ( 'button' )
            {
            // InternalMyDsl.g:674:2: ( 'button' )
            // InternalMyDsl.g:675:3: 'button'
            {
             before(grammarAccess.getTypeButtonAccess().getButtonKeyword()); 
            match(input,15,FOLLOW_2); 
             after(grammarAccess.getTypeButtonAccess().getButtonKeyword()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleTypeButton"


    // $ANTLR start "entryRuleTypeInput"
    // InternalMyDsl.g:685:1: entryRuleTypeInput : ruleTypeInput EOF ;
    public final void entryRuleTypeInput() throws RecognitionException {
        try {
            // InternalMyDsl.g:686:1: ( ruleTypeInput EOF )
            // InternalMyDsl.g:687:1: ruleTypeInput EOF
            {
             before(grammarAccess.getTypeInputRule()); 
            pushFollow(FOLLOW_1);
            ruleTypeInput();

            state._fsp--;

             after(grammarAccess.getTypeInputRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleTypeInput"


    // $ANTLR start "ruleTypeInput"
    // InternalMyDsl.g:694:1: ruleTypeInput : ( 'input' ) ;
    public final void ruleTypeInput() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:698:2: ( ( 'input' ) )
            // InternalMyDsl.g:699:2: ( 'input' )
            {
            // InternalMyDsl.g:699:2: ( 'input' )
            // InternalMyDsl.g:700:3: 'input'
            {
             before(grammarAccess.getTypeInputAccess().getInputKeyword()); 
            match(input,16,FOLLOW_2); 
             after(grammarAccess.getTypeInputAccess().getInputKeyword()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleTypeInput"


    // $ANTLR start "entryRuleTypeCombo"
    // InternalMyDsl.g:710:1: entryRuleTypeCombo : ruleTypeCombo EOF ;
    public final void entryRuleTypeCombo() throws RecognitionException {
        try {
            // InternalMyDsl.g:711:1: ( ruleTypeCombo EOF )
            // InternalMyDsl.g:712:1: ruleTypeCombo EOF
            {
             before(grammarAccess.getTypeComboRule()); 
            pushFollow(FOLLOW_1);
            ruleTypeCombo();

            state._fsp--;

             after(grammarAccess.getTypeComboRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleTypeCombo"


    // $ANTLR start "ruleTypeCombo"
    // InternalMyDsl.g:719:1: ruleTypeCombo : ( 'combobox' ) ;
    public final void ruleTypeCombo() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:723:2: ( ( 'combobox' ) )
            // InternalMyDsl.g:724:2: ( 'combobox' )
            {
            // InternalMyDsl.g:724:2: ( 'combobox' )
            // InternalMyDsl.g:725:3: 'combobox'
            {
             before(grammarAccess.getTypeComboAccess().getComboboxKeyword()); 
            match(input,17,FOLLOW_2); 
             after(grammarAccess.getTypeComboAccess().getComboboxKeyword()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleTypeCombo"


    // $ANTLR start "entryRuleTypeTitle"
    // InternalMyDsl.g:735:1: entryRuleTypeTitle : ruleTypeTitle EOF ;
    public final void entryRuleTypeTitle() throws RecognitionException {
        try {
            // InternalMyDsl.g:736:1: ( ruleTypeTitle EOF )
            // InternalMyDsl.g:737:1: ruleTypeTitle EOF
            {
             before(grammarAccess.getTypeTitleRule()); 
            pushFollow(FOLLOW_1);
            ruleTypeTitle();

            state._fsp--;

             after(grammarAccess.getTypeTitleRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleTypeTitle"


    // $ANTLR start "ruleTypeTitle"
    // InternalMyDsl.g:744:1: ruleTypeTitle : ( 'title' ) ;
    public final void ruleTypeTitle() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:748:2: ( ( 'title' ) )
            // InternalMyDsl.g:749:2: ( 'title' )
            {
            // InternalMyDsl.g:749:2: ( 'title' )
            // InternalMyDsl.g:750:3: 'title'
            {
             before(grammarAccess.getTypeTitleAccess().getTitleKeyword()); 
            match(input,18,FOLLOW_2); 
             after(grammarAccess.getTypeTitleAccess().getTitleKeyword()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleTypeTitle"


    // $ANTLR start "entryRuleTypeUrl"
    // InternalMyDsl.g:760:1: entryRuleTypeUrl : ruleTypeUrl EOF ;
    public final void entryRuleTypeUrl() throws RecognitionException {
        try {
            // InternalMyDsl.g:761:1: ( ruleTypeUrl EOF )
            // InternalMyDsl.g:762:1: ruleTypeUrl EOF
            {
             before(grammarAccess.getTypeUrlRule()); 
            pushFollow(FOLLOW_1);
            ruleTypeUrl();

            state._fsp--;

             after(grammarAccess.getTypeUrlRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleTypeUrl"


    // $ANTLR start "ruleTypeUrl"
    // InternalMyDsl.g:769:1: ruleTypeUrl : ( 'url' ) ;
    public final void ruleTypeUrl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:773:2: ( ( 'url' ) )
            // InternalMyDsl.g:774:2: ( 'url' )
            {
            // InternalMyDsl.g:774:2: ( 'url' )
            // InternalMyDsl.g:775:3: 'url'
            {
             before(grammarAccess.getTypeUrlAccess().getUrlKeyword()); 
            match(input,19,FOLLOW_2); 
             after(grammarAccess.getTypeUrlAccess().getUrlKeyword()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleTypeUrl"


    // $ANTLR start "entryRuleTypeCheckBox"
    // InternalMyDsl.g:785:1: entryRuleTypeCheckBox : ruleTypeCheckBox EOF ;
    public final void entryRuleTypeCheckBox() throws RecognitionException {
        try {
            // InternalMyDsl.g:786:1: ( ruleTypeCheckBox EOF )
            // InternalMyDsl.g:787:1: ruleTypeCheckBox EOF
            {
             before(grammarAccess.getTypeCheckBoxRule()); 
            pushFollow(FOLLOW_1);
            ruleTypeCheckBox();

            state._fsp--;

             after(grammarAccess.getTypeCheckBoxRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleTypeCheckBox"


    // $ANTLR start "ruleTypeCheckBox"
    // InternalMyDsl.g:794:1: ruleTypeCheckBox : ( 'checkbox' ) ;
    public final void ruleTypeCheckBox() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:798:2: ( ( 'checkbox' ) )
            // InternalMyDsl.g:799:2: ( 'checkbox' )
            {
            // InternalMyDsl.g:799:2: ( 'checkbox' )
            // InternalMyDsl.g:800:3: 'checkbox'
            {
             before(grammarAccess.getTypeCheckBoxAccess().getCheckboxKeyword()); 
            match(input,20,FOLLOW_2); 
             after(grammarAccess.getTypeCheckBoxAccess().getCheckboxKeyword()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleTypeCheckBox"


    // $ANTLR start "entryRuleTypeSet"
    // InternalMyDsl.g:810:1: entryRuleTypeSet : ruleTypeSet EOF ;
    public final void entryRuleTypeSet() throws RecognitionException {
        try {
            // InternalMyDsl.g:811:1: ( ruleTypeSet EOF )
            // InternalMyDsl.g:812:1: ruleTypeSet EOF
            {
             before(grammarAccess.getTypeSetRule()); 
            pushFollow(FOLLOW_1);
            ruleTypeSet();

            state._fsp--;

             after(grammarAccess.getTypeSetRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleTypeSet"


    // $ANTLR start "ruleTypeSet"
    // InternalMyDsl.g:819:1: ruleTypeSet : ( ( rule__TypeSet__Alternatives ) ) ;
    public final void ruleTypeSet() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:823:2: ( ( ( rule__TypeSet__Alternatives ) ) )
            // InternalMyDsl.g:824:2: ( ( rule__TypeSet__Alternatives ) )
            {
            // InternalMyDsl.g:824:2: ( ( rule__TypeSet__Alternatives ) )
            // InternalMyDsl.g:825:3: ( rule__TypeSet__Alternatives )
            {
             before(grammarAccess.getTypeSetAccess().getAlternatives()); 
            // InternalMyDsl.g:826:3: ( rule__TypeSet__Alternatives )
            // InternalMyDsl.g:826:4: rule__TypeSet__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__TypeSet__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getTypeSetAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleTypeSet"


    // $ANTLR start "rule__Instruction__Alternatives"
    // InternalMyDsl.g:834:1: rule__Instruction__Alternatives : ( ( ruleOpenBrowser ) | ( ruleContains ) | ( ruleClick ) | ( ruleSet ) | ( ruleCheck ) | ( ruleUncheck ) | ( ruleChangeUrl ) | ( ruleRead ) | ( ruleVariable ) | ( ruleFunction ) | ( ruleCount ) | ( ruleEqualsTo ) | ( ruleCall ) );
    public final void rule__Instruction__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:838:1: ( ( ruleOpenBrowser ) | ( ruleContains ) | ( ruleClick ) | ( ruleSet ) | ( ruleCheck ) | ( ruleUncheck ) | ( ruleChangeUrl ) | ( ruleRead ) | ( ruleVariable ) | ( ruleFunction ) | ( ruleCount ) | ( ruleEqualsTo ) | ( ruleCall ) )
            int alt2=13;
            switch ( input.LA(1) ) {
            case 22:
                {
                alt2=1;
                }
                break;
            case 24:
                {
                alt2=2;
                }
                break;
            case 25:
                {
                alt2=3;
                }
                break;
            case 26:
                {
                alt2=4;
                }
                break;
            case 27:
                {
                alt2=5;
                }
                break;
            case 28:
                {
                alt2=6;
                }
                break;
            case 23:
                {
                alt2=7;
                }
                break;
            case 29:
                {
                alt2=8;
                }
                break;
            case 32:
                {
                alt2=9;
                }
                break;
            case 36:
                {
                alt2=10;
                }
                break;
            case 30:
                {
                alt2=11;
                }
                break;
            case 31:
                {
                alt2=12;
                }
                break;
            case 34:
                {
                alt2=13;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                throw nvae;
            }

            switch (alt2) {
                case 1 :
                    // InternalMyDsl.g:839:2: ( ruleOpenBrowser )
                    {
                    // InternalMyDsl.g:839:2: ( ruleOpenBrowser )
                    // InternalMyDsl.g:840:3: ruleOpenBrowser
                    {
                     before(grammarAccess.getInstructionAccess().getOpenBrowserParserRuleCall_0()); 
                    pushFollow(FOLLOW_2);
                    ruleOpenBrowser();

                    state._fsp--;

                     after(grammarAccess.getInstructionAccess().getOpenBrowserParserRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:845:2: ( ruleContains )
                    {
                    // InternalMyDsl.g:845:2: ( ruleContains )
                    // InternalMyDsl.g:846:3: ruleContains
                    {
                     before(grammarAccess.getInstructionAccess().getContainsParserRuleCall_1()); 
                    pushFollow(FOLLOW_2);
                    ruleContains();

                    state._fsp--;

                     after(grammarAccess.getInstructionAccess().getContainsParserRuleCall_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalMyDsl.g:851:2: ( ruleClick )
                    {
                    // InternalMyDsl.g:851:2: ( ruleClick )
                    // InternalMyDsl.g:852:3: ruleClick
                    {
                     before(grammarAccess.getInstructionAccess().getClickParserRuleCall_2()); 
                    pushFollow(FOLLOW_2);
                    ruleClick();

                    state._fsp--;

                     after(grammarAccess.getInstructionAccess().getClickParserRuleCall_2()); 

                    }


                    }
                    break;
                case 4 :
                    // InternalMyDsl.g:857:2: ( ruleSet )
                    {
                    // InternalMyDsl.g:857:2: ( ruleSet )
                    // InternalMyDsl.g:858:3: ruleSet
                    {
                     before(grammarAccess.getInstructionAccess().getSetParserRuleCall_3()); 
                    pushFollow(FOLLOW_2);
                    ruleSet();

                    state._fsp--;

                     after(grammarAccess.getInstructionAccess().getSetParserRuleCall_3()); 

                    }


                    }
                    break;
                case 5 :
                    // InternalMyDsl.g:863:2: ( ruleCheck )
                    {
                    // InternalMyDsl.g:863:2: ( ruleCheck )
                    // InternalMyDsl.g:864:3: ruleCheck
                    {
                     before(grammarAccess.getInstructionAccess().getCheckParserRuleCall_4()); 
                    pushFollow(FOLLOW_2);
                    ruleCheck();

                    state._fsp--;

                     after(grammarAccess.getInstructionAccess().getCheckParserRuleCall_4()); 

                    }


                    }
                    break;
                case 6 :
                    // InternalMyDsl.g:869:2: ( ruleUncheck )
                    {
                    // InternalMyDsl.g:869:2: ( ruleUncheck )
                    // InternalMyDsl.g:870:3: ruleUncheck
                    {
                     before(grammarAccess.getInstructionAccess().getUncheckParserRuleCall_5()); 
                    pushFollow(FOLLOW_2);
                    ruleUncheck();

                    state._fsp--;

                     after(grammarAccess.getInstructionAccess().getUncheckParserRuleCall_5()); 

                    }


                    }
                    break;
                case 7 :
                    // InternalMyDsl.g:875:2: ( ruleChangeUrl )
                    {
                    // InternalMyDsl.g:875:2: ( ruleChangeUrl )
                    // InternalMyDsl.g:876:3: ruleChangeUrl
                    {
                     before(grammarAccess.getInstructionAccess().getChangeUrlParserRuleCall_6()); 
                    pushFollow(FOLLOW_2);
                    ruleChangeUrl();

                    state._fsp--;

                     after(grammarAccess.getInstructionAccess().getChangeUrlParserRuleCall_6()); 

                    }


                    }
                    break;
                case 8 :
                    // InternalMyDsl.g:881:2: ( ruleRead )
                    {
                    // InternalMyDsl.g:881:2: ( ruleRead )
                    // InternalMyDsl.g:882:3: ruleRead
                    {
                     before(grammarAccess.getInstructionAccess().getReadParserRuleCall_7()); 
                    pushFollow(FOLLOW_2);
                    ruleRead();

                    state._fsp--;

                     after(grammarAccess.getInstructionAccess().getReadParserRuleCall_7()); 

                    }


                    }
                    break;
                case 9 :
                    // InternalMyDsl.g:887:2: ( ruleVariable )
                    {
                    // InternalMyDsl.g:887:2: ( ruleVariable )
                    // InternalMyDsl.g:888:3: ruleVariable
                    {
                     before(grammarAccess.getInstructionAccess().getVariableParserRuleCall_8()); 
                    pushFollow(FOLLOW_2);
                    ruleVariable();

                    state._fsp--;

                     after(grammarAccess.getInstructionAccess().getVariableParserRuleCall_8()); 

                    }


                    }
                    break;
                case 10 :
                    // InternalMyDsl.g:893:2: ( ruleFunction )
                    {
                    // InternalMyDsl.g:893:2: ( ruleFunction )
                    // InternalMyDsl.g:894:3: ruleFunction
                    {
                     before(grammarAccess.getInstructionAccess().getFunctionParserRuleCall_9()); 
                    pushFollow(FOLLOW_2);
                    ruleFunction();

                    state._fsp--;

                     after(grammarAccess.getInstructionAccess().getFunctionParserRuleCall_9()); 

                    }


                    }
                    break;
                case 11 :
                    // InternalMyDsl.g:899:2: ( ruleCount )
                    {
                    // InternalMyDsl.g:899:2: ( ruleCount )
                    // InternalMyDsl.g:900:3: ruleCount
                    {
                     before(grammarAccess.getInstructionAccess().getCountParserRuleCall_10()); 
                    pushFollow(FOLLOW_2);
                    ruleCount();

                    state._fsp--;

                     after(grammarAccess.getInstructionAccess().getCountParserRuleCall_10()); 

                    }


                    }
                    break;
                case 12 :
                    // InternalMyDsl.g:905:2: ( ruleEqualsTo )
                    {
                    // InternalMyDsl.g:905:2: ( ruleEqualsTo )
                    // InternalMyDsl.g:906:3: ruleEqualsTo
                    {
                     before(grammarAccess.getInstructionAccess().getEqualsToParserRuleCall_11()); 
                    pushFollow(FOLLOW_2);
                    ruleEqualsTo();

                    state._fsp--;

                     after(grammarAccess.getInstructionAccess().getEqualsToParserRuleCall_11()); 

                    }


                    }
                    break;
                case 13 :
                    // InternalMyDsl.g:911:2: ( ruleCall )
                    {
                    // InternalMyDsl.g:911:2: ( ruleCall )
                    // InternalMyDsl.g:912:3: ruleCall
                    {
                     before(grammarAccess.getInstructionAccess().getCallParserRuleCall_12()); 
                    pushFollow(FOLLOW_2);
                    ruleCall();

                    state._fsp--;

                     after(grammarAccess.getInstructionAccess().getCallParserRuleCall_12()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Instruction__Alternatives"


    // $ANTLR start "rule__Uncheck__Alternatives_3"
    // InternalMyDsl.g:921:1: rule__Uncheck__Alternatives_3 : ( ( ( rule__Uncheck__OptionUncheckAssignment_3_0 )? ) | ( 'all' ) );
    public final void rule__Uncheck__Alternatives_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:925:1: ( ( ( rule__Uncheck__OptionUncheckAssignment_3_0 )? ) | ( 'all' ) )
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0==EOF||(LA4_0>=22 && LA4_0<=32)||LA4_0==34||LA4_0==36||(LA4_0>=38 && LA4_0<=39)) ) {
                alt4=1;
            }
            else if ( (LA4_0==21) ) {
                alt4=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 4, 0, input);

                throw nvae;
            }
            switch (alt4) {
                case 1 :
                    // InternalMyDsl.g:926:2: ( ( rule__Uncheck__OptionUncheckAssignment_3_0 )? )
                    {
                    // InternalMyDsl.g:926:2: ( ( rule__Uncheck__OptionUncheckAssignment_3_0 )? )
                    // InternalMyDsl.g:927:3: ( rule__Uncheck__OptionUncheckAssignment_3_0 )?
                    {
                     before(grammarAccess.getUncheckAccess().getOptionUncheckAssignment_3_0()); 
                    // InternalMyDsl.g:928:3: ( rule__Uncheck__OptionUncheckAssignment_3_0 )?
                    int alt3=2;
                    int LA3_0 = input.LA(1);

                    if ( (LA3_0==39) ) {
                        alt3=1;
                    }
                    switch (alt3) {
                        case 1 :
                            // InternalMyDsl.g:928:4: rule__Uncheck__OptionUncheckAssignment_3_0
                            {
                            pushFollow(FOLLOW_2);
                            rule__Uncheck__OptionUncheckAssignment_3_0();

                            state._fsp--;


                            }
                            break;

                    }

                     after(grammarAccess.getUncheckAccess().getOptionUncheckAssignment_3_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:932:2: ( 'all' )
                    {
                    // InternalMyDsl.g:932:2: ( 'all' )
                    // InternalMyDsl.g:933:3: 'all'
                    {
                     before(grammarAccess.getUncheckAccess().getAllKeyword_3_1()); 
                    match(input,21,FOLLOW_2); 
                     after(grammarAccess.getUncheckAccess().getAllKeyword_3_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Uncheck__Alternatives_3"


    // $ANTLR start "rule__Variable__ValAlternatives_3_0"
    // InternalMyDsl.g:942:1: rule__Variable__ValAlternatives_3_0 : ( ( ruleRead ) | ( ruleCount ) );
    public final void rule__Variable__ValAlternatives_3_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:946:1: ( ( ruleRead ) | ( ruleCount ) )
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==29) ) {
                alt5=1;
            }
            else if ( (LA5_0==30) ) {
                alt5=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 5, 0, input);

                throw nvae;
            }
            switch (alt5) {
                case 1 :
                    // InternalMyDsl.g:947:2: ( ruleRead )
                    {
                    // InternalMyDsl.g:947:2: ( ruleRead )
                    // InternalMyDsl.g:948:3: ruleRead
                    {
                     before(grammarAccess.getVariableAccess().getValReadParserRuleCall_3_0_0()); 
                    pushFollow(FOLLOW_2);
                    ruleRead();

                    state._fsp--;

                     after(grammarAccess.getVariableAccess().getValReadParserRuleCall_3_0_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:953:2: ( ruleCount )
                    {
                    // InternalMyDsl.g:953:2: ( ruleCount )
                    // InternalMyDsl.g:954:3: ruleCount
                    {
                     before(grammarAccess.getVariableAccess().getValCountParserRuleCall_3_0_1()); 
                    pushFollow(FOLLOW_2);
                    ruleCount();

                    state._fsp--;

                     after(grammarAccess.getVariableAccess().getValCountParserRuleCall_3_0_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Variable__ValAlternatives_3_0"


    // $ANTLR start "rule__Name__NameAlternatives_1_0"
    // InternalMyDsl.g:963:1: rule__Name__NameAlternatives_1_0 : ( ( RULE_STRING ) | ( RULE_ID ) );
    public final void rule__Name__NameAlternatives_1_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:967:1: ( ( RULE_STRING ) | ( RULE_ID ) )
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( (LA6_0==RULE_STRING) ) {
                alt6=1;
            }
            else if ( (LA6_0==RULE_ID) ) {
                alt6=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 6, 0, input);

                throw nvae;
            }
            switch (alt6) {
                case 1 :
                    // InternalMyDsl.g:968:2: ( RULE_STRING )
                    {
                    // InternalMyDsl.g:968:2: ( RULE_STRING )
                    // InternalMyDsl.g:969:3: RULE_STRING
                    {
                     before(grammarAccess.getNameAccess().getNameSTRINGTerminalRuleCall_1_0_0()); 
                    match(input,RULE_STRING,FOLLOW_2); 
                     after(grammarAccess.getNameAccess().getNameSTRINGTerminalRuleCall_1_0_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:974:2: ( RULE_ID )
                    {
                    // InternalMyDsl.g:974:2: ( RULE_ID )
                    // InternalMyDsl.g:975:3: RULE_ID
                    {
                     before(grammarAccess.getNameAccess().getNameIDTerminalRuleCall_1_0_1()); 
                    match(input,RULE_ID,FOLLOW_2); 
                     after(grammarAccess.getNameAccess().getNameIDTerminalRuleCall_1_0_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Name__NameAlternatives_1_0"


    // $ANTLR start "rule__Value__Alternatives_1"
    // InternalMyDsl.g:984:1: rule__Value__Alternatives_1 : ( ( ( rule__Value__StringAssignment_1_0 ) ) | ( ( rule__Value__IdAssignment_1_1 ) ) );
    public final void rule__Value__Alternatives_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:988:1: ( ( ( rule__Value__StringAssignment_1_0 ) ) | ( ( rule__Value__IdAssignment_1_1 ) ) )
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0==RULE_STRING) ) {
                alt7=1;
            }
            else if ( (LA7_0==RULE_ID) ) {
                alt7=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 7, 0, input);

                throw nvae;
            }
            switch (alt7) {
                case 1 :
                    // InternalMyDsl.g:989:2: ( ( rule__Value__StringAssignment_1_0 ) )
                    {
                    // InternalMyDsl.g:989:2: ( ( rule__Value__StringAssignment_1_0 ) )
                    // InternalMyDsl.g:990:3: ( rule__Value__StringAssignment_1_0 )
                    {
                     before(grammarAccess.getValueAccess().getStringAssignment_1_0()); 
                    // InternalMyDsl.g:991:3: ( rule__Value__StringAssignment_1_0 )
                    // InternalMyDsl.g:991:4: rule__Value__StringAssignment_1_0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Value__StringAssignment_1_0();

                    state._fsp--;


                    }

                     after(grammarAccess.getValueAccess().getStringAssignment_1_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:995:2: ( ( rule__Value__IdAssignment_1_1 ) )
                    {
                    // InternalMyDsl.g:995:2: ( ( rule__Value__IdAssignment_1_1 ) )
                    // InternalMyDsl.g:996:3: ( rule__Value__IdAssignment_1_1 )
                    {
                     before(grammarAccess.getValueAccess().getIdAssignment_1_1()); 
                    // InternalMyDsl.g:997:3: ( rule__Value__IdAssignment_1_1 )
                    // InternalMyDsl.g:997:4: rule__Value__IdAssignment_1_1
                    {
                    pushFollow(FOLLOW_2);
                    rule__Value__IdAssignment_1_1();

                    state._fsp--;


                    }

                     after(grammarAccess.getValueAccess().getIdAssignment_1_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Value__Alternatives_1"


    // $ANTLR start "rule__Parameter__Alternatives"
    // InternalMyDsl.g:1005:1: rule__Parameter__Alternatives : ( ( RULE_STRING ) | ( RULE_ID ) );
    public final void rule__Parameter__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1009:1: ( ( RULE_STRING ) | ( RULE_ID ) )
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==RULE_STRING) ) {
                alt8=1;
            }
            else if ( (LA8_0==RULE_ID) ) {
                alt8=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 8, 0, input);

                throw nvae;
            }
            switch (alt8) {
                case 1 :
                    // InternalMyDsl.g:1010:2: ( RULE_STRING )
                    {
                    // InternalMyDsl.g:1010:2: ( RULE_STRING )
                    // InternalMyDsl.g:1011:3: RULE_STRING
                    {
                     before(grammarAccess.getParameterAccess().getSTRINGTerminalRuleCall_0()); 
                    match(input,RULE_STRING,FOLLOW_2); 
                     after(grammarAccess.getParameterAccess().getSTRINGTerminalRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:1016:2: ( RULE_ID )
                    {
                    // InternalMyDsl.g:1016:2: ( RULE_ID )
                    // InternalMyDsl.g:1017:3: RULE_ID
                    {
                     before(grammarAccess.getParameterAccess().getIDTerminalRuleCall_1()); 
                    match(input,RULE_ID,FOLLOW_2); 
                     after(grammarAccess.getParameterAccess().getIDTerminalRuleCall_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Parameter__Alternatives"


    // $ANTLR start "rule__TypeElement__Alternatives"
    // InternalMyDsl.g:1026:1: rule__TypeElement__Alternatives : ( ( ruleTypeLink ) | ( ruleTypeImage ) | ( ruleTypeText ) | ( ruleTypeButton ) | ( ruleTypeTitle ) );
    public final void rule__TypeElement__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1030:1: ( ( ruleTypeLink ) | ( ruleTypeImage ) | ( ruleTypeText ) | ( ruleTypeButton ) | ( ruleTypeTitle ) )
            int alt9=5;
            switch ( input.LA(1) ) {
            case 12:
                {
                alt9=1;
                }
                break;
            case 13:
                {
                alt9=2;
                }
                break;
            case 14:
                {
                alt9=3;
                }
                break;
            case 15:
                {
                alt9=4;
                }
                break;
            case 18:
                {
                alt9=5;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 9, 0, input);

                throw nvae;
            }

            switch (alt9) {
                case 1 :
                    // InternalMyDsl.g:1031:2: ( ruleTypeLink )
                    {
                    // InternalMyDsl.g:1031:2: ( ruleTypeLink )
                    // InternalMyDsl.g:1032:3: ruleTypeLink
                    {
                     before(grammarAccess.getTypeElementAccess().getTypeLinkParserRuleCall_0()); 
                    pushFollow(FOLLOW_2);
                    ruleTypeLink();

                    state._fsp--;

                     after(grammarAccess.getTypeElementAccess().getTypeLinkParserRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:1037:2: ( ruleTypeImage )
                    {
                    // InternalMyDsl.g:1037:2: ( ruleTypeImage )
                    // InternalMyDsl.g:1038:3: ruleTypeImage
                    {
                     before(grammarAccess.getTypeElementAccess().getTypeImageParserRuleCall_1()); 
                    pushFollow(FOLLOW_2);
                    ruleTypeImage();

                    state._fsp--;

                     after(grammarAccess.getTypeElementAccess().getTypeImageParserRuleCall_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalMyDsl.g:1043:2: ( ruleTypeText )
                    {
                    // InternalMyDsl.g:1043:2: ( ruleTypeText )
                    // InternalMyDsl.g:1044:3: ruleTypeText
                    {
                     before(grammarAccess.getTypeElementAccess().getTypeTextParserRuleCall_2()); 
                    pushFollow(FOLLOW_2);
                    ruleTypeText();

                    state._fsp--;

                     after(grammarAccess.getTypeElementAccess().getTypeTextParserRuleCall_2()); 

                    }


                    }
                    break;
                case 4 :
                    // InternalMyDsl.g:1049:2: ( ruleTypeButton )
                    {
                    // InternalMyDsl.g:1049:2: ( ruleTypeButton )
                    // InternalMyDsl.g:1050:3: ruleTypeButton
                    {
                     before(grammarAccess.getTypeElementAccess().getTypeButtonParserRuleCall_3()); 
                    pushFollow(FOLLOW_2);
                    ruleTypeButton();

                    state._fsp--;

                     after(grammarAccess.getTypeElementAccess().getTypeButtonParserRuleCall_3()); 

                    }


                    }
                    break;
                case 5 :
                    // InternalMyDsl.g:1055:2: ( ruleTypeTitle )
                    {
                    // InternalMyDsl.g:1055:2: ( ruleTypeTitle )
                    // InternalMyDsl.g:1056:3: ruleTypeTitle
                    {
                     before(grammarAccess.getTypeElementAccess().getTypeTitleParserRuleCall_4()); 
                    pushFollow(FOLLOW_2);
                    ruleTypeTitle();

                    state._fsp--;

                     after(grammarAccess.getTypeElementAccess().getTypeTitleParserRuleCall_4()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TypeElement__Alternatives"


    // $ANTLR start "rule__TypeProperty__Alternatives"
    // InternalMyDsl.g:1065:1: rule__TypeProperty__Alternatives : ( ( ruleTypeUrl ) | ( ruleTypeText ) );
    public final void rule__TypeProperty__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1069:1: ( ( ruleTypeUrl ) | ( ruleTypeText ) )
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( (LA10_0==19) ) {
                alt10=1;
            }
            else if ( (LA10_0==14) ) {
                alt10=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 10, 0, input);

                throw nvae;
            }
            switch (alt10) {
                case 1 :
                    // InternalMyDsl.g:1070:2: ( ruleTypeUrl )
                    {
                    // InternalMyDsl.g:1070:2: ( ruleTypeUrl )
                    // InternalMyDsl.g:1071:3: ruleTypeUrl
                    {
                     before(grammarAccess.getTypePropertyAccess().getTypeUrlParserRuleCall_0()); 
                    pushFollow(FOLLOW_2);
                    ruleTypeUrl();

                    state._fsp--;

                     after(grammarAccess.getTypePropertyAccess().getTypeUrlParserRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:1076:2: ( ruleTypeText )
                    {
                    // InternalMyDsl.g:1076:2: ( ruleTypeText )
                    // InternalMyDsl.g:1077:3: ruleTypeText
                    {
                     before(grammarAccess.getTypePropertyAccess().getTypeTextParserRuleCall_1()); 
                    pushFollow(FOLLOW_2);
                    ruleTypeText();

                    state._fsp--;

                     after(grammarAccess.getTypePropertyAccess().getTypeTextParserRuleCall_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TypeProperty__Alternatives"


    // $ANTLR start "rule__TypeSet__Alternatives"
    // InternalMyDsl.g:1086:1: rule__TypeSet__Alternatives : ( ( ruleTypeInput ) | ( ruleTypeCombo ) );
    public final void rule__TypeSet__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1090:1: ( ( ruleTypeInput ) | ( ruleTypeCombo ) )
            int alt11=2;
            int LA11_0 = input.LA(1);

            if ( (LA11_0==16) ) {
                alt11=1;
            }
            else if ( (LA11_0==17) ) {
                alt11=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 11, 0, input);

                throw nvae;
            }
            switch (alt11) {
                case 1 :
                    // InternalMyDsl.g:1091:2: ( ruleTypeInput )
                    {
                    // InternalMyDsl.g:1091:2: ( ruleTypeInput )
                    // InternalMyDsl.g:1092:3: ruleTypeInput
                    {
                     before(grammarAccess.getTypeSetAccess().getTypeInputParserRuleCall_0()); 
                    pushFollow(FOLLOW_2);
                    ruleTypeInput();

                    state._fsp--;

                     after(grammarAccess.getTypeSetAccess().getTypeInputParserRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:1097:2: ( ruleTypeCombo )
                    {
                    // InternalMyDsl.g:1097:2: ( ruleTypeCombo )
                    // InternalMyDsl.g:1098:3: ruleTypeCombo
                    {
                     before(grammarAccess.getTypeSetAccess().getTypeComboParserRuleCall_1()); 
                    pushFollow(FOLLOW_2);
                    ruleTypeCombo();

                    state._fsp--;

                     after(grammarAccess.getTypeSetAccess().getTypeComboParserRuleCall_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TypeSet__Alternatives"


    // $ANTLR start "rule__OpenBrowser__Group__0"
    // InternalMyDsl.g:1107:1: rule__OpenBrowser__Group__0 : rule__OpenBrowser__Group__0__Impl rule__OpenBrowser__Group__1 ;
    public final void rule__OpenBrowser__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1111:1: ( rule__OpenBrowser__Group__0__Impl rule__OpenBrowser__Group__1 )
            // InternalMyDsl.g:1112:2: rule__OpenBrowser__Group__0__Impl rule__OpenBrowser__Group__1
            {
            pushFollow(FOLLOW_4);
            rule__OpenBrowser__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__OpenBrowser__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__OpenBrowser__Group__0"


    // $ANTLR start "rule__OpenBrowser__Group__0__Impl"
    // InternalMyDsl.g:1119:1: rule__OpenBrowser__Group__0__Impl : ( 'open browser on url' ) ;
    public final void rule__OpenBrowser__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1123:1: ( ( 'open browser on url' ) )
            // InternalMyDsl.g:1124:1: ( 'open browser on url' )
            {
            // InternalMyDsl.g:1124:1: ( 'open browser on url' )
            // InternalMyDsl.g:1125:2: 'open browser on url'
            {
             before(grammarAccess.getOpenBrowserAccess().getOpenBrowserOnUrlKeyword_0()); 
            match(input,22,FOLLOW_2); 
             after(grammarAccess.getOpenBrowserAccess().getOpenBrowserOnUrlKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__OpenBrowser__Group__0__Impl"


    // $ANTLR start "rule__OpenBrowser__Group__1"
    // InternalMyDsl.g:1134:1: rule__OpenBrowser__Group__1 : rule__OpenBrowser__Group__1__Impl ;
    public final void rule__OpenBrowser__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1138:1: ( rule__OpenBrowser__Group__1__Impl )
            // InternalMyDsl.g:1139:2: rule__OpenBrowser__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__OpenBrowser__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__OpenBrowser__Group__1"


    // $ANTLR start "rule__OpenBrowser__Group__1__Impl"
    // InternalMyDsl.g:1145:1: rule__OpenBrowser__Group__1__Impl : ( ( rule__OpenBrowser__UrlAssignment_1 ) ) ;
    public final void rule__OpenBrowser__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1149:1: ( ( ( rule__OpenBrowser__UrlAssignment_1 ) ) )
            // InternalMyDsl.g:1150:1: ( ( rule__OpenBrowser__UrlAssignment_1 ) )
            {
            // InternalMyDsl.g:1150:1: ( ( rule__OpenBrowser__UrlAssignment_1 ) )
            // InternalMyDsl.g:1151:2: ( rule__OpenBrowser__UrlAssignment_1 )
            {
             before(grammarAccess.getOpenBrowserAccess().getUrlAssignment_1()); 
            // InternalMyDsl.g:1152:2: ( rule__OpenBrowser__UrlAssignment_1 )
            // InternalMyDsl.g:1152:3: rule__OpenBrowser__UrlAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__OpenBrowser__UrlAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getOpenBrowserAccess().getUrlAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__OpenBrowser__Group__1__Impl"


    // $ANTLR start "rule__ChangeUrl__Group__0"
    // InternalMyDsl.g:1161:1: rule__ChangeUrl__Group__0 : rule__ChangeUrl__Group__0__Impl rule__ChangeUrl__Group__1 ;
    public final void rule__ChangeUrl__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1165:1: ( rule__ChangeUrl__Group__0__Impl rule__ChangeUrl__Group__1 )
            // InternalMyDsl.g:1166:2: rule__ChangeUrl__Group__0__Impl rule__ChangeUrl__Group__1
            {
            pushFollow(FOLLOW_4);
            rule__ChangeUrl__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ChangeUrl__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ChangeUrl__Group__0"


    // $ANTLR start "rule__ChangeUrl__Group__0__Impl"
    // InternalMyDsl.g:1173:1: rule__ChangeUrl__Group__0__Impl : ( 'change url' ) ;
    public final void rule__ChangeUrl__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1177:1: ( ( 'change url' ) )
            // InternalMyDsl.g:1178:1: ( 'change url' )
            {
            // InternalMyDsl.g:1178:1: ( 'change url' )
            // InternalMyDsl.g:1179:2: 'change url'
            {
             before(grammarAccess.getChangeUrlAccess().getChangeUrlKeyword_0()); 
            match(input,23,FOLLOW_2); 
             after(grammarAccess.getChangeUrlAccess().getChangeUrlKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ChangeUrl__Group__0__Impl"


    // $ANTLR start "rule__ChangeUrl__Group__1"
    // InternalMyDsl.g:1188:1: rule__ChangeUrl__Group__1 : rule__ChangeUrl__Group__1__Impl ;
    public final void rule__ChangeUrl__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1192:1: ( rule__ChangeUrl__Group__1__Impl )
            // InternalMyDsl.g:1193:2: rule__ChangeUrl__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ChangeUrl__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ChangeUrl__Group__1"


    // $ANTLR start "rule__ChangeUrl__Group__1__Impl"
    // InternalMyDsl.g:1199:1: rule__ChangeUrl__Group__1__Impl : ( ( rule__ChangeUrl__UrlAssignment_1 ) ) ;
    public final void rule__ChangeUrl__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1203:1: ( ( ( rule__ChangeUrl__UrlAssignment_1 ) ) )
            // InternalMyDsl.g:1204:1: ( ( rule__ChangeUrl__UrlAssignment_1 ) )
            {
            // InternalMyDsl.g:1204:1: ( ( rule__ChangeUrl__UrlAssignment_1 ) )
            // InternalMyDsl.g:1205:2: ( rule__ChangeUrl__UrlAssignment_1 )
            {
             before(grammarAccess.getChangeUrlAccess().getUrlAssignment_1()); 
            // InternalMyDsl.g:1206:2: ( rule__ChangeUrl__UrlAssignment_1 )
            // InternalMyDsl.g:1206:3: rule__ChangeUrl__UrlAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__ChangeUrl__UrlAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getChangeUrlAccess().getUrlAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ChangeUrl__Group__1__Impl"


    // $ANTLR start "rule__Contains__Group__0"
    // InternalMyDsl.g:1215:1: rule__Contains__Group__0 : rule__Contains__Group__0__Impl rule__Contains__Group__1 ;
    public final void rule__Contains__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1219:1: ( rule__Contains__Group__0__Impl rule__Contains__Group__1 )
            // InternalMyDsl.g:1220:2: rule__Contains__Group__0__Impl rule__Contains__Group__1
            {
            pushFollow(FOLLOW_5);
            rule__Contains__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Contains__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Contains__Group__0"


    // $ANTLR start "rule__Contains__Group__0__Impl"
    // InternalMyDsl.g:1227:1: rule__Contains__Group__0__Impl : ( 'contains' ) ;
    public final void rule__Contains__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1231:1: ( ( 'contains' ) )
            // InternalMyDsl.g:1232:1: ( 'contains' )
            {
            // InternalMyDsl.g:1232:1: ( 'contains' )
            // InternalMyDsl.g:1233:2: 'contains'
            {
             before(grammarAccess.getContainsAccess().getContainsKeyword_0()); 
            match(input,24,FOLLOW_2); 
             after(grammarAccess.getContainsAccess().getContainsKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Contains__Group__0__Impl"


    // $ANTLR start "rule__Contains__Group__1"
    // InternalMyDsl.g:1242:1: rule__Contains__Group__1 : rule__Contains__Group__1__Impl rule__Contains__Group__2 ;
    public final void rule__Contains__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1246:1: ( rule__Contains__Group__1__Impl rule__Contains__Group__2 )
            // InternalMyDsl.g:1247:2: rule__Contains__Group__1__Impl rule__Contains__Group__2
            {
            pushFollow(FOLLOW_6);
            rule__Contains__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Contains__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Contains__Group__1"


    // $ANTLR start "rule__Contains__Group__1__Impl"
    // InternalMyDsl.g:1254:1: rule__Contains__Group__1__Impl : ( ( rule__Contains__TypeAssignment_1 ) ) ;
    public final void rule__Contains__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1258:1: ( ( ( rule__Contains__TypeAssignment_1 ) ) )
            // InternalMyDsl.g:1259:1: ( ( rule__Contains__TypeAssignment_1 ) )
            {
            // InternalMyDsl.g:1259:1: ( ( rule__Contains__TypeAssignment_1 ) )
            // InternalMyDsl.g:1260:2: ( rule__Contains__TypeAssignment_1 )
            {
             before(grammarAccess.getContainsAccess().getTypeAssignment_1()); 
            // InternalMyDsl.g:1261:2: ( rule__Contains__TypeAssignment_1 )
            // InternalMyDsl.g:1261:3: rule__Contains__TypeAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Contains__TypeAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getContainsAccess().getTypeAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Contains__Group__1__Impl"


    // $ANTLR start "rule__Contains__Group__2"
    // InternalMyDsl.g:1269:1: rule__Contains__Group__2 : rule__Contains__Group__2__Impl ;
    public final void rule__Contains__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1273:1: ( rule__Contains__Group__2__Impl )
            // InternalMyDsl.g:1274:2: rule__Contains__Group__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Contains__Group__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Contains__Group__2"


    // $ANTLR start "rule__Contains__Group__2__Impl"
    // InternalMyDsl.g:1280:1: rule__Contains__Group__2__Impl : ( ( rule__Contains__ValeurAssignment_2 ) ) ;
    public final void rule__Contains__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1284:1: ( ( ( rule__Contains__ValeurAssignment_2 ) ) )
            // InternalMyDsl.g:1285:1: ( ( rule__Contains__ValeurAssignment_2 ) )
            {
            // InternalMyDsl.g:1285:1: ( ( rule__Contains__ValeurAssignment_2 ) )
            // InternalMyDsl.g:1286:2: ( rule__Contains__ValeurAssignment_2 )
            {
             before(grammarAccess.getContainsAccess().getValeurAssignment_2()); 
            // InternalMyDsl.g:1287:2: ( rule__Contains__ValeurAssignment_2 )
            // InternalMyDsl.g:1287:3: rule__Contains__ValeurAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__Contains__ValeurAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getContainsAccess().getValeurAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Contains__Group__2__Impl"


    // $ANTLR start "rule__Click__Group__0"
    // InternalMyDsl.g:1296:1: rule__Click__Group__0 : rule__Click__Group__0__Impl rule__Click__Group__1 ;
    public final void rule__Click__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1300:1: ( rule__Click__Group__0__Impl rule__Click__Group__1 )
            // InternalMyDsl.g:1301:2: rule__Click__Group__0__Impl rule__Click__Group__1
            {
            pushFollow(FOLLOW_5);
            rule__Click__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Click__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Click__Group__0"


    // $ANTLR start "rule__Click__Group__0__Impl"
    // InternalMyDsl.g:1308:1: rule__Click__Group__0__Impl : ( 'click' ) ;
    public final void rule__Click__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1312:1: ( ( 'click' ) )
            // InternalMyDsl.g:1313:1: ( 'click' )
            {
            // InternalMyDsl.g:1313:1: ( 'click' )
            // InternalMyDsl.g:1314:2: 'click'
            {
             before(grammarAccess.getClickAccess().getClickKeyword_0()); 
            match(input,25,FOLLOW_2); 
             after(grammarAccess.getClickAccess().getClickKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Click__Group__0__Impl"


    // $ANTLR start "rule__Click__Group__1"
    // InternalMyDsl.g:1323:1: rule__Click__Group__1 : rule__Click__Group__1__Impl rule__Click__Group__2 ;
    public final void rule__Click__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1327:1: ( rule__Click__Group__1__Impl rule__Click__Group__2 )
            // InternalMyDsl.g:1328:2: rule__Click__Group__1__Impl rule__Click__Group__2
            {
            pushFollow(FOLLOW_6);
            rule__Click__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Click__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Click__Group__1"


    // $ANTLR start "rule__Click__Group__1__Impl"
    // InternalMyDsl.g:1335:1: rule__Click__Group__1__Impl : ( ( rule__Click__TypeAssignment_1 ) ) ;
    public final void rule__Click__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1339:1: ( ( ( rule__Click__TypeAssignment_1 ) ) )
            // InternalMyDsl.g:1340:1: ( ( rule__Click__TypeAssignment_1 ) )
            {
            // InternalMyDsl.g:1340:1: ( ( rule__Click__TypeAssignment_1 ) )
            // InternalMyDsl.g:1341:2: ( rule__Click__TypeAssignment_1 )
            {
             before(grammarAccess.getClickAccess().getTypeAssignment_1()); 
            // InternalMyDsl.g:1342:2: ( rule__Click__TypeAssignment_1 )
            // InternalMyDsl.g:1342:3: rule__Click__TypeAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Click__TypeAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getClickAccess().getTypeAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Click__Group__1__Impl"


    // $ANTLR start "rule__Click__Group__2"
    // InternalMyDsl.g:1350:1: rule__Click__Group__2 : rule__Click__Group__2__Impl ;
    public final void rule__Click__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1354:1: ( rule__Click__Group__2__Impl )
            // InternalMyDsl.g:1355:2: rule__Click__Group__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Click__Group__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Click__Group__2"


    // $ANTLR start "rule__Click__Group__2__Impl"
    // InternalMyDsl.g:1361:1: rule__Click__Group__2__Impl : ( ( rule__Click__ValeurAssignment_2 ) ) ;
    public final void rule__Click__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1365:1: ( ( ( rule__Click__ValeurAssignment_2 ) ) )
            // InternalMyDsl.g:1366:1: ( ( rule__Click__ValeurAssignment_2 ) )
            {
            // InternalMyDsl.g:1366:1: ( ( rule__Click__ValeurAssignment_2 ) )
            // InternalMyDsl.g:1367:2: ( rule__Click__ValeurAssignment_2 )
            {
             before(grammarAccess.getClickAccess().getValeurAssignment_2()); 
            // InternalMyDsl.g:1368:2: ( rule__Click__ValeurAssignment_2 )
            // InternalMyDsl.g:1368:3: rule__Click__ValeurAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__Click__ValeurAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getClickAccess().getValeurAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Click__Group__2__Impl"


    // $ANTLR start "rule__Set__Group__0"
    // InternalMyDsl.g:1377:1: rule__Set__Group__0 : rule__Set__Group__0__Impl rule__Set__Group__1 ;
    public final void rule__Set__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1381:1: ( rule__Set__Group__0__Impl rule__Set__Group__1 )
            // InternalMyDsl.g:1382:2: rule__Set__Group__0__Impl rule__Set__Group__1
            {
            pushFollow(FOLLOW_7);
            rule__Set__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Set__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Set__Group__0"


    // $ANTLR start "rule__Set__Group__0__Impl"
    // InternalMyDsl.g:1389:1: rule__Set__Group__0__Impl : ( 'set' ) ;
    public final void rule__Set__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1393:1: ( ( 'set' ) )
            // InternalMyDsl.g:1394:1: ( 'set' )
            {
            // InternalMyDsl.g:1394:1: ( 'set' )
            // InternalMyDsl.g:1395:2: 'set'
            {
             before(grammarAccess.getSetAccess().getSetKeyword_0()); 
            match(input,26,FOLLOW_2); 
             after(grammarAccess.getSetAccess().getSetKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Set__Group__0__Impl"


    // $ANTLR start "rule__Set__Group__1"
    // InternalMyDsl.g:1404:1: rule__Set__Group__1 : rule__Set__Group__1__Impl rule__Set__Group__2 ;
    public final void rule__Set__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1408:1: ( rule__Set__Group__1__Impl rule__Set__Group__2 )
            // InternalMyDsl.g:1409:2: rule__Set__Group__1__Impl rule__Set__Group__2
            {
            pushFollow(FOLLOW_6);
            rule__Set__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Set__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Set__Group__1"


    // $ANTLR start "rule__Set__Group__1__Impl"
    // InternalMyDsl.g:1416:1: rule__Set__Group__1__Impl : ( ( rule__Set__TypeAssignment_1 ) ) ;
    public final void rule__Set__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1420:1: ( ( ( rule__Set__TypeAssignment_1 ) ) )
            // InternalMyDsl.g:1421:1: ( ( rule__Set__TypeAssignment_1 ) )
            {
            // InternalMyDsl.g:1421:1: ( ( rule__Set__TypeAssignment_1 ) )
            // InternalMyDsl.g:1422:2: ( rule__Set__TypeAssignment_1 )
            {
             before(grammarAccess.getSetAccess().getTypeAssignment_1()); 
            // InternalMyDsl.g:1423:2: ( rule__Set__TypeAssignment_1 )
            // InternalMyDsl.g:1423:3: rule__Set__TypeAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Set__TypeAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getSetAccess().getTypeAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Set__Group__1__Impl"


    // $ANTLR start "rule__Set__Group__2"
    // InternalMyDsl.g:1431:1: rule__Set__Group__2 : rule__Set__Group__2__Impl rule__Set__Group__3 ;
    public final void rule__Set__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1435:1: ( rule__Set__Group__2__Impl rule__Set__Group__3 )
            // InternalMyDsl.g:1436:2: rule__Set__Group__2__Impl rule__Set__Group__3
            {
            pushFollow(FOLLOW_8);
            rule__Set__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Set__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Set__Group__2"


    // $ANTLR start "rule__Set__Group__2__Impl"
    // InternalMyDsl.g:1443:1: rule__Set__Group__2__Impl : ( ( rule__Set__NameAssignment_2 ) ) ;
    public final void rule__Set__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1447:1: ( ( ( rule__Set__NameAssignment_2 ) ) )
            // InternalMyDsl.g:1448:1: ( ( rule__Set__NameAssignment_2 ) )
            {
            // InternalMyDsl.g:1448:1: ( ( rule__Set__NameAssignment_2 ) )
            // InternalMyDsl.g:1449:2: ( rule__Set__NameAssignment_2 )
            {
             before(grammarAccess.getSetAccess().getNameAssignment_2()); 
            // InternalMyDsl.g:1450:2: ( rule__Set__NameAssignment_2 )
            // InternalMyDsl.g:1450:3: rule__Set__NameAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__Set__NameAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getSetAccess().getNameAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Set__Group__2__Impl"


    // $ANTLR start "rule__Set__Group__3"
    // InternalMyDsl.g:1458:1: rule__Set__Group__3 : rule__Set__Group__3__Impl ;
    public final void rule__Set__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1462:1: ( rule__Set__Group__3__Impl )
            // InternalMyDsl.g:1463:2: rule__Set__Group__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Set__Group__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Set__Group__3"


    // $ANTLR start "rule__Set__Group__3__Impl"
    // InternalMyDsl.g:1469:1: rule__Set__Group__3__Impl : ( ( rule__Set__ValueAssignment_3 ) ) ;
    public final void rule__Set__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1473:1: ( ( ( rule__Set__ValueAssignment_3 ) ) )
            // InternalMyDsl.g:1474:1: ( ( rule__Set__ValueAssignment_3 ) )
            {
            // InternalMyDsl.g:1474:1: ( ( rule__Set__ValueAssignment_3 ) )
            // InternalMyDsl.g:1475:2: ( rule__Set__ValueAssignment_3 )
            {
             before(grammarAccess.getSetAccess().getValueAssignment_3()); 
            // InternalMyDsl.g:1476:2: ( rule__Set__ValueAssignment_3 )
            // InternalMyDsl.g:1476:3: rule__Set__ValueAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__Set__ValueAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getSetAccess().getValueAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Set__Group__3__Impl"


    // $ANTLR start "rule__Check__Group__0"
    // InternalMyDsl.g:1485:1: rule__Check__Group__0 : rule__Check__Group__0__Impl rule__Check__Group__1 ;
    public final void rule__Check__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1489:1: ( rule__Check__Group__0__Impl rule__Check__Group__1 )
            // InternalMyDsl.g:1490:2: rule__Check__Group__0__Impl rule__Check__Group__1
            {
            pushFollow(FOLLOW_9);
            rule__Check__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Check__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Check__Group__0"


    // $ANTLR start "rule__Check__Group__0__Impl"
    // InternalMyDsl.g:1497:1: rule__Check__Group__0__Impl : ( 'check' ) ;
    public final void rule__Check__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1501:1: ( ( 'check' ) )
            // InternalMyDsl.g:1502:1: ( 'check' )
            {
            // InternalMyDsl.g:1502:1: ( 'check' )
            // InternalMyDsl.g:1503:2: 'check'
            {
             before(grammarAccess.getCheckAccess().getCheckKeyword_0()); 
            match(input,27,FOLLOW_2); 
             after(grammarAccess.getCheckAccess().getCheckKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Check__Group__0__Impl"


    // $ANTLR start "rule__Check__Group__1"
    // InternalMyDsl.g:1512:1: rule__Check__Group__1 : rule__Check__Group__1__Impl rule__Check__Group__2 ;
    public final void rule__Check__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1516:1: ( rule__Check__Group__1__Impl rule__Check__Group__2 )
            // InternalMyDsl.g:1517:2: rule__Check__Group__1__Impl rule__Check__Group__2
            {
            pushFollow(FOLLOW_6);
            rule__Check__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Check__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Check__Group__1"


    // $ANTLR start "rule__Check__Group__1__Impl"
    // InternalMyDsl.g:1524:1: rule__Check__Group__1__Impl : ( ruleTypeCheckBox ) ;
    public final void rule__Check__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1528:1: ( ( ruleTypeCheckBox ) )
            // InternalMyDsl.g:1529:1: ( ruleTypeCheckBox )
            {
            // InternalMyDsl.g:1529:1: ( ruleTypeCheckBox )
            // InternalMyDsl.g:1530:2: ruleTypeCheckBox
            {
             before(grammarAccess.getCheckAccess().getTypeCheckBoxParserRuleCall_1()); 
            pushFollow(FOLLOW_2);
            ruleTypeCheckBox();

            state._fsp--;

             after(grammarAccess.getCheckAccess().getTypeCheckBoxParserRuleCall_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Check__Group__1__Impl"


    // $ANTLR start "rule__Check__Group__2"
    // InternalMyDsl.g:1539:1: rule__Check__Group__2 : rule__Check__Group__2__Impl ;
    public final void rule__Check__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1543:1: ( rule__Check__Group__2__Impl )
            // InternalMyDsl.g:1544:2: rule__Check__Group__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Check__Group__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Check__Group__2"


    // $ANTLR start "rule__Check__Group__2__Impl"
    // InternalMyDsl.g:1550:1: rule__Check__Group__2__Impl : ( ( rule__Check__OptionCheckAssignment_2 ) ) ;
    public final void rule__Check__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1554:1: ( ( ( rule__Check__OptionCheckAssignment_2 ) ) )
            // InternalMyDsl.g:1555:1: ( ( rule__Check__OptionCheckAssignment_2 ) )
            {
            // InternalMyDsl.g:1555:1: ( ( rule__Check__OptionCheckAssignment_2 ) )
            // InternalMyDsl.g:1556:2: ( rule__Check__OptionCheckAssignment_2 )
            {
             before(grammarAccess.getCheckAccess().getOptionCheckAssignment_2()); 
            // InternalMyDsl.g:1557:2: ( rule__Check__OptionCheckAssignment_2 )
            // InternalMyDsl.g:1557:3: rule__Check__OptionCheckAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__Check__OptionCheckAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getCheckAccess().getOptionCheckAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Check__Group__2__Impl"


    // $ANTLR start "rule__Uncheck__Group__0"
    // InternalMyDsl.g:1566:1: rule__Uncheck__Group__0 : rule__Uncheck__Group__0__Impl rule__Uncheck__Group__1 ;
    public final void rule__Uncheck__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1570:1: ( rule__Uncheck__Group__0__Impl rule__Uncheck__Group__1 )
            // InternalMyDsl.g:1571:2: rule__Uncheck__Group__0__Impl rule__Uncheck__Group__1
            {
            pushFollow(FOLLOW_10);
            rule__Uncheck__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Uncheck__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Uncheck__Group__0"


    // $ANTLR start "rule__Uncheck__Group__0__Impl"
    // InternalMyDsl.g:1578:1: rule__Uncheck__Group__0__Impl : ( () ) ;
    public final void rule__Uncheck__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1582:1: ( ( () ) )
            // InternalMyDsl.g:1583:1: ( () )
            {
            // InternalMyDsl.g:1583:1: ( () )
            // InternalMyDsl.g:1584:2: ()
            {
             before(grammarAccess.getUncheckAccess().getUncheckAction_0()); 
            // InternalMyDsl.g:1585:2: ()
            // InternalMyDsl.g:1585:3: 
            {
            }

             after(grammarAccess.getUncheckAccess().getUncheckAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Uncheck__Group__0__Impl"


    // $ANTLR start "rule__Uncheck__Group__1"
    // InternalMyDsl.g:1593:1: rule__Uncheck__Group__1 : rule__Uncheck__Group__1__Impl rule__Uncheck__Group__2 ;
    public final void rule__Uncheck__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1597:1: ( rule__Uncheck__Group__1__Impl rule__Uncheck__Group__2 )
            // InternalMyDsl.g:1598:2: rule__Uncheck__Group__1__Impl rule__Uncheck__Group__2
            {
            pushFollow(FOLLOW_9);
            rule__Uncheck__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Uncheck__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Uncheck__Group__1"


    // $ANTLR start "rule__Uncheck__Group__1__Impl"
    // InternalMyDsl.g:1605:1: rule__Uncheck__Group__1__Impl : ( 'uncheck' ) ;
    public final void rule__Uncheck__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1609:1: ( ( 'uncheck' ) )
            // InternalMyDsl.g:1610:1: ( 'uncheck' )
            {
            // InternalMyDsl.g:1610:1: ( 'uncheck' )
            // InternalMyDsl.g:1611:2: 'uncheck'
            {
             before(grammarAccess.getUncheckAccess().getUncheckKeyword_1()); 
            match(input,28,FOLLOW_2); 
             after(grammarAccess.getUncheckAccess().getUncheckKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Uncheck__Group__1__Impl"


    // $ANTLR start "rule__Uncheck__Group__2"
    // InternalMyDsl.g:1620:1: rule__Uncheck__Group__2 : rule__Uncheck__Group__2__Impl rule__Uncheck__Group__3 ;
    public final void rule__Uncheck__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1624:1: ( rule__Uncheck__Group__2__Impl rule__Uncheck__Group__3 )
            // InternalMyDsl.g:1625:2: rule__Uncheck__Group__2__Impl rule__Uncheck__Group__3
            {
            pushFollow(FOLLOW_11);
            rule__Uncheck__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Uncheck__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Uncheck__Group__2"


    // $ANTLR start "rule__Uncheck__Group__2__Impl"
    // InternalMyDsl.g:1632:1: rule__Uncheck__Group__2__Impl : ( ruleTypeCheckBox ) ;
    public final void rule__Uncheck__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1636:1: ( ( ruleTypeCheckBox ) )
            // InternalMyDsl.g:1637:1: ( ruleTypeCheckBox )
            {
            // InternalMyDsl.g:1637:1: ( ruleTypeCheckBox )
            // InternalMyDsl.g:1638:2: ruleTypeCheckBox
            {
             before(grammarAccess.getUncheckAccess().getTypeCheckBoxParserRuleCall_2()); 
            pushFollow(FOLLOW_2);
            ruleTypeCheckBox();

            state._fsp--;

             after(grammarAccess.getUncheckAccess().getTypeCheckBoxParserRuleCall_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Uncheck__Group__2__Impl"


    // $ANTLR start "rule__Uncheck__Group__3"
    // InternalMyDsl.g:1647:1: rule__Uncheck__Group__3 : rule__Uncheck__Group__3__Impl ;
    public final void rule__Uncheck__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1651:1: ( rule__Uncheck__Group__3__Impl )
            // InternalMyDsl.g:1652:2: rule__Uncheck__Group__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Uncheck__Group__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Uncheck__Group__3"


    // $ANTLR start "rule__Uncheck__Group__3__Impl"
    // InternalMyDsl.g:1658:1: rule__Uncheck__Group__3__Impl : ( ( rule__Uncheck__Alternatives_3 ) ) ;
    public final void rule__Uncheck__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1662:1: ( ( ( rule__Uncheck__Alternatives_3 ) ) )
            // InternalMyDsl.g:1663:1: ( ( rule__Uncheck__Alternatives_3 ) )
            {
            // InternalMyDsl.g:1663:1: ( ( rule__Uncheck__Alternatives_3 ) )
            // InternalMyDsl.g:1664:2: ( rule__Uncheck__Alternatives_3 )
            {
             before(grammarAccess.getUncheckAccess().getAlternatives_3()); 
            // InternalMyDsl.g:1665:2: ( rule__Uncheck__Alternatives_3 )
            // InternalMyDsl.g:1665:3: rule__Uncheck__Alternatives_3
            {
            pushFollow(FOLLOW_2);
            rule__Uncheck__Alternatives_3();

            state._fsp--;


            }

             after(grammarAccess.getUncheckAccess().getAlternatives_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Uncheck__Group__3__Impl"


    // $ANTLR start "rule__Read__Group__0"
    // InternalMyDsl.g:1674:1: rule__Read__Group__0 : rule__Read__Group__0__Impl rule__Read__Group__1 ;
    public final void rule__Read__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1678:1: ( rule__Read__Group__0__Impl rule__Read__Group__1 )
            // InternalMyDsl.g:1679:2: rule__Read__Group__0__Impl rule__Read__Group__1
            {
            pushFollow(FOLLOW_12);
            rule__Read__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Read__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Read__Group__0"


    // $ANTLR start "rule__Read__Group__0__Impl"
    // InternalMyDsl.g:1686:1: rule__Read__Group__0__Impl : ( 'read' ) ;
    public final void rule__Read__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1690:1: ( ( 'read' ) )
            // InternalMyDsl.g:1691:1: ( 'read' )
            {
            // InternalMyDsl.g:1691:1: ( 'read' )
            // InternalMyDsl.g:1692:2: 'read'
            {
             before(grammarAccess.getReadAccess().getReadKeyword_0()); 
            match(input,29,FOLLOW_2); 
             after(grammarAccess.getReadAccess().getReadKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Read__Group__0__Impl"


    // $ANTLR start "rule__Read__Group__1"
    // InternalMyDsl.g:1701:1: rule__Read__Group__1 : rule__Read__Group__1__Impl rule__Read__Group__2 ;
    public final void rule__Read__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1705:1: ( rule__Read__Group__1__Impl rule__Read__Group__2 )
            // InternalMyDsl.g:1706:2: rule__Read__Group__1__Impl rule__Read__Group__2
            {
            pushFollow(FOLLOW_13);
            rule__Read__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Read__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Read__Group__1"


    // $ANTLR start "rule__Read__Group__1__Impl"
    // InternalMyDsl.g:1713:1: rule__Read__Group__1__Impl : ( ( rule__Read__TypeAssignment_1 ) ) ;
    public final void rule__Read__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1717:1: ( ( ( rule__Read__TypeAssignment_1 ) ) )
            // InternalMyDsl.g:1718:1: ( ( rule__Read__TypeAssignment_1 ) )
            {
            // InternalMyDsl.g:1718:1: ( ( rule__Read__TypeAssignment_1 ) )
            // InternalMyDsl.g:1719:2: ( rule__Read__TypeAssignment_1 )
            {
             before(grammarAccess.getReadAccess().getTypeAssignment_1()); 
            // InternalMyDsl.g:1720:2: ( rule__Read__TypeAssignment_1 )
            // InternalMyDsl.g:1720:3: rule__Read__TypeAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Read__TypeAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getReadAccess().getTypeAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Read__Group__1__Impl"


    // $ANTLR start "rule__Read__Group__2"
    // InternalMyDsl.g:1728:1: rule__Read__Group__2 : rule__Read__Group__2__Impl rule__Read__Group__3 ;
    public final void rule__Read__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1732:1: ( rule__Read__Group__2__Impl rule__Read__Group__3 )
            // InternalMyDsl.g:1733:2: rule__Read__Group__2__Impl rule__Read__Group__3
            {
            pushFollow(FOLLOW_6);
            rule__Read__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Read__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Read__Group__2"


    // $ANTLR start "rule__Read__Group__2__Impl"
    // InternalMyDsl.g:1740:1: rule__Read__Group__2__Impl : ( ruleOfTitle ) ;
    public final void rule__Read__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1744:1: ( ( ruleOfTitle ) )
            // InternalMyDsl.g:1745:1: ( ruleOfTitle )
            {
            // InternalMyDsl.g:1745:1: ( ruleOfTitle )
            // InternalMyDsl.g:1746:2: ruleOfTitle
            {
             before(grammarAccess.getReadAccess().getOfTitleParserRuleCall_2()); 
            pushFollow(FOLLOW_2);
            ruleOfTitle();

            state._fsp--;

             after(grammarAccess.getReadAccess().getOfTitleParserRuleCall_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Read__Group__2__Impl"


    // $ANTLR start "rule__Read__Group__3"
    // InternalMyDsl.g:1755:1: rule__Read__Group__3 : rule__Read__Group__3__Impl ;
    public final void rule__Read__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1759:1: ( rule__Read__Group__3__Impl )
            // InternalMyDsl.g:1760:2: rule__Read__Group__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Read__Group__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Read__Group__3"


    // $ANTLR start "rule__Read__Group__3__Impl"
    // InternalMyDsl.g:1766:1: rule__Read__Group__3__Impl : ( ( rule__Read__NameAssignment_3 ) ) ;
    public final void rule__Read__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1770:1: ( ( ( rule__Read__NameAssignment_3 ) ) )
            // InternalMyDsl.g:1771:1: ( ( rule__Read__NameAssignment_3 ) )
            {
            // InternalMyDsl.g:1771:1: ( ( rule__Read__NameAssignment_3 ) )
            // InternalMyDsl.g:1772:2: ( rule__Read__NameAssignment_3 )
            {
             before(grammarAccess.getReadAccess().getNameAssignment_3()); 
            // InternalMyDsl.g:1773:2: ( rule__Read__NameAssignment_3 )
            // InternalMyDsl.g:1773:3: rule__Read__NameAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__Read__NameAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getReadAccess().getNameAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Read__Group__3__Impl"


    // $ANTLR start "rule__Count__Group__0"
    // InternalMyDsl.g:1782:1: rule__Count__Group__0 : rule__Count__Group__0__Impl rule__Count__Group__1 ;
    public final void rule__Count__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1786:1: ( rule__Count__Group__0__Impl rule__Count__Group__1 )
            // InternalMyDsl.g:1787:2: rule__Count__Group__0__Impl rule__Count__Group__1
            {
            pushFollow(FOLLOW_5);
            rule__Count__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Count__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Count__Group__0"


    // $ANTLR start "rule__Count__Group__0__Impl"
    // InternalMyDsl.g:1794:1: rule__Count__Group__0__Impl : ( 'count' ) ;
    public final void rule__Count__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1798:1: ( ( 'count' ) )
            // InternalMyDsl.g:1799:1: ( 'count' )
            {
            // InternalMyDsl.g:1799:1: ( 'count' )
            // InternalMyDsl.g:1800:2: 'count'
            {
             before(grammarAccess.getCountAccess().getCountKeyword_0()); 
            match(input,30,FOLLOW_2); 
             after(grammarAccess.getCountAccess().getCountKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Count__Group__0__Impl"


    // $ANTLR start "rule__Count__Group__1"
    // InternalMyDsl.g:1809:1: rule__Count__Group__1 : rule__Count__Group__1__Impl rule__Count__Group__2 ;
    public final void rule__Count__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1813:1: ( rule__Count__Group__1__Impl rule__Count__Group__2 )
            // InternalMyDsl.g:1814:2: rule__Count__Group__1__Impl rule__Count__Group__2
            {
            pushFollow(FOLLOW_6);
            rule__Count__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Count__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Count__Group__1"


    // $ANTLR start "rule__Count__Group__1__Impl"
    // InternalMyDsl.g:1821:1: rule__Count__Group__1__Impl : ( ruleTypeElement ) ;
    public final void rule__Count__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1825:1: ( ( ruleTypeElement ) )
            // InternalMyDsl.g:1826:1: ( ruleTypeElement )
            {
            // InternalMyDsl.g:1826:1: ( ruleTypeElement )
            // InternalMyDsl.g:1827:2: ruleTypeElement
            {
             before(grammarAccess.getCountAccess().getTypeElementParserRuleCall_1()); 
            pushFollow(FOLLOW_2);
            ruleTypeElement();

            state._fsp--;

             after(grammarAccess.getCountAccess().getTypeElementParserRuleCall_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Count__Group__1__Impl"


    // $ANTLR start "rule__Count__Group__2"
    // InternalMyDsl.g:1836:1: rule__Count__Group__2 : rule__Count__Group__2__Impl ;
    public final void rule__Count__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1840:1: ( rule__Count__Group__2__Impl )
            // InternalMyDsl.g:1841:2: rule__Count__Group__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Count__Group__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Count__Group__2"


    // $ANTLR start "rule__Count__Group__2__Impl"
    // InternalMyDsl.g:1847:1: rule__Count__Group__2__Impl : ( ruleName ) ;
    public final void rule__Count__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1851:1: ( ( ruleName ) )
            // InternalMyDsl.g:1852:1: ( ruleName )
            {
            // InternalMyDsl.g:1852:1: ( ruleName )
            // InternalMyDsl.g:1853:2: ruleName
            {
             before(grammarAccess.getCountAccess().getNameParserRuleCall_2()); 
            pushFollow(FOLLOW_2);
            ruleName();

            state._fsp--;

             after(grammarAccess.getCountAccess().getNameParserRuleCall_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Count__Group__2__Impl"


    // $ANTLR start "rule__EqualsTo__Group__0"
    // InternalMyDsl.g:1863:1: rule__EqualsTo__Group__0 : rule__EqualsTo__Group__0__Impl rule__EqualsTo__Group__1 ;
    public final void rule__EqualsTo__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1867:1: ( rule__EqualsTo__Group__0__Impl rule__EqualsTo__Group__1 )
            // InternalMyDsl.g:1868:2: rule__EqualsTo__Group__0__Impl rule__EqualsTo__Group__1
            {
            pushFollow(FOLLOW_14);
            rule__EqualsTo__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__EqualsTo__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EqualsTo__Group__0"


    // $ANTLR start "rule__EqualsTo__Group__0__Impl"
    // InternalMyDsl.g:1875:1: rule__EqualsTo__Group__0__Impl : ( 'equals to' ) ;
    public final void rule__EqualsTo__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1879:1: ( ( 'equals to' ) )
            // InternalMyDsl.g:1880:1: ( 'equals to' )
            {
            // InternalMyDsl.g:1880:1: ( 'equals to' )
            // InternalMyDsl.g:1881:2: 'equals to'
            {
             before(grammarAccess.getEqualsToAccess().getEqualsToKeyword_0()); 
            match(input,31,FOLLOW_2); 
             after(grammarAccess.getEqualsToAccess().getEqualsToKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EqualsTo__Group__0__Impl"


    // $ANTLR start "rule__EqualsTo__Group__1"
    // InternalMyDsl.g:1890:1: rule__EqualsTo__Group__1 : rule__EqualsTo__Group__1__Impl rule__EqualsTo__Group__2 ;
    public final void rule__EqualsTo__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1894:1: ( rule__EqualsTo__Group__1__Impl rule__EqualsTo__Group__2 )
            // InternalMyDsl.g:1895:2: rule__EqualsTo__Group__1__Impl rule__EqualsTo__Group__2
            {
            pushFollow(FOLLOW_14);
            rule__EqualsTo__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__EqualsTo__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EqualsTo__Group__1"


    // $ANTLR start "rule__EqualsTo__Group__1__Impl"
    // InternalMyDsl.g:1902:1: rule__EqualsTo__Group__1__Impl : ( ( rule__EqualsTo__Elmt1Assignment_1 ) ) ;
    public final void rule__EqualsTo__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1906:1: ( ( ( rule__EqualsTo__Elmt1Assignment_1 ) ) )
            // InternalMyDsl.g:1907:1: ( ( rule__EqualsTo__Elmt1Assignment_1 ) )
            {
            // InternalMyDsl.g:1907:1: ( ( rule__EqualsTo__Elmt1Assignment_1 ) )
            // InternalMyDsl.g:1908:2: ( rule__EqualsTo__Elmt1Assignment_1 )
            {
             before(grammarAccess.getEqualsToAccess().getElmt1Assignment_1()); 
            // InternalMyDsl.g:1909:2: ( rule__EqualsTo__Elmt1Assignment_1 )
            // InternalMyDsl.g:1909:3: rule__EqualsTo__Elmt1Assignment_1
            {
            pushFollow(FOLLOW_2);
            rule__EqualsTo__Elmt1Assignment_1();

            state._fsp--;


            }

             after(grammarAccess.getEqualsToAccess().getElmt1Assignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EqualsTo__Group__1__Impl"


    // $ANTLR start "rule__EqualsTo__Group__2"
    // InternalMyDsl.g:1917:1: rule__EqualsTo__Group__2 : rule__EqualsTo__Group__2__Impl ;
    public final void rule__EqualsTo__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1921:1: ( rule__EqualsTo__Group__2__Impl )
            // InternalMyDsl.g:1922:2: rule__EqualsTo__Group__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__EqualsTo__Group__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EqualsTo__Group__2"


    // $ANTLR start "rule__EqualsTo__Group__2__Impl"
    // InternalMyDsl.g:1928:1: rule__EqualsTo__Group__2__Impl : ( ( rule__EqualsTo__Elmt2Assignment_2 ) ) ;
    public final void rule__EqualsTo__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1932:1: ( ( ( rule__EqualsTo__Elmt2Assignment_2 ) ) )
            // InternalMyDsl.g:1933:1: ( ( rule__EqualsTo__Elmt2Assignment_2 ) )
            {
            // InternalMyDsl.g:1933:1: ( ( rule__EqualsTo__Elmt2Assignment_2 ) )
            // InternalMyDsl.g:1934:2: ( rule__EqualsTo__Elmt2Assignment_2 )
            {
             before(grammarAccess.getEqualsToAccess().getElmt2Assignment_2()); 
            // InternalMyDsl.g:1935:2: ( rule__EqualsTo__Elmt2Assignment_2 )
            // InternalMyDsl.g:1935:3: rule__EqualsTo__Elmt2Assignment_2
            {
            pushFollow(FOLLOW_2);
            rule__EqualsTo__Elmt2Assignment_2();

            state._fsp--;


            }

             after(grammarAccess.getEqualsToAccess().getElmt2Assignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EqualsTo__Group__2__Impl"


    // $ANTLR start "rule__Variable__Group__0"
    // InternalMyDsl.g:1944:1: rule__Variable__Group__0 : rule__Variable__Group__0__Impl rule__Variable__Group__1 ;
    public final void rule__Variable__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1948:1: ( rule__Variable__Group__0__Impl rule__Variable__Group__1 )
            // InternalMyDsl.g:1949:2: rule__Variable__Group__0__Impl rule__Variable__Group__1
            {
            pushFollow(FOLLOW_14);
            rule__Variable__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Variable__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Variable__Group__0"


    // $ANTLR start "rule__Variable__Group__0__Impl"
    // InternalMyDsl.g:1956:1: rule__Variable__Group__0__Impl : ( 'var' ) ;
    public final void rule__Variable__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1960:1: ( ( 'var' ) )
            // InternalMyDsl.g:1961:1: ( 'var' )
            {
            // InternalMyDsl.g:1961:1: ( 'var' )
            // InternalMyDsl.g:1962:2: 'var'
            {
             before(grammarAccess.getVariableAccess().getVarKeyword_0()); 
            match(input,32,FOLLOW_2); 
             after(grammarAccess.getVariableAccess().getVarKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Variable__Group__0__Impl"


    // $ANTLR start "rule__Variable__Group__1"
    // InternalMyDsl.g:1971:1: rule__Variable__Group__1 : rule__Variable__Group__1__Impl rule__Variable__Group__2 ;
    public final void rule__Variable__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1975:1: ( rule__Variable__Group__1__Impl rule__Variable__Group__2 )
            // InternalMyDsl.g:1976:2: rule__Variable__Group__1__Impl rule__Variable__Group__2
            {
            pushFollow(FOLLOW_15);
            rule__Variable__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Variable__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Variable__Group__1"


    // $ANTLR start "rule__Variable__Group__1__Impl"
    // InternalMyDsl.g:1983:1: rule__Variable__Group__1__Impl : ( ( rule__Variable__NameAssignment_1 ) ) ;
    public final void rule__Variable__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1987:1: ( ( ( rule__Variable__NameAssignment_1 ) ) )
            // InternalMyDsl.g:1988:1: ( ( rule__Variable__NameAssignment_1 ) )
            {
            // InternalMyDsl.g:1988:1: ( ( rule__Variable__NameAssignment_1 ) )
            // InternalMyDsl.g:1989:2: ( rule__Variable__NameAssignment_1 )
            {
             before(grammarAccess.getVariableAccess().getNameAssignment_1()); 
            // InternalMyDsl.g:1990:2: ( rule__Variable__NameAssignment_1 )
            // InternalMyDsl.g:1990:3: rule__Variable__NameAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Variable__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getVariableAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Variable__Group__1__Impl"


    // $ANTLR start "rule__Variable__Group__2"
    // InternalMyDsl.g:1998:1: rule__Variable__Group__2 : rule__Variable__Group__2__Impl rule__Variable__Group__3 ;
    public final void rule__Variable__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2002:1: ( rule__Variable__Group__2__Impl rule__Variable__Group__3 )
            // InternalMyDsl.g:2003:2: rule__Variable__Group__2__Impl rule__Variable__Group__3
            {
            pushFollow(FOLLOW_16);
            rule__Variable__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Variable__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Variable__Group__2"


    // $ANTLR start "rule__Variable__Group__2__Impl"
    // InternalMyDsl.g:2010:1: rule__Variable__Group__2__Impl : ( '=' ) ;
    public final void rule__Variable__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2014:1: ( ( '=' ) )
            // InternalMyDsl.g:2015:1: ( '=' )
            {
            // InternalMyDsl.g:2015:1: ( '=' )
            // InternalMyDsl.g:2016:2: '='
            {
             before(grammarAccess.getVariableAccess().getEqualsSignKeyword_2()); 
            match(input,33,FOLLOW_2); 
             after(grammarAccess.getVariableAccess().getEqualsSignKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Variable__Group__2__Impl"


    // $ANTLR start "rule__Variable__Group__3"
    // InternalMyDsl.g:2025:1: rule__Variable__Group__3 : rule__Variable__Group__3__Impl ;
    public final void rule__Variable__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2029:1: ( rule__Variable__Group__3__Impl )
            // InternalMyDsl.g:2030:2: rule__Variable__Group__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Variable__Group__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Variable__Group__3"


    // $ANTLR start "rule__Variable__Group__3__Impl"
    // InternalMyDsl.g:2036:1: rule__Variable__Group__3__Impl : ( ( rule__Variable__ValAssignment_3 ) ) ;
    public final void rule__Variable__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2040:1: ( ( ( rule__Variable__ValAssignment_3 ) ) )
            // InternalMyDsl.g:2041:1: ( ( rule__Variable__ValAssignment_3 ) )
            {
            // InternalMyDsl.g:2041:1: ( ( rule__Variable__ValAssignment_3 ) )
            // InternalMyDsl.g:2042:2: ( rule__Variable__ValAssignment_3 )
            {
             before(grammarAccess.getVariableAccess().getValAssignment_3()); 
            // InternalMyDsl.g:2043:2: ( rule__Variable__ValAssignment_3 )
            // InternalMyDsl.g:2043:3: rule__Variable__ValAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__Variable__ValAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getVariableAccess().getValAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Variable__Group__3__Impl"


    // $ANTLR start "rule__Call__Group__0"
    // InternalMyDsl.g:2052:1: rule__Call__Group__0 : rule__Call__Group__0__Impl rule__Call__Group__1 ;
    public final void rule__Call__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2056:1: ( rule__Call__Group__0__Impl rule__Call__Group__1 )
            // InternalMyDsl.g:2057:2: rule__Call__Group__0__Impl rule__Call__Group__1
            {
            pushFollow(FOLLOW_14);
            rule__Call__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Call__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Call__Group__0"


    // $ANTLR start "rule__Call__Group__0__Impl"
    // InternalMyDsl.g:2064:1: rule__Call__Group__0__Impl : ( 'call' ) ;
    public final void rule__Call__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2068:1: ( ( 'call' ) )
            // InternalMyDsl.g:2069:1: ( 'call' )
            {
            // InternalMyDsl.g:2069:1: ( 'call' )
            // InternalMyDsl.g:2070:2: 'call'
            {
             before(grammarAccess.getCallAccess().getCallKeyword_0()); 
            match(input,34,FOLLOW_2); 
             after(grammarAccess.getCallAccess().getCallKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Call__Group__0__Impl"


    // $ANTLR start "rule__Call__Group__1"
    // InternalMyDsl.g:2079:1: rule__Call__Group__1 : rule__Call__Group__1__Impl rule__Call__Group__2 ;
    public final void rule__Call__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2083:1: ( rule__Call__Group__1__Impl rule__Call__Group__2 )
            // InternalMyDsl.g:2084:2: rule__Call__Group__1__Impl rule__Call__Group__2
            {
            pushFollow(FOLLOW_17);
            rule__Call__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Call__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Call__Group__1"


    // $ANTLR start "rule__Call__Group__1__Impl"
    // InternalMyDsl.g:2091:1: rule__Call__Group__1__Impl : ( ( rule__Call__NameAssignment_1 ) ) ;
    public final void rule__Call__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2095:1: ( ( ( rule__Call__NameAssignment_1 ) ) )
            // InternalMyDsl.g:2096:1: ( ( rule__Call__NameAssignment_1 ) )
            {
            // InternalMyDsl.g:2096:1: ( ( rule__Call__NameAssignment_1 ) )
            // InternalMyDsl.g:2097:2: ( rule__Call__NameAssignment_1 )
            {
             before(grammarAccess.getCallAccess().getNameAssignment_1()); 
            // InternalMyDsl.g:2098:2: ( rule__Call__NameAssignment_1 )
            // InternalMyDsl.g:2098:3: rule__Call__NameAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Call__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getCallAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Call__Group__1__Impl"


    // $ANTLR start "rule__Call__Group__2"
    // InternalMyDsl.g:2106:1: rule__Call__Group__2 : rule__Call__Group__2__Impl rule__Call__Group__3 ;
    public final void rule__Call__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2110:1: ( rule__Call__Group__2__Impl rule__Call__Group__3 )
            // InternalMyDsl.g:2111:2: rule__Call__Group__2__Impl rule__Call__Group__3
            {
            pushFollow(FOLLOW_18);
            rule__Call__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Call__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Call__Group__2"


    // $ANTLR start "rule__Call__Group__2__Impl"
    // InternalMyDsl.g:2118:1: rule__Call__Group__2__Impl : ( 'parameters' ) ;
    public final void rule__Call__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2122:1: ( ( 'parameters' ) )
            // InternalMyDsl.g:2123:1: ( 'parameters' )
            {
            // InternalMyDsl.g:2123:1: ( 'parameters' )
            // InternalMyDsl.g:2124:2: 'parameters'
            {
             before(grammarAccess.getCallAccess().getParametersKeyword_2()); 
            match(input,35,FOLLOW_2); 
             after(grammarAccess.getCallAccess().getParametersKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Call__Group__2__Impl"


    // $ANTLR start "rule__Call__Group__3"
    // InternalMyDsl.g:2133:1: rule__Call__Group__3 : rule__Call__Group__3__Impl ;
    public final void rule__Call__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2137:1: ( rule__Call__Group__3__Impl )
            // InternalMyDsl.g:2138:2: rule__Call__Group__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Call__Group__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Call__Group__3"


    // $ANTLR start "rule__Call__Group__3__Impl"
    // InternalMyDsl.g:2144:1: rule__Call__Group__3__Impl : ( ( rule__Call__ParamAssignment_3 ) ) ;
    public final void rule__Call__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2148:1: ( ( ( rule__Call__ParamAssignment_3 ) ) )
            // InternalMyDsl.g:2149:1: ( ( rule__Call__ParamAssignment_3 ) )
            {
            // InternalMyDsl.g:2149:1: ( ( rule__Call__ParamAssignment_3 ) )
            // InternalMyDsl.g:2150:2: ( rule__Call__ParamAssignment_3 )
            {
             before(grammarAccess.getCallAccess().getParamAssignment_3()); 
            // InternalMyDsl.g:2151:2: ( rule__Call__ParamAssignment_3 )
            // InternalMyDsl.g:2151:3: rule__Call__ParamAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__Call__ParamAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getCallAccess().getParamAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Call__Group__3__Impl"


    // $ANTLR start "rule__Function__Group__0"
    // InternalMyDsl.g:2160:1: rule__Function__Group__0 : rule__Function__Group__0__Impl rule__Function__Group__1 ;
    public final void rule__Function__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2164:1: ( rule__Function__Group__0__Impl rule__Function__Group__1 )
            // InternalMyDsl.g:2165:2: rule__Function__Group__0__Impl rule__Function__Group__1
            {
            pushFollow(FOLLOW_14);
            rule__Function__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Function__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Function__Group__0"


    // $ANTLR start "rule__Function__Group__0__Impl"
    // InternalMyDsl.g:2172:1: rule__Function__Group__0__Impl : ( 'function' ) ;
    public final void rule__Function__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2176:1: ( ( 'function' ) )
            // InternalMyDsl.g:2177:1: ( 'function' )
            {
            // InternalMyDsl.g:2177:1: ( 'function' )
            // InternalMyDsl.g:2178:2: 'function'
            {
             before(grammarAccess.getFunctionAccess().getFunctionKeyword_0()); 
            match(input,36,FOLLOW_2); 
             after(grammarAccess.getFunctionAccess().getFunctionKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Function__Group__0__Impl"


    // $ANTLR start "rule__Function__Group__1"
    // InternalMyDsl.g:2187:1: rule__Function__Group__1 : rule__Function__Group__1__Impl rule__Function__Group__2 ;
    public final void rule__Function__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2191:1: ( rule__Function__Group__1__Impl rule__Function__Group__2 )
            // InternalMyDsl.g:2192:2: rule__Function__Group__1__Impl rule__Function__Group__2
            {
            pushFollow(FOLLOW_17);
            rule__Function__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Function__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Function__Group__1"


    // $ANTLR start "rule__Function__Group__1__Impl"
    // InternalMyDsl.g:2199:1: rule__Function__Group__1__Impl : ( ( rule__Function__NameAssignment_1 ) ) ;
    public final void rule__Function__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2203:1: ( ( ( rule__Function__NameAssignment_1 ) ) )
            // InternalMyDsl.g:2204:1: ( ( rule__Function__NameAssignment_1 ) )
            {
            // InternalMyDsl.g:2204:1: ( ( rule__Function__NameAssignment_1 ) )
            // InternalMyDsl.g:2205:2: ( rule__Function__NameAssignment_1 )
            {
             before(grammarAccess.getFunctionAccess().getNameAssignment_1()); 
            // InternalMyDsl.g:2206:2: ( rule__Function__NameAssignment_1 )
            // InternalMyDsl.g:2206:3: rule__Function__NameAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Function__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getFunctionAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Function__Group__1__Impl"


    // $ANTLR start "rule__Function__Group__2"
    // InternalMyDsl.g:2214:1: rule__Function__Group__2 : rule__Function__Group__2__Impl rule__Function__Group__3 ;
    public final void rule__Function__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2218:1: ( rule__Function__Group__2__Impl rule__Function__Group__3 )
            // InternalMyDsl.g:2219:2: rule__Function__Group__2__Impl rule__Function__Group__3
            {
            pushFollow(FOLLOW_18);
            rule__Function__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Function__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Function__Group__2"


    // $ANTLR start "rule__Function__Group__2__Impl"
    // InternalMyDsl.g:2226:1: rule__Function__Group__2__Impl : ( 'parameters' ) ;
    public final void rule__Function__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2230:1: ( ( 'parameters' ) )
            // InternalMyDsl.g:2231:1: ( 'parameters' )
            {
            // InternalMyDsl.g:2231:1: ( 'parameters' )
            // InternalMyDsl.g:2232:2: 'parameters'
            {
             before(grammarAccess.getFunctionAccess().getParametersKeyword_2()); 
            match(input,35,FOLLOW_2); 
             after(grammarAccess.getFunctionAccess().getParametersKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Function__Group__2__Impl"


    // $ANTLR start "rule__Function__Group__3"
    // InternalMyDsl.g:2241:1: rule__Function__Group__3 : rule__Function__Group__3__Impl rule__Function__Group__4 ;
    public final void rule__Function__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2245:1: ( rule__Function__Group__3__Impl rule__Function__Group__4 )
            // InternalMyDsl.g:2246:2: rule__Function__Group__3__Impl rule__Function__Group__4
            {
            pushFollow(FOLLOW_19);
            rule__Function__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Function__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Function__Group__3"


    // $ANTLR start "rule__Function__Group__3__Impl"
    // InternalMyDsl.g:2253:1: rule__Function__Group__3__Impl : ( ( ( rule__Function__ParamsAssignment_3 ) ) ( ( rule__Function__ParamsAssignment_3 )* ) ) ;
    public final void rule__Function__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2257:1: ( ( ( ( rule__Function__ParamsAssignment_3 ) ) ( ( rule__Function__ParamsAssignment_3 )* ) ) )
            // InternalMyDsl.g:2258:1: ( ( ( rule__Function__ParamsAssignment_3 ) ) ( ( rule__Function__ParamsAssignment_3 )* ) )
            {
            // InternalMyDsl.g:2258:1: ( ( ( rule__Function__ParamsAssignment_3 ) ) ( ( rule__Function__ParamsAssignment_3 )* ) )
            // InternalMyDsl.g:2259:2: ( ( rule__Function__ParamsAssignment_3 ) ) ( ( rule__Function__ParamsAssignment_3 )* )
            {
            // InternalMyDsl.g:2259:2: ( ( rule__Function__ParamsAssignment_3 ) )
            // InternalMyDsl.g:2260:3: ( rule__Function__ParamsAssignment_3 )
            {
             before(grammarAccess.getFunctionAccess().getParamsAssignment_3()); 
            // InternalMyDsl.g:2261:3: ( rule__Function__ParamsAssignment_3 )
            // InternalMyDsl.g:2261:4: rule__Function__ParamsAssignment_3
            {
            pushFollow(FOLLOW_20);
            rule__Function__ParamsAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getFunctionAccess().getParamsAssignment_3()); 

            }

            // InternalMyDsl.g:2264:2: ( ( rule__Function__ParamsAssignment_3 )* )
            // InternalMyDsl.g:2265:3: ( rule__Function__ParamsAssignment_3 )*
            {
             before(grammarAccess.getFunctionAccess().getParamsAssignment_3()); 
            // InternalMyDsl.g:2266:3: ( rule__Function__ParamsAssignment_3 )*
            loop12:
            do {
                int alt12=2;
                int LA12_0 = input.LA(1);

                if ( ((LA12_0>=RULE_STRING && LA12_0<=RULE_ID)) ) {
                    alt12=1;
                }


                switch (alt12) {
            	case 1 :
            	    // InternalMyDsl.g:2266:4: rule__Function__ParamsAssignment_3
            	    {
            	    pushFollow(FOLLOW_20);
            	    rule__Function__ParamsAssignment_3();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop12;
                }
            } while (true);

             after(grammarAccess.getFunctionAccess().getParamsAssignment_3()); 

            }


            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Function__Group__3__Impl"


    // $ANTLR start "rule__Function__Group__4"
    // InternalMyDsl.g:2275:1: rule__Function__Group__4 : rule__Function__Group__4__Impl rule__Function__Group__5 ;
    public final void rule__Function__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2279:1: ( rule__Function__Group__4__Impl rule__Function__Group__5 )
            // InternalMyDsl.g:2280:2: rule__Function__Group__4__Impl rule__Function__Group__5
            {
            pushFollow(FOLLOW_21);
            rule__Function__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Function__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Function__Group__4"


    // $ANTLR start "rule__Function__Group__4__Impl"
    // InternalMyDsl.g:2287:1: rule__Function__Group__4__Impl : ( '{' ) ;
    public final void rule__Function__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2291:1: ( ( '{' ) )
            // InternalMyDsl.g:2292:1: ( '{' )
            {
            // InternalMyDsl.g:2292:1: ( '{' )
            // InternalMyDsl.g:2293:2: '{'
            {
             before(grammarAccess.getFunctionAccess().getLeftCurlyBracketKeyword_4()); 
            match(input,37,FOLLOW_2); 
             after(grammarAccess.getFunctionAccess().getLeftCurlyBracketKeyword_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Function__Group__4__Impl"


    // $ANTLR start "rule__Function__Group__5"
    // InternalMyDsl.g:2302:1: rule__Function__Group__5 : rule__Function__Group__5__Impl rule__Function__Group__6 ;
    public final void rule__Function__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2306:1: ( rule__Function__Group__5__Impl rule__Function__Group__6 )
            // InternalMyDsl.g:2307:2: rule__Function__Group__5__Impl rule__Function__Group__6
            {
            pushFollow(FOLLOW_22);
            rule__Function__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Function__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Function__Group__5"


    // $ANTLR start "rule__Function__Group__5__Impl"
    // InternalMyDsl.g:2314:1: rule__Function__Group__5__Impl : ( ( ( rule__Function__InstrAssignment_5 ) ) ( ( rule__Function__InstrAssignment_5 )* ) ) ;
    public final void rule__Function__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2318:1: ( ( ( ( rule__Function__InstrAssignment_5 ) ) ( ( rule__Function__InstrAssignment_5 )* ) ) )
            // InternalMyDsl.g:2319:1: ( ( ( rule__Function__InstrAssignment_5 ) ) ( ( rule__Function__InstrAssignment_5 )* ) )
            {
            // InternalMyDsl.g:2319:1: ( ( ( rule__Function__InstrAssignment_5 ) ) ( ( rule__Function__InstrAssignment_5 )* ) )
            // InternalMyDsl.g:2320:2: ( ( rule__Function__InstrAssignment_5 ) ) ( ( rule__Function__InstrAssignment_5 )* )
            {
            // InternalMyDsl.g:2320:2: ( ( rule__Function__InstrAssignment_5 ) )
            // InternalMyDsl.g:2321:3: ( rule__Function__InstrAssignment_5 )
            {
             before(grammarAccess.getFunctionAccess().getInstrAssignment_5()); 
            // InternalMyDsl.g:2322:3: ( rule__Function__InstrAssignment_5 )
            // InternalMyDsl.g:2322:4: rule__Function__InstrAssignment_5
            {
            pushFollow(FOLLOW_3);
            rule__Function__InstrAssignment_5();

            state._fsp--;


            }

             after(grammarAccess.getFunctionAccess().getInstrAssignment_5()); 

            }

            // InternalMyDsl.g:2325:2: ( ( rule__Function__InstrAssignment_5 )* )
            // InternalMyDsl.g:2326:3: ( rule__Function__InstrAssignment_5 )*
            {
             before(grammarAccess.getFunctionAccess().getInstrAssignment_5()); 
            // InternalMyDsl.g:2327:3: ( rule__Function__InstrAssignment_5 )*
            loop13:
            do {
                int alt13=2;
                int LA13_0 = input.LA(1);

                if ( ((LA13_0>=22 && LA13_0<=32)||LA13_0==34||LA13_0==36) ) {
                    alt13=1;
                }


                switch (alt13) {
            	case 1 :
            	    // InternalMyDsl.g:2327:4: rule__Function__InstrAssignment_5
            	    {
            	    pushFollow(FOLLOW_3);
            	    rule__Function__InstrAssignment_5();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop13;
                }
            } while (true);

             after(grammarAccess.getFunctionAccess().getInstrAssignment_5()); 

            }


            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Function__Group__5__Impl"


    // $ANTLR start "rule__Function__Group__6"
    // InternalMyDsl.g:2336:1: rule__Function__Group__6 : rule__Function__Group__6__Impl ;
    public final void rule__Function__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2340:1: ( rule__Function__Group__6__Impl )
            // InternalMyDsl.g:2341:2: rule__Function__Group__6__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Function__Group__6__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Function__Group__6"


    // $ANTLR start "rule__Function__Group__6__Impl"
    // InternalMyDsl.g:2347:1: rule__Function__Group__6__Impl : ( '}' ) ;
    public final void rule__Function__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2351:1: ( ( '}' ) )
            // InternalMyDsl.g:2352:1: ( '}' )
            {
            // InternalMyDsl.g:2352:1: ( '}' )
            // InternalMyDsl.g:2353:2: '}'
            {
             before(grammarAccess.getFunctionAccess().getRightCurlyBracketKeyword_6()); 
            match(input,38,FOLLOW_2); 
             after(grammarAccess.getFunctionAccess().getRightCurlyBracketKeyword_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Function__Group__6__Impl"


    // $ANTLR start "rule__Name__Group__0"
    // InternalMyDsl.g:2363:1: rule__Name__Group__0 : rule__Name__Group__0__Impl rule__Name__Group__1 ;
    public final void rule__Name__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2367:1: ( rule__Name__Group__0__Impl rule__Name__Group__1 )
            // InternalMyDsl.g:2368:2: rule__Name__Group__0__Impl rule__Name__Group__1
            {
            pushFollow(FOLLOW_18);
            rule__Name__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Name__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Name__Group__0"


    // $ANTLR start "rule__Name__Group__0__Impl"
    // InternalMyDsl.g:2375:1: rule__Name__Group__0__Impl : ( 'name' ) ;
    public final void rule__Name__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2379:1: ( ( 'name' ) )
            // InternalMyDsl.g:2380:1: ( 'name' )
            {
            // InternalMyDsl.g:2380:1: ( 'name' )
            // InternalMyDsl.g:2381:2: 'name'
            {
             before(grammarAccess.getNameAccess().getNameKeyword_0()); 
            match(input,39,FOLLOW_2); 
             after(grammarAccess.getNameAccess().getNameKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Name__Group__0__Impl"


    // $ANTLR start "rule__Name__Group__1"
    // InternalMyDsl.g:2390:1: rule__Name__Group__1 : rule__Name__Group__1__Impl ;
    public final void rule__Name__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2394:1: ( rule__Name__Group__1__Impl )
            // InternalMyDsl.g:2395:2: rule__Name__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Name__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Name__Group__1"


    // $ANTLR start "rule__Name__Group__1__Impl"
    // InternalMyDsl.g:2401:1: rule__Name__Group__1__Impl : ( ( rule__Name__NameAssignment_1 ) ) ;
    public final void rule__Name__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2405:1: ( ( ( rule__Name__NameAssignment_1 ) ) )
            // InternalMyDsl.g:2406:1: ( ( rule__Name__NameAssignment_1 ) )
            {
            // InternalMyDsl.g:2406:1: ( ( rule__Name__NameAssignment_1 ) )
            // InternalMyDsl.g:2407:2: ( rule__Name__NameAssignment_1 )
            {
             before(grammarAccess.getNameAccess().getNameAssignment_1()); 
            // InternalMyDsl.g:2408:2: ( rule__Name__NameAssignment_1 )
            // InternalMyDsl.g:2408:3: rule__Name__NameAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Name__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getNameAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Name__Group__1__Impl"


    // $ANTLR start "rule__Value__Group__0"
    // InternalMyDsl.g:2417:1: rule__Value__Group__0 : rule__Value__Group__0__Impl rule__Value__Group__1 ;
    public final void rule__Value__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2421:1: ( rule__Value__Group__0__Impl rule__Value__Group__1 )
            // InternalMyDsl.g:2422:2: rule__Value__Group__0__Impl rule__Value__Group__1
            {
            pushFollow(FOLLOW_18);
            rule__Value__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Value__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Value__Group__0"


    // $ANTLR start "rule__Value__Group__0__Impl"
    // InternalMyDsl.g:2429:1: rule__Value__Group__0__Impl : ( 'value' ) ;
    public final void rule__Value__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2433:1: ( ( 'value' ) )
            // InternalMyDsl.g:2434:1: ( 'value' )
            {
            // InternalMyDsl.g:2434:1: ( 'value' )
            // InternalMyDsl.g:2435:2: 'value'
            {
             before(grammarAccess.getValueAccess().getValueKeyword_0()); 
            match(input,40,FOLLOW_2); 
             after(grammarAccess.getValueAccess().getValueKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Value__Group__0__Impl"


    // $ANTLR start "rule__Value__Group__1"
    // InternalMyDsl.g:2444:1: rule__Value__Group__1 : rule__Value__Group__1__Impl ;
    public final void rule__Value__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2448:1: ( rule__Value__Group__1__Impl )
            // InternalMyDsl.g:2449:2: rule__Value__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Value__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Value__Group__1"


    // $ANTLR start "rule__Value__Group__1__Impl"
    // InternalMyDsl.g:2455:1: rule__Value__Group__1__Impl : ( ( rule__Value__Alternatives_1 ) ) ;
    public final void rule__Value__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2459:1: ( ( ( rule__Value__Alternatives_1 ) ) )
            // InternalMyDsl.g:2460:1: ( ( rule__Value__Alternatives_1 ) )
            {
            // InternalMyDsl.g:2460:1: ( ( rule__Value__Alternatives_1 ) )
            // InternalMyDsl.g:2461:2: ( rule__Value__Alternatives_1 )
            {
             before(grammarAccess.getValueAccess().getAlternatives_1()); 
            // InternalMyDsl.g:2462:2: ( rule__Value__Alternatives_1 )
            // InternalMyDsl.g:2462:3: rule__Value__Alternatives_1
            {
            pushFollow(FOLLOW_2);
            rule__Value__Alternatives_1();

            state._fsp--;


            }

             after(grammarAccess.getValueAccess().getAlternatives_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Value__Group__1__Impl"


    // $ANTLR start "rule__Model__InstructionsAssignment"
    // InternalMyDsl.g:2471:1: rule__Model__InstructionsAssignment : ( ruleInstruction ) ;
    public final void rule__Model__InstructionsAssignment() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2475:1: ( ( ruleInstruction ) )
            // InternalMyDsl.g:2476:2: ( ruleInstruction )
            {
            // InternalMyDsl.g:2476:2: ( ruleInstruction )
            // InternalMyDsl.g:2477:3: ruleInstruction
            {
             before(grammarAccess.getModelAccess().getInstructionsInstructionParserRuleCall_0()); 
            pushFollow(FOLLOW_2);
            ruleInstruction();

            state._fsp--;

             after(grammarAccess.getModelAccess().getInstructionsInstructionParserRuleCall_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__InstructionsAssignment"


    // $ANTLR start "rule__OpenBrowser__UrlAssignment_1"
    // InternalMyDsl.g:2486:1: rule__OpenBrowser__UrlAssignment_1 : ( RULE_STRING ) ;
    public final void rule__OpenBrowser__UrlAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2490:1: ( ( RULE_STRING ) )
            // InternalMyDsl.g:2491:2: ( RULE_STRING )
            {
            // InternalMyDsl.g:2491:2: ( RULE_STRING )
            // InternalMyDsl.g:2492:3: RULE_STRING
            {
             before(grammarAccess.getOpenBrowserAccess().getUrlSTRINGTerminalRuleCall_1_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getOpenBrowserAccess().getUrlSTRINGTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__OpenBrowser__UrlAssignment_1"


    // $ANTLR start "rule__ChangeUrl__UrlAssignment_1"
    // InternalMyDsl.g:2501:1: rule__ChangeUrl__UrlAssignment_1 : ( RULE_STRING ) ;
    public final void rule__ChangeUrl__UrlAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2505:1: ( ( RULE_STRING ) )
            // InternalMyDsl.g:2506:2: ( RULE_STRING )
            {
            // InternalMyDsl.g:2506:2: ( RULE_STRING )
            // InternalMyDsl.g:2507:3: RULE_STRING
            {
             before(grammarAccess.getChangeUrlAccess().getUrlSTRINGTerminalRuleCall_1_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getChangeUrlAccess().getUrlSTRINGTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ChangeUrl__UrlAssignment_1"


    // $ANTLR start "rule__Contains__TypeAssignment_1"
    // InternalMyDsl.g:2516:1: rule__Contains__TypeAssignment_1 : ( ruleTypeElement ) ;
    public final void rule__Contains__TypeAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2520:1: ( ( ruleTypeElement ) )
            // InternalMyDsl.g:2521:2: ( ruleTypeElement )
            {
            // InternalMyDsl.g:2521:2: ( ruleTypeElement )
            // InternalMyDsl.g:2522:3: ruleTypeElement
            {
             before(grammarAccess.getContainsAccess().getTypeTypeElementParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleTypeElement();

            state._fsp--;

             after(grammarAccess.getContainsAccess().getTypeTypeElementParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Contains__TypeAssignment_1"


    // $ANTLR start "rule__Contains__ValeurAssignment_2"
    // InternalMyDsl.g:2531:1: rule__Contains__ValeurAssignment_2 : ( ruleName ) ;
    public final void rule__Contains__ValeurAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2535:1: ( ( ruleName ) )
            // InternalMyDsl.g:2536:2: ( ruleName )
            {
            // InternalMyDsl.g:2536:2: ( ruleName )
            // InternalMyDsl.g:2537:3: ruleName
            {
             before(grammarAccess.getContainsAccess().getValeurNameParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleName();

            state._fsp--;

             after(grammarAccess.getContainsAccess().getValeurNameParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Contains__ValeurAssignment_2"


    // $ANTLR start "rule__Click__TypeAssignment_1"
    // InternalMyDsl.g:2546:1: rule__Click__TypeAssignment_1 : ( ruleTypeElement ) ;
    public final void rule__Click__TypeAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2550:1: ( ( ruleTypeElement ) )
            // InternalMyDsl.g:2551:2: ( ruleTypeElement )
            {
            // InternalMyDsl.g:2551:2: ( ruleTypeElement )
            // InternalMyDsl.g:2552:3: ruleTypeElement
            {
             before(grammarAccess.getClickAccess().getTypeTypeElementParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleTypeElement();

            state._fsp--;

             after(grammarAccess.getClickAccess().getTypeTypeElementParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Click__TypeAssignment_1"


    // $ANTLR start "rule__Click__ValeurAssignment_2"
    // InternalMyDsl.g:2561:1: rule__Click__ValeurAssignment_2 : ( ruleName ) ;
    public final void rule__Click__ValeurAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2565:1: ( ( ruleName ) )
            // InternalMyDsl.g:2566:2: ( ruleName )
            {
            // InternalMyDsl.g:2566:2: ( ruleName )
            // InternalMyDsl.g:2567:3: ruleName
            {
             before(grammarAccess.getClickAccess().getValeurNameParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleName();

            state._fsp--;

             after(grammarAccess.getClickAccess().getValeurNameParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Click__ValeurAssignment_2"


    // $ANTLR start "rule__Set__TypeAssignment_1"
    // InternalMyDsl.g:2576:1: rule__Set__TypeAssignment_1 : ( ruleTypeSet ) ;
    public final void rule__Set__TypeAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2580:1: ( ( ruleTypeSet ) )
            // InternalMyDsl.g:2581:2: ( ruleTypeSet )
            {
            // InternalMyDsl.g:2581:2: ( ruleTypeSet )
            // InternalMyDsl.g:2582:3: ruleTypeSet
            {
             before(grammarAccess.getSetAccess().getTypeTypeSetParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleTypeSet();

            state._fsp--;

             after(grammarAccess.getSetAccess().getTypeTypeSetParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Set__TypeAssignment_1"


    // $ANTLR start "rule__Set__NameAssignment_2"
    // InternalMyDsl.g:2591:1: rule__Set__NameAssignment_2 : ( ruleName ) ;
    public final void rule__Set__NameAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2595:1: ( ( ruleName ) )
            // InternalMyDsl.g:2596:2: ( ruleName )
            {
            // InternalMyDsl.g:2596:2: ( ruleName )
            // InternalMyDsl.g:2597:3: ruleName
            {
             before(grammarAccess.getSetAccess().getNameNameParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleName();

            state._fsp--;

             after(grammarAccess.getSetAccess().getNameNameParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Set__NameAssignment_2"


    // $ANTLR start "rule__Set__ValueAssignment_3"
    // InternalMyDsl.g:2606:1: rule__Set__ValueAssignment_3 : ( ruleValue ) ;
    public final void rule__Set__ValueAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2610:1: ( ( ruleValue ) )
            // InternalMyDsl.g:2611:2: ( ruleValue )
            {
            // InternalMyDsl.g:2611:2: ( ruleValue )
            // InternalMyDsl.g:2612:3: ruleValue
            {
             before(grammarAccess.getSetAccess().getValueValueParserRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleValue();

            state._fsp--;

             after(grammarAccess.getSetAccess().getValueValueParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Set__ValueAssignment_3"


    // $ANTLR start "rule__Check__OptionCheckAssignment_2"
    // InternalMyDsl.g:2621:1: rule__Check__OptionCheckAssignment_2 : ( ruleName ) ;
    public final void rule__Check__OptionCheckAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2625:1: ( ( ruleName ) )
            // InternalMyDsl.g:2626:2: ( ruleName )
            {
            // InternalMyDsl.g:2626:2: ( ruleName )
            // InternalMyDsl.g:2627:3: ruleName
            {
             before(grammarAccess.getCheckAccess().getOptionCheckNameParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleName();

            state._fsp--;

             after(grammarAccess.getCheckAccess().getOptionCheckNameParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Check__OptionCheckAssignment_2"


    // $ANTLR start "rule__Uncheck__OptionUncheckAssignment_3_0"
    // InternalMyDsl.g:2636:1: rule__Uncheck__OptionUncheckAssignment_3_0 : ( ruleName ) ;
    public final void rule__Uncheck__OptionUncheckAssignment_3_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2640:1: ( ( ruleName ) )
            // InternalMyDsl.g:2641:2: ( ruleName )
            {
            // InternalMyDsl.g:2641:2: ( ruleName )
            // InternalMyDsl.g:2642:3: ruleName
            {
             before(grammarAccess.getUncheckAccess().getOptionUncheckNameParserRuleCall_3_0_0()); 
            pushFollow(FOLLOW_2);
            ruleName();

            state._fsp--;

             after(grammarAccess.getUncheckAccess().getOptionUncheckNameParserRuleCall_3_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Uncheck__OptionUncheckAssignment_3_0"


    // $ANTLR start "rule__Read__TypeAssignment_1"
    // InternalMyDsl.g:2651:1: rule__Read__TypeAssignment_1 : ( ruleTypeProperty ) ;
    public final void rule__Read__TypeAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2655:1: ( ( ruleTypeProperty ) )
            // InternalMyDsl.g:2656:2: ( ruleTypeProperty )
            {
            // InternalMyDsl.g:2656:2: ( ruleTypeProperty )
            // InternalMyDsl.g:2657:3: ruleTypeProperty
            {
             before(grammarAccess.getReadAccess().getTypeTypePropertyParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleTypeProperty();

            state._fsp--;

             after(grammarAccess.getReadAccess().getTypeTypePropertyParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Read__TypeAssignment_1"


    // $ANTLR start "rule__Read__NameAssignment_3"
    // InternalMyDsl.g:2666:1: rule__Read__NameAssignment_3 : ( ruleName ) ;
    public final void rule__Read__NameAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2670:1: ( ( ruleName ) )
            // InternalMyDsl.g:2671:2: ( ruleName )
            {
            // InternalMyDsl.g:2671:2: ( ruleName )
            // InternalMyDsl.g:2672:3: ruleName
            {
             before(grammarAccess.getReadAccess().getNameNameParserRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleName();

            state._fsp--;

             after(grammarAccess.getReadAccess().getNameNameParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Read__NameAssignment_3"


    // $ANTLR start "rule__EqualsTo__Elmt1Assignment_1"
    // InternalMyDsl.g:2681:1: rule__EqualsTo__Elmt1Assignment_1 : ( RULE_ID ) ;
    public final void rule__EqualsTo__Elmt1Assignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2685:1: ( ( RULE_ID ) )
            // InternalMyDsl.g:2686:2: ( RULE_ID )
            {
            // InternalMyDsl.g:2686:2: ( RULE_ID )
            // InternalMyDsl.g:2687:3: RULE_ID
            {
             before(grammarAccess.getEqualsToAccess().getElmt1IDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getEqualsToAccess().getElmt1IDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EqualsTo__Elmt1Assignment_1"


    // $ANTLR start "rule__EqualsTo__Elmt2Assignment_2"
    // InternalMyDsl.g:2696:1: rule__EqualsTo__Elmt2Assignment_2 : ( RULE_ID ) ;
    public final void rule__EqualsTo__Elmt2Assignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2700:1: ( ( RULE_ID ) )
            // InternalMyDsl.g:2701:2: ( RULE_ID )
            {
            // InternalMyDsl.g:2701:2: ( RULE_ID )
            // InternalMyDsl.g:2702:3: RULE_ID
            {
             before(grammarAccess.getEqualsToAccess().getElmt2IDTerminalRuleCall_2_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getEqualsToAccess().getElmt2IDTerminalRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EqualsTo__Elmt2Assignment_2"


    // $ANTLR start "rule__Variable__NameAssignment_1"
    // InternalMyDsl.g:2711:1: rule__Variable__NameAssignment_1 : ( RULE_ID ) ;
    public final void rule__Variable__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2715:1: ( ( RULE_ID ) )
            // InternalMyDsl.g:2716:2: ( RULE_ID )
            {
            // InternalMyDsl.g:2716:2: ( RULE_ID )
            // InternalMyDsl.g:2717:3: RULE_ID
            {
             before(grammarAccess.getVariableAccess().getNameIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getVariableAccess().getNameIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Variable__NameAssignment_1"


    // $ANTLR start "rule__Variable__ValAssignment_3"
    // InternalMyDsl.g:2726:1: rule__Variable__ValAssignment_3 : ( ( rule__Variable__ValAlternatives_3_0 ) ) ;
    public final void rule__Variable__ValAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2730:1: ( ( ( rule__Variable__ValAlternatives_3_0 ) ) )
            // InternalMyDsl.g:2731:2: ( ( rule__Variable__ValAlternatives_3_0 ) )
            {
            // InternalMyDsl.g:2731:2: ( ( rule__Variable__ValAlternatives_3_0 ) )
            // InternalMyDsl.g:2732:3: ( rule__Variable__ValAlternatives_3_0 )
            {
             before(grammarAccess.getVariableAccess().getValAlternatives_3_0()); 
            // InternalMyDsl.g:2733:3: ( rule__Variable__ValAlternatives_3_0 )
            // InternalMyDsl.g:2733:4: rule__Variable__ValAlternatives_3_0
            {
            pushFollow(FOLLOW_2);
            rule__Variable__ValAlternatives_3_0();

            state._fsp--;


            }

             after(grammarAccess.getVariableAccess().getValAlternatives_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Variable__ValAssignment_3"


    // $ANTLR start "rule__Call__NameAssignment_1"
    // InternalMyDsl.g:2741:1: rule__Call__NameAssignment_1 : ( RULE_ID ) ;
    public final void rule__Call__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2745:1: ( ( RULE_ID ) )
            // InternalMyDsl.g:2746:2: ( RULE_ID )
            {
            // InternalMyDsl.g:2746:2: ( RULE_ID )
            // InternalMyDsl.g:2747:3: RULE_ID
            {
             before(grammarAccess.getCallAccess().getNameIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getCallAccess().getNameIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Call__NameAssignment_1"


    // $ANTLR start "rule__Call__ParamAssignment_3"
    // InternalMyDsl.g:2756:1: rule__Call__ParamAssignment_3 : ( ruleParameter ) ;
    public final void rule__Call__ParamAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2760:1: ( ( ruleParameter ) )
            // InternalMyDsl.g:2761:2: ( ruleParameter )
            {
            // InternalMyDsl.g:2761:2: ( ruleParameter )
            // InternalMyDsl.g:2762:3: ruleParameter
            {
             before(grammarAccess.getCallAccess().getParamParameterParserRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleParameter();

            state._fsp--;

             after(grammarAccess.getCallAccess().getParamParameterParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Call__ParamAssignment_3"


    // $ANTLR start "rule__Function__NameAssignment_1"
    // InternalMyDsl.g:2771:1: rule__Function__NameAssignment_1 : ( RULE_ID ) ;
    public final void rule__Function__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2775:1: ( ( RULE_ID ) )
            // InternalMyDsl.g:2776:2: ( RULE_ID )
            {
            // InternalMyDsl.g:2776:2: ( RULE_ID )
            // InternalMyDsl.g:2777:3: RULE_ID
            {
             before(grammarAccess.getFunctionAccess().getNameIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getFunctionAccess().getNameIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Function__NameAssignment_1"


    // $ANTLR start "rule__Function__ParamsAssignment_3"
    // InternalMyDsl.g:2786:1: rule__Function__ParamsAssignment_3 : ( ruleParameter ) ;
    public final void rule__Function__ParamsAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2790:1: ( ( ruleParameter ) )
            // InternalMyDsl.g:2791:2: ( ruleParameter )
            {
            // InternalMyDsl.g:2791:2: ( ruleParameter )
            // InternalMyDsl.g:2792:3: ruleParameter
            {
             before(grammarAccess.getFunctionAccess().getParamsParameterParserRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleParameter();

            state._fsp--;

             after(grammarAccess.getFunctionAccess().getParamsParameterParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Function__ParamsAssignment_3"


    // $ANTLR start "rule__Function__InstrAssignment_5"
    // InternalMyDsl.g:2801:1: rule__Function__InstrAssignment_5 : ( ruleInstruction ) ;
    public final void rule__Function__InstrAssignment_5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2805:1: ( ( ruleInstruction ) )
            // InternalMyDsl.g:2806:2: ( ruleInstruction )
            {
            // InternalMyDsl.g:2806:2: ( ruleInstruction )
            // InternalMyDsl.g:2807:3: ruleInstruction
            {
             before(grammarAccess.getFunctionAccess().getInstrInstructionParserRuleCall_5_0()); 
            pushFollow(FOLLOW_2);
            ruleInstruction();

            state._fsp--;

             after(grammarAccess.getFunctionAccess().getInstrInstructionParserRuleCall_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Function__InstrAssignment_5"


    // $ANTLR start "rule__Name__NameAssignment_1"
    // InternalMyDsl.g:2816:1: rule__Name__NameAssignment_1 : ( ( rule__Name__NameAlternatives_1_0 ) ) ;
    public final void rule__Name__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2820:1: ( ( ( rule__Name__NameAlternatives_1_0 ) ) )
            // InternalMyDsl.g:2821:2: ( ( rule__Name__NameAlternatives_1_0 ) )
            {
            // InternalMyDsl.g:2821:2: ( ( rule__Name__NameAlternatives_1_0 ) )
            // InternalMyDsl.g:2822:3: ( rule__Name__NameAlternatives_1_0 )
            {
             before(grammarAccess.getNameAccess().getNameAlternatives_1_0()); 
            // InternalMyDsl.g:2823:3: ( rule__Name__NameAlternatives_1_0 )
            // InternalMyDsl.g:2823:4: rule__Name__NameAlternatives_1_0
            {
            pushFollow(FOLLOW_2);
            rule__Name__NameAlternatives_1_0();

            state._fsp--;


            }

             after(grammarAccess.getNameAccess().getNameAlternatives_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Name__NameAssignment_1"


    // $ANTLR start "rule__Value__StringAssignment_1_0"
    // InternalMyDsl.g:2831:1: rule__Value__StringAssignment_1_0 : ( RULE_STRING ) ;
    public final void rule__Value__StringAssignment_1_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2835:1: ( ( RULE_STRING ) )
            // InternalMyDsl.g:2836:2: ( RULE_STRING )
            {
            // InternalMyDsl.g:2836:2: ( RULE_STRING )
            // InternalMyDsl.g:2837:3: RULE_STRING
            {
             before(grammarAccess.getValueAccess().getStringSTRINGTerminalRuleCall_1_0_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getValueAccess().getStringSTRINGTerminalRuleCall_1_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Value__StringAssignment_1_0"


    // $ANTLR start "rule__Value__IdAssignment_1_1"
    // InternalMyDsl.g:2846:1: rule__Value__IdAssignment_1_1 : ( RULE_ID ) ;
    public final void rule__Value__IdAssignment_1_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2850:1: ( ( RULE_ID ) )
            // InternalMyDsl.g:2851:2: ( RULE_ID )
            {
            // InternalMyDsl.g:2851:2: ( RULE_ID )
            // InternalMyDsl.g:2852:3: RULE_ID
            {
             before(grammarAccess.getValueAccess().getIdIDTerminalRuleCall_1_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getValueAccess().getIdIDTerminalRuleCall_1_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Value__IdAssignment_1_1"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x00000015FFC00002L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x000000000004F000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000008000000000L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000030000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000010000000000L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000010000000L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000008000200000L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000000084000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000000800L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000200000000L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000060000000L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000800000000L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000000000030L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0000002000000000L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0000000000000032L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x00000015FFC00000L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x0000004000000000L});

}