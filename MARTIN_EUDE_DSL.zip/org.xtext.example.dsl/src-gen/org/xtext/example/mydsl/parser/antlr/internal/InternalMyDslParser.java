package org.xtext.example.mydsl.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import org.xtext.example.mydsl.services.MyDslGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalMyDslParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_STRING", "RULE_ID", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'open browser on url'", "'change url'", "'contains'", "'click'", "'set'", "'check'", "'uncheck'", "'all'", "'read'", "'count'", "'equals to'", "'of title'", "'var'", "'='", "'call'", "'parameters'", "'function'", "'{'", "'}'", "'name'", "'value'", "'link'", "'image'", "'text'", "'button'", "'input'", "'combobox'", "'title'", "'url'", "'checkbox'"
    };
    public static final int RULE_STRING=4;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__37=37;
    public static final int T__16=16;
    public static final int T__38=38;
    public static final int T__17=17;
    public static final int T__39=39;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__33=33;
    public static final int T__12=12;
    public static final int T__34=34;
    public static final int T__13=13;
    public static final int T__35=35;
    public static final int T__14=14;
    public static final int T__36=36;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int T__31=31;
    public static final int T__32=32;
    public static final int RULE_ID=5;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=6;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__23=23;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__40=40;
    public static final int T__20=20;
    public static final int T__21=21;

    // delegates
    // delegators


        public InternalMyDslParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalMyDslParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalMyDslParser.tokenNames; }
    public String getGrammarFileName() { return "InternalMyDsl.g"; }



     	private MyDslGrammarAccess grammarAccess;

        public InternalMyDslParser(TokenStream input, MyDslGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "Model";
       	}

       	@Override
       	protected MyDslGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleModel"
    // InternalMyDsl.g:64:1: entryRuleModel returns [EObject current=null] : iv_ruleModel= ruleModel EOF ;
    public final EObject entryRuleModel() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleModel = null;


        try {
            // InternalMyDsl.g:64:46: (iv_ruleModel= ruleModel EOF )
            // InternalMyDsl.g:65:2: iv_ruleModel= ruleModel EOF
            {
             newCompositeNode(grammarAccess.getModelRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleModel=ruleModel();

            state._fsp--;

             current =iv_ruleModel; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleModel"


    // $ANTLR start "ruleModel"
    // InternalMyDsl.g:71:1: ruleModel returns [EObject current=null] : ( (lv_instructions_0_0= ruleInstruction ) )+ ;
    public final EObject ruleModel() throws RecognitionException {
        EObject current = null;

        EObject lv_instructions_0_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:77:2: ( ( (lv_instructions_0_0= ruleInstruction ) )+ )
            // InternalMyDsl.g:78:2: ( (lv_instructions_0_0= ruleInstruction ) )+
            {
            // InternalMyDsl.g:78:2: ( (lv_instructions_0_0= ruleInstruction ) )+
            int cnt1=0;
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( ((LA1_0>=11 && LA1_0<=17)||(LA1_0>=19 && LA1_0<=21)||LA1_0==23||LA1_0==25||LA1_0==27) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // InternalMyDsl.g:79:3: (lv_instructions_0_0= ruleInstruction )
            	    {
            	    // InternalMyDsl.g:79:3: (lv_instructions_0_0= ruleInstruction )
            	    // InternalMyDsl.g:80:4: lv_instructions_0_0= ruleInstruction
            	    {

            	    				newCompositeNode(grammarAccess.getModelAccess().getInstructionsInstructionParserRuleCall_0());
            	    			
            	    pushFollow(FOLLOW_3);
            	    lv_instructions_0_0=ruleInstruction();

            	    state._fsp--;


            	    				if (current==null) {
            	    					current = createModelElementForParent(grammarAccess.getModelRule());
            	    				}
            	    				add(
            	    					current,
            	    					"instructions",
            	    					lv_instructions_0_0,
            	    					"org.xtext.example.mydsl.MyDsl.Instruction");
            	    				afterParserOrEnumRuleCall();
            	    			

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt1 >= 1 ) break loop1;
                        EarlyExitException eee =
                            new EarlyExitException(1, input);
                        throw eee;
                }
                cnt1++;
            } while (true);


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleModel"


    // $ANTLR start "entryRuleInstruction"
    // InternalMyDsl.g:100:1: entryRuleInstruction returns [EObject current=null] : iv_ruleInstruction= ruleInstruction EOF ;
    public final EObject entryRuleInstruction() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleInstruction = null;


        try {
            // InternalMyDsl.g:100:52: (iv_ruleInstruction= ruleInstruction EOF )
            // InternalMyDsl.g:101:2: iv_ruleInstruction= ruleInstruction EOF
            {
             newCompositeNode(grammarAccess.getInstructionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleInstruction=ruleInstruction();

            state._fsp--;

             current =iv_ruleInstruction; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleInstruction"


    // $ANTLR start "ruleInstruction"
    // InternalMyDsl.g:107:1: ruleInstruction returns [EObject current=null] : (this_OpenBrowser_0= ruleOpenBrowser | this_Contains_1= ruleContains | this_Click_2= ruleClick | this_Set_3= ruleSet | this_Check_4= ruleCheck | this_Uncheck_5= ruleUncheck | this_ChangeUrl_6= ruleChangeUrl | this_Read_7= ruleRead | this_Variable_8= ruleVariable | this_Function_9= ruleFunction | this_Count_10= ruleCount | this_EqualsTo_11= ruleEqualsTo | this_Call_12= ruleCall ) ;
    public final EObject ruleInstruction() throws RecognitionException {
        EObject current = null;

        EObject this_OpenBrowser_0 = null;

        EObject this_Contains_1 = null;

        EObject this_Click_2 = null;

        EObject this_Set_3 = null;

        EObject this_Check_4 = null;

        EObject this_Uncheck_5 = null;

        EObject this_ChangeUrl_6 = null;

        EObject this_Read_7 = null;

        EObject this_Variable_8 = null;

        EObject this_Function_9 = null;

        EObject this_Count_10 = null;

        EObject this_EqualsTo_11 = null;

        EObject this_Call_12 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:113:2: ( (this_OpenBrowser_0= ruleOpenBrowser | this_Contains_1= ruleContains | this_Click_2= ruleClick | this_Set_3= ruleSet | this_Check_4= ruleCheck | this_Uncheck_5= ruleUncheck | this_ChangeUrl_6= ruleChangeUrl | this_Read_7= ruleRead | this_Variable_8= ruleVariable | this_Function_9= ruleFunction | this_Count_10= ruleCount | this_EqualsTo_11= ruleEqualsTo | this_Call_12= ruleCall ) )
            // InternalMyDsl.g:114:2: (this_OpenBrowser_0= ruleOpenBrowser | this_Contains_1= ruleContains | this_Click_2= ruleClick | this_Set_3= ruleSet | this_Check_4= ruleCheck | this_Uncheck_5= ruleUncheck | this_ChangeUrl_6= ruleChangeUrl | this_Read_7= ruleRead | this_Variable_8= ruleVariable | this_Function_9= ruleFunction | this_Count_10= ruleCount | this_EqualsTo_11= ruleEqualsTo | this_Call_12= ruleCall )
            {
            // InternalMyDsl.g:114:2: (this_OpenBrowser_0= ruleOpenBrowser | this_Contains_1= ruleContains | this_Click_2= ruleClick | this_Set_3= ruleSet | this_Check_4= ruleCheck | this_Uncheck_5= ruleUncheck | this_ChangeUrl_6= ruleChangeUrl | this_Read_7= ruleRead | this_Variable_8= ruleVariable | this_Function_9= ruleFunction | this_Count_10= ruleCount | this_EqualsTo_11= ruleEqualsTo | this_Call_12= ruleCall )
            int alt2=13;
            switch ( input.LA(1) ) {
            case 11:
                {
                alt2=1;
                }
                break;
            case 13:
                {
                alt2=2;
                }
                break;
            case 14:
                {
                alt2=3;
                }
                break;
            case 15:
                {
                alt2=4;
                }
                break;
            case 16:
                {
                alt2=5;
                }
                break;
            case 17:
                {
                alt2=6;
                }
                break;
            case 12:
                {
                alt2=7;
                }
                break;
            case 19:
                {
                alt2=8;
                }
                break;
            case 23:
                {
                alt2=9;
                }
                break;
            case 27:
                {
                alt2=10;
                }
                break;
            case 20:
                {
                alt2=11;
                }
                break;
            case 21:
                {
                alt2=12;
                }
                break;
            case 25:
                {
                alt2=13;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                throw nvae;
            }

            switch (alt2) {
                case 1 :
                    // InternalMyDsl.g:115:3: this_OpenBrowser_0= ruleOpenBrowser
                    {

                    			newCompositeNode(grammarAccess.getInstructionAccess().getOpenBrowserParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_OpenBrowser_0=ruleOpenBrowser();

                    state._fsp--;


                    			current = this_OpenBrowser_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:124:3: this_Contains_1= ruleContains
                    {

                    			newCompositeNode(grammarAccess.getInstructionAccess().getContainsParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_Contains_1=ruleContains();

                    state._fsp--;


                    			current = this_Contains_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalMyDsl.g:133:3: this_Click_2= ruleClick
                    {

                    			newCompositeNode(grammarAccess.getInstructionAccess().getClickParserRuleCall_2());
                    		
                    pushFollow(FOLLOW_2);
                    this_Click_2=ruleClick();

                    state._fsp--;


                    			current = this_Click_2;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 4 :
                    // InternalMyDsl.g:142:3: this_Set_3= ruleSet
                    {

                    			newCompositeNode(grammarAccess.getInstructionAccess().getSetParserRuleCall_3());
                    		
                    pushFollow(FOLLOW_2);
                    this_Set_3=ruleSet();

                    state._fsp--;


                    			current = this_Set_3;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 5 :
                    // InternalMyDsl.g:151:3: this_Check_4= ruleCheck
                    {

                    			newCompositeNode(grammarAccess.getInstructionAccess().getCheckParserRuleCall_4());
                    		
                    pushFollow(FOLLOW_2);
                    this_Check_4=ruleCheck();

                    state._fsp--;


                    			current = this_Check_4;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 6 :
                    // InternalMyDsl.g:160:3: this_Uncheck_5= ruleUncheck
                    {

                    			newCompositeNode(grammarAccess.getInstructionAccess().getUncheckParserRuleCall_5());
                    		
                    pushFollow(FOLLOW_2);
                    this_Uncheck_5=ruleUncheck();

                    state._fsp--;


                    			current = this_Uncheck_5;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 7 :
                    // InternalMyDsl.g:169:3: this_ChangeUrl_6= ruleChangeUrl
                    {

                    			newCompositeNode(grammarAccess.getInstructionAccess().getChangeUrlParserRuleCall_6());
                    		
                    pushFollow(FOLLOW_2);
                    this_ChangeUrl_6=ruleChangeUrl();

                    state._fsp--;


                    			current = this_ChangeUrl_6;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 8 :
                    // InternalMyDsl.g:178:3: this_Read_7= ruleRead
                    {

                    			newCompositeNode(grammarAccess.getInstructionAccess().getReadParserRuleCall_7());
                    		
                    pushFollow(FOLLOW_2);
                    this_Read_7=ruleRead();

                    state._fsp--;


                    			current = this_Read_7;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 9 :
                    // InternalMyDsl.g:187:3: this_Variable_8= ruleVariable
                    {

                    			newCompositeNode(grammarAccess.getInstructionAccess().getVariableParserRuleCall_8());
                    		
                    pushFollow(FOLLOW_2);
                    this_Variable_8=ruleVariable();

                    state._fsp--;


                    			current = this_Variable_8;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 10 :
                    // InternalMyDsl.g:196:3: this_Function_9= ruleFunction
                    {

                    			newCompositeNode(grammarAccess.getInstructionAccess().getFunctionParserRuleCall_9());
                    		
                    pushFollow(FOLLOW_2);
                    this_Function_9=ruleFunction();

                    state._fsp--;


                    			current = this_Function_9;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 11 :
                    // InternalMyDsl.g:205:3: this_Count_10= ruleCount
                    {

                    			newCompositeNode(grammarAccess.getInstructionAccess().getCountParserRuleCall_10());
                    		
                    pushFollow(FOLLOW_2);
                    this_Count_10=ruleCount();

                    state._fsp--;


                    			current = this_Count_10;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 12 :
                    // InternalMyDsl.g:214:3: this_EqualsTo_11= ruleEqualsTo
                    {

                    			newCompositeNode(grammarAccess.getInstructionAccess().getEqualsToParserRuleCall_11());
                    		
                    pushFollow(FOLLOW_2);
                    this_EqualsTo_11=ruleEqualsTo();

                    state._fsp--;


                    			current = this_EqualsTo_11;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 13 :
                    // InternalMyDsl.g:223:3: this_Call_12= ruleCall
                    {

                    			newCompositeNode(grammarAccess.getInstructionAccess().getCallParserRuleCall_12());
                    		
                    pushFollow(FOLLOW_2);
                    this_Call_12=ruleCall();

                    state._fsp--;


                    			current = this_Call_12;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleInstruction"


    // $ANTLR start "entryRuleOpenBrowser"
    // InternalMyDsl.g:235:1: entryRuleOpenBrowser returns [EObject current=null] : iv_ruleOpenBrowser= ruleOpenBrowser EOF ;
    public final EObject entryRuleOpenBrowser() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleOpenBrowser = null;


        try {
            // InternalMyDsl.g:235:52: (iv_ruleOpenBrowser= ruleOpenBrowser EOF )
            // InternalMyDsl.g:236:2: iv_ruleOpenBrowser= ruleOpenBrowser EOF
            {
             newCompositeNode(grammarAccess.getOpenBrowserRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleOpenBrowser=ruleOpenBrowser();

            state._fsp--;

             current =iv_ruleOpenBrowser; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleOpenBrowser"


    // $ANTLR start "ruleOpenBrowser"
    // InternalMyDsl.g:242:1: ruleOpenBrowser returns [EObject current=null] : (otherlv_0= 'open browser on url' ( (lv_url_1_0= RULE_STRING ) ) ) ;
    public final EObject ruleOpenBrowser() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_url_1_0=null;


        	enterRule();

        try {
            // InternalMyDsl.g:248:2: ( (otherlv_0= 'open browser on url' ( (lv_url_1_0= RULE_STRING ) ) ) )
            // InternalMyDsl.g:249:2: (otherlv_0= 'open browser on url' ( (lv_url_1_0= RULE_STRING ) ) )
            {
            // InternalMyDsl.g:249:2: (otherlv_0= 'open browser on url' ( (lv_url_1_0= RULE_STRING ) ) )
            // InternalMyDsl.g:250:3: otherlv_0= 'open browser on url' ( (lv_url_1_0= RULE_STRING ) )
            {
            otherlv_0=(Token)match(input,11,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getOpenBrowserAccess().getOpenBrowserOnUrlKeyword_0());
            		
            // InternalMyDsl.g:254:3: ( (lv_url_1_0= RULE_STRING ) )
            // InternalMyDsl.g:255:4: (lv_url_1_0= RULE_STRING )
            {
            // InternalMyDsl.g:255:4: (lv_url_1_0= RULE_STRING )
            // InternalMyDsl.g:256:5: lv_url_1_0= RULE_STRING
            {
            lv_url_1_0=(Token)match(input,RULE_STRING,FOLLOW_2); 

            					newLeafNode(lv_url_1_0, grammarAccess.getOpenBrowserAccess().getUrlSTRINGTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getOpenBrowserRule());
            					}
            					setWithLastConsumed(
            						current,
            						"url",
            						lv_url_1_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleOpenBrowser"


    // $ANTLR start "entryRuleChangeUrl"
    // InternalMyDsl.g:276:1: entryRuleChangeUrl returns [EObject current=null] : iv_ruleChangeUrl= ruleChangeUrl EOF ;
    public final EObject entryRuleChangeUrl() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleChangeUrl = null;


        try {
            // InternalMyDsl.g:276:50: (iv_ruleChangeUrl= ruleChangeUrl EOF )
            // InternalMyDsl.g:277:2: iv_ruleChangeUrl= ruleChangeUrl EOF
            {
             newCompositeNode(grammarAccess.getChangeUrlRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleChangeUrl=ruleChangeUrl();

            state._fsp--;

             current =iv_ruleChangeUrl; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleChangeUrl"


    // $ANTLR start "ruleChangeUrl"
    // InternalMyDsl.g:283:1: ruleChangeUrl returns [EObject current=null] : (otherlv_0= 'change url' ( (lv_url_1_0= RULE_STRING ) ) ) ;
    public final EObject ruleChangeUrl() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_url_1_0=null;


        	enterRule();

        try {
            // InternalMyDsl.g:289:2: ( (otherlv_0= 'change url' ( (lv_url_1_0= RULE_STRING ) ) ) )
            // InternalMyDsl.g:290:2: (otherlv_0= 'change url' ( (lv_url_1_0= RULE_STRING ) ) )
            {
            // InternalMyDsl.g:290:2: (otherlv_0= 'change url' ( (lv_url_1_0= RULE_STRING ) ) )
            // InternalMyDsl.g:291:3: otherlv_0= 'change url' ( (lv_url_1_0= RULE_STRING ) )
            {
            otherlv_0=(Token)match(input,12,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getChangeUrlAccess().getChangeUrlKeyword_0());
            		
            // InternalMyDsl.g:295:3: ( (lv_url_1_0= RULE_STRING ) )
            // InternalMyDsl.g:296:4: (lv_url_1_0= RULE_STRING )
            {
            // InternalMyDsl.g:296:4: (lv_url_1_0= RULE_STRING )
            // InternalMyDsl.g:297:5: lv_url_1_0= RULE_STRING
            {
            lv_url_1_0=(Token)match(input,RULE_STRING,FOLLOW_2); 

            					newLeafNode(lv_url_1_0, grammarAccess.getChangeUrlAccess().getUrlSTRINGTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getChangeUrlRule());
            					}
            					setWithLastConsumed(
            						current,
            						"url",
            						lv_url_1_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleChangeUrl"


    // $ANTLR start "entryRuleContains"
    // InternalMyDsl.g:317:1: entryRuleContains returns [EObject current=null] : iv_ruleContains= ruleContains EOF ;
    public final EObject entryRuleContains() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleContains = null;


        try {
            // InternalMyDsl.g:317:49: (iv_ruleContains= ruleContains EOF )
            // InternalMyDsl.g:318:2: iv_ruleContains= ruleContains EOF
            {
             newCompositeNode(grammarAccess.getContainsRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleContains=ruleContains();

            state._fsp--;

             current =iv_ruleContains; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleContains"


    // $ANTLR start "ruleContains"
    // InternalMyDsl.g:324:1: ruleContains returns [EObject current=null] : (otherlv_0= 'contains' ( (lv_type_1_0= ruleTypeElement ) ) ( (lv_valeur_2_0= ruleName ) ) ) ;
    public final EObject ruleContains() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        AntlrDatatypeRuleToken lv_type_1_0 = null;

        EObject lv_valeur_2_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:330:2: ( (otherlv_0= 'contains' ( (lv_type_1_0= ruleTypeElement ) ) ( (lv_valeur_2_0= ruleName ) ) ) )
            // InternalMyDsl.g:331:2: (otherlv_0= 'contains' ( (lv_type_1_0= ruleTypeElement ) ) ( (lv_valeur_2_0= ruleName ) ) )
            {
            // InternalMyDsl.g:331:2: (otherlv_0= 'contains' ( (lv_type_1_0= ruleTypeElement ) ) ( (lv_valeur_2_0= ruleName ) ) )
            // InternalMyDsl.g:332:3: otherlv_0= 'contains' ( (lv_type_1_0= ruleTypeElement ) ) ( (lv_valeur_2_0= ruleName ) )
            {
            otherlv_0=(Token)match(input,13,FOLLOW_5); 

            			newLeafNode(otherlv_0, grammarAccess.getContainsAccess().getContainsKeyword_0());
            		
            // InternalMyDsl.g:336:3: ( (lv_type_1_0= ruleTypeElement ) )
            // InternalMyDsl.g:337:4: (lv_type_1_0= ruleTypeElement )
            {
            // InternalMyDsl.g:337:4: (lv_type_1_0= ruleTypeElement )
            // InternalMyDsl.g:338:5: lv_type_1_0= ruleTypeElement
            {

            					newCompositeNode(grammarAccess.getContainsAccess().getTypeTypeElementParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_6);
            lv_type_1_0=ruleTypeElement();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getContainsRule());
            					}
            					set(
            						current,
            						"type",
            						lv_type_1_0,
            						"org.xtext.example.mydsl.MyDsl.TypeElement");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalMyDsl.g:355:3: ( (lv_valeur_2_0= ruleName ) )
            // InternalMyDsl.g:356:4: (lv_valeur_2_0= ruleName )
            {
            // InternalMyDsl.g:356:4: (lv_valeur_2_0= ruleName )
            // InternalMyDsl.g:357:5: lv_valeur_2_0= ruleName
            {

            					newCompositeNode(grammarAccess.getContainsAccess().getValeurNameParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_2);
            lv_valeur_2_0=ruleName();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getContainsRule());
            					}
            					set(
            						current,
            						"valeur",
            						lv_valeur_2_0,
            						"org.xtext.example.mydsl.MyDsl.Name");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleContains"


    // $ANTLR start "entryRuleClick"
    // InternalMyDsl.g:378:1: entryRuleClick returns [EObject current=null] : iv_ruleClick= ruleClick EOF ;
    public final EObject entryRuleClick() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleClick = null;


        try {
            // InternalMyDsl.g:378:46: (iv_ruleClick= ruleClick EOF )
            // InternalMyDsl.g:379:2: iv_ruleClick= ruleClick EOF
            {
             newCompositeNode(grammarAccess.getClickRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleClick=ruleClick();

            state._fsp--;

             current =iv_ruleClick; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleClick"


    // $ANTLR start "ruleClick"
    // InternalMyDsl.g:385:1: ruleClick returns [EObject current=null] : (otherlv_0= 'click' ( (lv_type_1_0= ruleTypeElement ) ) ( (lv_valeur_2_0= ruleName ) ) ) ;
    public final EObject ruleClick() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        AntlrDatatypeRuleToken lv_type_1_0 = null;

        EObject lv_valeur_2_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:391:2: ( (otherlv_0= 'click' ( (lv_type_1_0= ruleTypeElement ) ) ( (lv_valeur_2_0= ruleName ) ) ) )
            // InternalMyDsl.g:392:2: (otherlv_0= 'click' ( (lv_type_1_0= ruleTypeElement ) ) ( (lv_valeur_2_0= ruleName ) ) )
            {
            // InternalMyDsl.g:392:2: (otherlv_0= 'click' ( (lv_type_1_0= ruleTypeElement ) ) ( (lv_valeur_2_0= ruleName ) ) )
            // InternalMyDsl.g:393:3: otherlv_0= 'click' ( (lv_type_1_0= ruleTypeElement ) ) ( (lv_valeur_2_0= ruleName ) )
            {
            otherlv_0=(Token)match(input,14,FOLLOW_5); 

            			newLeafNode(otherlv_0, grammarAccess.getClickAccess().getClickKeyword_0());
            		
            // InternalMyDsl.g:397:3: ( (lv_type_1_0= ruleTypeElement ) )
            // InternalMyDsl.g:398:4: (lv_type_1_0= ruleTypeElement )
            {
            // InternalMyDsl.g:398:4: (lv_type_1_0= ruleTypeElement )
            // InternalMyDsl.g:399:5: lv_type_1_0= ruleTypeElement
            {

            					newCompositeNode(grammarAccess.getClickAccess().getTypeTypeElementParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_6);
            lv_type_1_0=ruleTypeElement();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getClickRule());
            					}
            					set(
            						current,
            						"type",
            						lv_type_1_0,
            						"org.xtext.example.mydsl.MyDsl.TypeElement");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalMyDsl.g:416:3: ( (lv_valeur_2_0= ruleName ) )
            // InternalMyDsl.g:417:4: (lv_valeur_2_0= ruleName )
            {
            // InternalMyDsl.g:417:4: (lv_valeur_2_0= ruleName )
            // InternalMyDsl.g:418:5: lv_valeur_2_0= ruleName
            {

            					newCompositeNode(grammarAccess.getClickAccess().getValeurNameParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_2);
            lv_valeur_2_0=ruleName();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getClickRule());
            					}
            					set(
            						current,
            						"valeur",
            						lv_valeur_2_0,
            						"org.xtext.example.mydsl.MyDsl.Name");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleClick"


    // $ANTLR start "entryRuleSet"
    // InternalMyDsl.g:439:1: entryRuleSet returns [EObject current=null] : iv_ruleSet= ruleSet EOF ;
    public final EObject entryRuleSet() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSet = null;


        try {
            // InternalMyDsl.g:439:44: (iv_ruleSet= ruleSet EOF )
            // InternalMyDsl.g:440:2: iv_ruleSet= ruleSet EOF
            {
             newCompositeNode(grammarAccess.getSetRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSet=ruleSet();

            state._fsp--;

             current =iv_ruleSet; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSet"


    // $ANTLR start "ruleSet"
    // InternalMyDsl.g:446:1: ruleSet returns [EObject current=null] : (otherlv_0= 'set' ( (lv_type_1_0= ruleTypeSet ) ) ( (lv_name_2_0= ruleName ) ) ( (lv_value_3_0= ruleValue ) ) ) ;
    public final EObject ruleSet() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        AntlrDatatypeRuleToken lv_type_1_0 = null;

        EObject lv_name_2_0 = null;

        EObject lv_value_3_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:452:2: ( (otherlv_0= 'set' ( (lv_type_1_0= ruleTypeSet ) ) ( (lv_name_2_0= ruleName ) ) ( (lv_value_3_0= ruleValue ) ) ) )
            // InternalMyDsl.g:453:2: (otherlv_0= 'set' ( (lv_type_1_0= ruleTypeSet ) ) ( (lv_name_2_0= ruleName ) ) ( (lv_value_3_0= ruleValue ) ) )
            {
            // InternalMyDsl.g:453:2: (otherlv_0= 'set' ( (lv_type_1_0= ruleTypeSet ) ) ( (lv_name_2_0= ruleName ) ) ( (lv_value_3_0= ruleValue ) ) )
            // InternalMyDsl.g:454:3: otherlv_0= 'set' ( (lv_type_1_0= ruleTypeSet ) ) ( (lv_name_2_0= ruleName ) ) ( (lv_value_3_0= ruleValue ) )
            {
            otherlv_0=(Token)match(input,15,FOLLOW_7); 

            			newLeafNode(otherlv_0, grammarAccess.getSetAccess().getSetKeyword_0());
            		
            // InternalMyDsl.g:458:3: ( (lv_type_1_0= ruleTypeSet ) )
            // InternalMyDsl.g:459:4: (lv_type_1_0= ruleTypeSet )
            {
            // InternalMyDsl.g:459:4: (lv_type_1_0= ruleTypeSet )
            // InternalMyDsl.g:460:5: lv_type_1_0= ruleTypeSet
            {

            					newCompositeNode(grammarAccess.getSetAccess().getTypeTypeSetParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_6);
            lv_type_1_0=ruleTypeSet();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getSetRule());
            					}
            					set(
            						current,
            						"type",
            						lv_type_1_0,
            						"org.xtext.example.mydsl.MyDsl.TypeSet");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalMyDsl.g:477:3: ( (lv_name_2_0= ruleName ) )
            // InternalMyDsl.g:478:4: (lv_name_2_0= ruleName )
            {
            // InternalMyDsl.g:478:4: (lv_name_2_0= ruleName )
            // InternalMyDsl.g:479:5: lv_name_2_0= ruleName
            {

            					newCompositeNode(grammarAccess.getSetAccess().getNameNameParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_8);
            lv_name_2_0=ruleName();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getSetRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_2_0,
            						"org.xtext.example.mydsl.MyDsl.Name");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalMyDsl.g:496:3: ( (lv_value_3_0= ruleValue ) )
            // InternalMyDsl.g:497:4: (lv_value_3_0= ruleValue )
            {
            // InternalMyDsl.g:497:4: (lv_value_3_0= ruleValue )
            // InternalMyDsl.g:498:5: lv_value_3_0= ruleValue
            {

            					newCompositeNode(grammarAccess.getSetAccess().getValueValueParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_2);
            lv_value_3_0=ruleValue();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getSetRule());
            					}
            					set(
            						current,
            						"value",
            						lv_value_3_0,
            						"org.xtext.example.mydsl.MyDsl.Value");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSet"


    // $ANTLR start "entryRuleCheck"
    // InternalMyDsl.g:519:1: entryRuleCheck returns [EObject current=null] : iv_ruleCheck= ruleCheck EOF ;
    public final EObject entryRuleCheck() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleCheck = null;


        try {
            // InternalMyDsl.g:519:46: (iv_ruleCheck= ruleCheck EOF )
            // InternalMyDsl.g:520:2: iv_ruleCheck= ruleCheck EOF
            {
             newCompositeNode(grammarAccess.getCheckRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleCheck=ruleCheck();

            state._fsp--;

             current =iv_ruleCheck; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCheck"


    // $ANTLR start "ruleCheck"
    // InternalMyDsl.g:526:1: ruleCheck returns [EObject current=null] : (otherlv_0= 'check' ruleTypeCheckBox ( (lv_optionCheck_2_0= ruleName ) ) ) ;
    public final EObject ruleCheck() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        EObject lv_optionCheck_2_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:532:2: ( (otherlv_0= 'check' ruleTypeCheckBox ( (lv_optionCheck_2_0= ruleName ) ) ) )
            // InternalMyDsl.g:533:2: (otherlv_0= 'check' ruleTypeCheckBox ( (lv_optionCheck_2_0= ruleName ) ) )
            {
            // InternalMyDsl.g:533:2: (otherlv_0= 'check' ruleTypeCheckBox ( (lv_optionCheck_2_0= ruleName ) ) )
            // InternalMyDsl.g:534:3: otherlv_0= 'check' ruleTypeCheckBox ( (lv_optionCheck_2_0= ruleName ) )
            {
            otherlv_0=(Token)match(input,16,FOLLOW_9); 

            			newLeafNode(otherlv_0, grammarAccess.getCheckAccess().getCheckKeyword_0());
            		

            			newCompositeNode(grammarAccess.getCheckAccess().getTypeCheckBoxParserRuleCall_1());
            		
            pushFollow(FOLLOW_6);
            ruleTypeCheckBox();

            state._fsp--;


            			afterParserOrEnumRuleCall();
            		
            // InternalMyDsl.g:545:3: ( (lv_optionCheck_2_0= ruleName ) )
            // InternalMyDsl.g:546:4: (lv_optionCheck_2_0= ruleName )
            {
            // InternalMyDsl.g:546:4: (lv_optionCheck_2_0= ruleName )
            // InternalMyDsl.g:547:5: lv_optionCheck_2_0= ruleName
            {

            					newCompositeNode(grammarAccess.getCheckAccess().getOptionCheckNameParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_2);
            lv_optionCheck_2_0=ruleName();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getCheckRule());
            					}
            					set(
            						current,
            						"optionCheck",
            						lv_optionCheck_2_0,
            						"org.xtext.example.mydsl.MyDsl.Name");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCheck"


    // $ANTLR start "entryRuleUncheck"
    // InternalMyDsl.g:568:1: entryRuleUncheck returns [EObject current=null] : iv_ruleUncheck= ruleUncheck EOF ;
    public final EObject entryRuleUncheck() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleUncheck = null;


        try {
            // InternalMyDsl.g:568:48: (iv_ruleUncheck= ruleUncheck EOF )
            // InternalMyDsl.g:569:2: iv_ruleUncheck= ruleUncheck EOF
            {
             newCompositeNode(grammarAccess.getUncheckRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleUncheck=ruleUncheck();

            state._fsp--;

             current =iv_ruleUncheck; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleUncheck"


    // $ANTLR start "ruleUncheck"
    // InternalMyDsl.g:575:1: ruleUncheck returns [EObject current=null] : ( () otherlv_1= 'uncheck' ruleTypeCheckBox ( ( (lv_optionUncheck_3_0= ruleName ) )? | otherlv_4= 'all' ) ) ;
    public final EObject ruleUncheck() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_4=null;
        EObject lv_optionUncheck_3_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:581:2: ( ( () otherlv_1= 'uncheck' ruleTypeCheckBox ( ( (lv_optionUncheck_3_0= ruleName ) )? | otherlv_4= 'all' ) ) )
            // InternalMyDsl.g:582:2: ( () otherlv_1= 'uncheck' ruleTypeCheckBox ( ( (lv_optionUncheck_3_0= ruleName ) )? | otherlv_4= 'all' ) )
            {
            // InternalMyDsl.g:582:2: ( () otherlv_1= 'uncheck' ruleTypeCheckBox ( ( (lv_optionUncheck_3_0= ruleName ) )? | otherlv_4= 'all' ) )
            // InternalMyDsl.g:583:3: () otherlv_1= 'uncheck' ruleTypeCheckBox ( ( (lv_optionUncheck_3_0= ruleName ) )? | otherlv_4= 'all' )
            {
            // InternalMyDsl.g:583:3: ()
            // InternalMyDsl.g:584:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getUncheckAccess().getUncheckAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,17,FOLLOW_9); 

            			newLeafNode(otherlv_1, grammarAccess.getUncheckAccess().getUncheckKeyword_1());
            		

            			newCompositeNode(grammarAccess.getUncheckAccess().getTypeCheckBoxParserRuleCall_2());
            		
            pushFollow(FOLLOW_10);
            ruleTypeCheckBox();

            state._fsp--;


            			afterParserOrEnumRuleCall();
            		
            // InternalMyDsl.g:601:3: ( ( (lv_optionUncheck_3_0= ruleName ) )? | otherlv_4= 'all' )
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0==EOF||(LA4_0>=11 && LA4_0<=17)||(LA4_0>=19 && LA4_0<=21)||LA4_0==23||LA4_0==25||LA4_0==27||(LA4_0>=29 && LA4_0<=30)) ) {
                alt4=1;
            }
            else if ( (LA4_0==18) ) {
                alt4=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 4, 0, input);

                throw nvae;
            }
            switch (alt4) {
                case 1 :
                    // InternalMyDsl.g:602:4: ( (lv_optionUncheck_3_0= ruleName ) )?
                    {
                    // InternalMyDsl.g:602:4: ( (lv_optionUncheck_3_0= ruleName ) )?
                    int alt3=2;
                    int LA3_0 = input.LA(1);

                    if ( (LA3_0==30) ) {
                        alt3=1;
                    }
                    switch (alt3) {
                        case 1 :
                            // InternalMyDsl.g:603:5: (lv_optionUncheck_3_0= ruleName )
                            {
                            // InternalMyDsl.g:603:5: (lv_optionUncheck_3_0= ruleName )
                            // InternalMyDsl.g:604:6: lv_optionUncheck_3_0= ruleName
                            {

                            						newCompositeNode(grammarAccess.getUncheckAccess().getOptionUncheckNameParserRuleCall_3_0_0());
                            					
                            pushFollow(FOLLOW_2);
                            lv_optionUncheck_3_0=ruleName();

                            state._fsp--;


                            						if (current==null) {
                            							current = createModelElementForParent(grammarAccess.getUncheckRule());
                            						}
                            						set(
                            							current,
                            							"optionUncheck",
                            							lv_optionUncheck_3_0,
                            							"org.xtext.example.mydsl.MyDsl.Name");
                            						afterParserOrEnumRuleCall();
                            					

                            }


                            }
                            break;

                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:622:4: otherlv_4= 'all'
                    {
                    otherlv_4=(Token)match(input,18,FOLLOW_2); 

                    				newLeafNode(otherlv_4, grammarAccess.getUncheckAccess().getAllKeyword_3_1());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleUncheck"


    // $ANTLR start "entryRuleRead"
    // InternalMyDsl.g:631:1: entryRuleRead returns [EObject current=null] : iv_ruleRead= ruleRead EOF ;
    public final EObject entryRuleRead() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRead = null;


        try {
            // InternalMyDsl.g:631:45: (iv_ruleRead= ruleRead EOF )
            // InternalMyDsl.g:632:2: iv_ruleRead= ruleRead EOF
            {
             newCompositeNode(grammarAccess.getReadRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleRead=ruleRead();

            state._fsp--;

             current =iv_ruleRead; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRead"


    // $ANTLR start "ruleRead"
    // InternalMyDsl.g:638:1: ruleRead returns [EObject current=null] : (otherlv_0= 'read' ( (lv_type_1_0= ruleTypeProperty ) ) ruleOfTitle ( (lv_name_3_0= ruleName ) ) ) ;
    public final EObject ruleRead() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        AntlrDatatypeRuleToken lv_type_1_0 = null;

        EObject lv_name_3_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:644:2: ( (otherlv_0= 'read' ( (lv_type_1_0= ruleTypeProperty ) ) ruleOfTitle ( (lv_name_3_0= ruleName ) ) ) )
            // InternalMyDsl.g:645:2: (otherlv_0= 'read' ( (lv_type_1_0= ruleTypeProperty ) ) ruleOfTitle ( (lv_name_3_0= ruleName ) ) )
            {
            // InternalMyDsl.g:645:2: (otherlv_0= 'read' ( (lv_type_1_0= ruleTypeProperty ) ) ruleOfTitle ( (lv_name_3_0= ruleName ) ) )
            // InternalMyDsl.g:646:3: otherlv_0= 'read' ( (lv_type_1_0= ruleTypeProperty ) ) ruleOfTitle ( (lv_name_3_0= ruleName ) )
            {
            otherlv_0=(Token)match(input,19,FOLLOW_11); 

            			newLeafNode(otherlv_0, grammarAccess.getReadAccess().getReadKeyword_0());
            		
            // InternalMyDsl.g:650:3: ( (lv_type_1_0= ruleTypeProperty ) )
            // InternalMyDsl.g:651:4: (lv_type_1_0= ruleTypeProperty )
            {
            // InternalMyDsl.g:651:4: (lv_type_1_0= ruleTypeProperty )
            // InternalMyDsl.g:652:5: lv_type_1_0= ruleTypeProperty
            {

            					newCompositeNode(grammarAccess.getReadAccess().getTypeTypePropertyParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_12);
            lv_type_1_0=ruleTypeProperty();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getReadRule());
            					}
            					set(
            						current,
            						"type",
            						lv_type_1_0,
            						"org.xtext.example.mydsl.MyDsl.TypeProperty");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            			newCompositeNode(grammarAccess.getReadAccess().getOfTitleParserRuleCall_2());
            		
            pushFollow(FOLLOW_6);
            ruleOfTitle();

            state._fsp--;


            			afterParserOrEnumRuleCall();
            		
            // InternalMyDsl.g:676:3: ( (lv_name_3_0= ruleName ) )
            // InternalMyDsl.g:677:4: (lv_name_3_0= ruleName )
            {
            // InternalMyDsl.g:677:4: (lv_name_3_0= ruleName )
            // InternalMyDsl.g:678:5: lv_name_3_0= ruleName
            {

            					newCompositeNode(grammarAccess.getReadAccess().getNameNameParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_2);
            lv_name_3_0=ruleName();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getReadRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_3_0,
            						"org.xtext.example.mydsl.MyDsl.Name");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRead"


    // $ANTLR start "entryRuleCount"
    // InternalMyDsl.g:699:1: entryRuleCount returns [EObject current=null] : iv_ruleCount= ruleCount EOF ;
    public final EObject entryRuleCount() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleCount = null;


        try {
            // InternalMyDsl.g:699:46: (iv_ruleCount= ruleCount EOF )
            // InternalMyDsl.g:700:2: iv_ruleCount= ruleCount EOF
            {
             newCompositeNode(grammarAccess.getCountRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleCount=ruleCount();

            state._fsp--;

             current =iv_ruleCount; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCount"


    // $ANTLR start "ruleCount"
    // InternalMyDsl.g:706:1: ruleCount returns [EObject current=null] : (otherlv_0= 'count' ruleTypeElement this_Name_2= ruleName ) ;
    public final EObject ruleCount() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        EObject this_Name_2 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:712:2: ( (otherlv_0= 'count' ruleTypeElement this_Name_2= ruleName ) )
            // InternalMyDsl.g:713:2: (otherlv_0= 'count' ruleTypeElement this_Name_2= ruleName )
            {
            // InternalMyDsl.g:713:2: (otherlv_0= 'count' ruleTypeElement this_Name_2= ruleName )
            // InternalMyDsl.g:714:3: otherlv_0= 'count' ruleTypeElement this_Name_2= ruleName
            {
            otherlv_0=(Token)match(input,20,FOLLOW_5); 

            			newLeafNode(otherlv_0, grammarAccess.getCountAccess().getCountKeyword_0());
            		

            			newCompositeNode(grammarAccess.getCountAccess().getTypeElementParserRuleCall_1());
            		
            pushFollow(FOLLOW_6);
            ruleTypeElement();

            state._fsp--;


            			afterParserOrEnumRuleCall();
            		

            			newCompositeNode(grammarAccess.getCountAccess().getNameParserRuleCall_2());
            		
            pushFollow(FOLLOW_2);
            this_Name_2=ruleName();

            state._fsp--;


            			current = this_Name_2;
            			afterParserOrEnumRuleCall();
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCount"


    // $ANTLR start "entryRuleEqualsTo"
    // InternalMyDsl.g:737:1: entryRuleEqualsTo returns [EObject current=null] : iv_ruleEqualsTo= ruleEqualsTo EOF ;
    public final EObject entryRuleEqualsTo() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleEqualsTo = null;


        try {
            // InternalMyDsl.g:737:49: (iv_ruleEqualsTo= ruleEqualsTo EOF )
            // InternalMyDsl.g:738:2: iv_ruleEqualsTo= ruleEqualsTo EOF
            {
             newCompositeNode(grammarAccess.getEqualsToRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEqualsTo=ruleEqualsTo();

            state._fsp--;

             current =iv_ruleEqualsTo; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEqualsTo"


    // $ANTLR start "ruleEqualsTo"
    // InternalMyDsl.g:744:1: ruleEqualsTo returns [EObject current=null] : (otherlv_0= 'equals to' ( (lv_elmt1_1_0= RULE_ID ) ) ( (lv_elmt2_2_0= RULE_ID ) ) ) ;
    public final EObject ruleEqualsTo() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_elmt1_1_0=null;
        Token lv_elmt2_2_0=null;


        	enterRule();

        try {
            // InternalMyDsl.g:750:2: ( (otherlv_0= 'equals to' ( (lv_elmt1_1_0= RULE_ID ) ) ( (lv_elmt2_2_0= RULE_ID ) ) ) )
            // InternalMyDsl.g:751:2: (otherlv_0= 'equals to' ( (lv_elmt1_1_0= RULE_ID ) ) ( (lv_elmt2_2_0= RULE_ID ) ) )
            {
            // InternalMyDsl.g:751:2: (otherlv_0= 'equals to' ( (lv_elmt1_1_0= RULE_ID ) ) ( (lv_elmt2_2_0= RULE_ID ) ) )
            // InternalMyDsl.g:752:3: otherlv_0= 'equals to' ( (lv_elmt1_1_0= RULE_ID ) ) ( (lv_elmt2_2_0= RULE_ID ) )
            {
            otherlv_0=(Token)match(input,21,FOLLOW_13); 

            			newLeafNode(otherlv_0, grammarAccess.getEqualsToAccess().getEqualsToKeyword_0());
            		
            // InternalMyDsl.g:756:3: ( (lv_elmt1_1_0= RULE_ID ) )
            // InternalMyDsl.g:757:4: (lv_elmt1_1_0= RULE_ID )
            {
            // InternalMyDsl.g:757:4: (lv_elmt1_1_0= RULE_ID )
            // InternalMyDsl.g:758:5: lv_elmt1_1_0= RULE_ID
            {
            lv_elmt1_1_0=(Token)match(input,RULE_ID,FOLLOW_13); 

            					newLeafNode(lv_elmt1_1_0, grammarAccess.getEqualsToAccess().getElmt1IDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEqualsToRule());
            					}
            					setWithLastConsumed(
            						current,
            						"elmt1",
            						lv_elmt1_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalMyDsl.g:774:3: ( (lv_elmt2_2_0= RULE_ID ) )
            // InternalMyDsl.g:775:4: (lv_elmt2_2_0= RULE_ID )
            {
            // InternalMyDsl.g:775:4: (lv_elmt2_2_0= RULE_ID )
            // InternalMyDsl.g:776:5: lv_elmt2_2_0= RULE_ID
            {
            lv_elmt2_2_0=(Token)match(input,RULE_ID,FOLLOW_2); 

            					newLeafNode(lv_elmt2_2_0, grammarAccess.getEqualsToAccess().getElmt2IDTerminalRuleCall_2_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEqualsToRule());
            					}
            					setWithLastConsumed(
            						current,
            						"elmt2",
            						lv_elmt2_2_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEqualsTo"


    // $ANTLR start "entryRuleOfTitle"
    // InternalMyDsl.g:796:1: entryRuleOfTitle returns [String current=null] : iv_ruleOfTitle= ruleOfTitle EOF ;
    public final String entryRuleOfTitle() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleOfTitle = null;


        try {
            // InternalMyDsl.g:796:47: (iv_ruleOfTitle= ruleOfTitle EOF )
            // InternalMyDsl.g:797:2: iv_ruleOfTitle= ruleOfTitle EOF
            {
             newCompositeNode(grammarAccess.getOfTitleRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleOfTitle=ruleOfTitle();

            state._fsp--;

             current =iv_ruleOfTitle.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleOfTitle"


    // $ANTLR start "ruleOfTitle"
    // InternalMyDsl.g:803:1: ruleOfTitle returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : kw= 'of title' ;
    public final AntlrDatatypeRuleToken ruleOfTitle() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalMyDsl.g:809:2: (kw= 'of title' )
            // InternalMyDsl.g:810:2: kw= 'of title'
            {
            kw=(Token)match(input,22,FOLLOW_2); 

            		current.merge(kw);
            		newLeafNode(kw, grammarAccess.getOfTitleAccess().getOfTitleKeyword());
            	

            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleOfTitle"


    // $ANTLR start "entryRuleVariable"
    // InternalMyDsl.g:818:1: entryRuleVariable returns [EObject current=null] : iv_ruleVariable= ruleVariable EOF ;
    public final EObject entryRuleVariable() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleVariable = null;


        try {
            // InternalMyDsl.g:818:49: (iv_ruleVariable= ruleVariable EOF )
            // InternalMyDsl.g:819:2: iv_ruleVariable= ruleVariable EOF
            {
             newCompositeNode(grammarAccess.getVariableRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleVariable=ruleVariable();

            state._fsp--;

             current =iv_ruleVariable; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleVariable"


    // $ANTLR start "ruleVariable"
    // InternalMyDsl.g:825:1: ruleVariable returns [EObject current=null] : (otherlv_0= 'var' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '=' ( ( (lv_val_3_1= ruleRead | lv_val_3_2= ruleCount ) ) ) ) ;
    public final EObject ruleVariable() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        EObject lv_val_3_1 = null;

        EObject lv_val_3_2 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:831:2: ( (otherlv_0= 'var' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '=' ( ( (lv_val_3_1= ruleRead | lv_val_3_2= ruleCount ) ) ) ) )
            // InternalMyDsl.g:832:2: (otherlv_0= 'var' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '=' ( ( (lv_val_3_1= ruleRead | lv_val_3_2= ruleCount ) ) ) )
            {
            // InternalMyDsl.g:832:2: (otherlv_0= 'var' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '=' ( ( (lv_val_3_1= ruleRead | lv_val_3_2= ruleCount ) ) ) )
            // InternalMyDsl.g:833:3: otherlv_0= 'var' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '=' ( ( (lv_val_3_1= ruleRead | lv_val_3_2= ruleCount ) ) )
            {
            otherlv_0=(Token)match(input,23,FOLLOW_13); 

            			newLeafNode(otherlv_0, grammarAccess.getVariableAccess().getVarKeyword_0());
            		
            // InternalMyDsl.g:837:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalMyDsl.g:838:4: (lv_name_1_0= RULE_ID )
            {
            // InternalMyDsl.g:838:4: (lv_name_1_0= RULE_ID )
            // InternalMyDsl.g:839:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_14); 

            					newLeafNode(lv_name_1_0, grammarAccess.getVariableAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getVariableRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_2=(Token)match(input,24,FOLLOW_15); 

            			newLeafNode(otherlv_2, grammarAccess.getVariableAccess().getEqualsSignKeyword_2());
            		
            // InternalMyDsl.g:859:3: ( ( (lv_val_3_1= ruleRead | lv_val_3_2= ruleCount ) ) )
            // InternalMyDsl.g:860:4: ( (lv_val_3_1= ruleRead | lv_val_3_2= ruleCount ) )
            {
            // InternalMyDsl.g:860:4: ( (lv_val_3_1= ruleRead | lv_val_3_2= ruleCount ) )
            // InternalMyDsl.g:861:5: (lv_val_3_1= ruleRead | lv_val_3_2= ruleCount )
            {
            // InternalMyDsl.g:861:5: (lv_val_3_1= ruleRead | lv_val_3_2= ruleCount )
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==19) ) {
                alt5=1;
            }
            else if ( (LA5_0==20) ) {
                alt5=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 5, 0, input);

                throw nvae;
            }
            switch (alt5) {
                case 1 :
                    // InternalMyDsl.g:862:6: lv_val_3_1= ruleRead
                    {

                    						newCompositeNode(grammarAccess.getVariableAccess().getValReadParserRuleCall_3_0_0());
                    					
                    pushFollow(FOLLOW_2);
                    lv_val_3_1=ruleRead();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getVariableRule());
                    						}
                    						set(
                    							current,
                    							"val",
                    							lv_val_3_1,
                    							"org.xtext.example.mydsl.MyDsl.Read");
                    						afterParserOrEnumRuleCall();
                    					

                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:878:6: lv_val_3_2= ruleCount
                    {

                    						newCompositeNode(grammarAccess.getVariableAccess().getValCountParserRuleCall_3_0_1());
                    					
                    pushFollow(FOLLOW_2);
                    lv_val_3_2=ruleCount();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getVariableRule());
                    						}
                    						set(
                    							current,
                    							"val",
                    							lv_val_3_2,
                    							"org.xtext.example.mydsl.MyDsl.Count");
                    						afterParserOrEnumRuleCall();
                    					

                    }
                    break;

            }


            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleVariable"


    // $ANTLR start "entryRuleCall"
    // InternalMyDsl.g:900:1: entryRuleCall returns [EObject current=null] : iv_ruleCall= ruleCall EOF ;
    public final EObject entryRuleCall() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleCall = null;


        try {
            // InternalMyDsl.g:900:45: (iv_ruleCall= ruleCall EOF )
            // InternalMyDsl.g:901:2: iv_ruleCall= ruleCall EOF
            {
             newCompositeNode(grammarAccess.getCallRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleCall=ruleCall();

            state._fsp--;

             current =iv_ruleCall; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCall"


    // $ANTLR start "ruleCall"
    // InternalMyDsl.g:907:1: ruleCall returns [EObject current=null] : (otherlv_0= 'call' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'parameters' ( (lv_param_3_0= ruleParameter ) ) ) ;
    public final EObject ruleCall() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        AntlrDatatypeRuleToken lv_param_3_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:913:2: ( (otherlv_0= 'call' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'parameters' ( (lv_param_3_0= ruleParameter ) ) ) )
            // InternalMyDsl.g:914:2: (otherlv_0= 'call' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'parameters' ( (lv_param_3_0= ruleParameter ) ) )
            {
            // InternalMyDsl.g:914:2: (otherlv_0= 'call' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'parameters' ( (lv_param_3_0= ruleParameter ) ) )
            // InternalMyDsl.g:915:3: otherlv_0= 'call' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'parameters' ( (lv_param_3_0= ruleParameter ) )
            {
            otherlv_0=(Token)match(input,25,FOLLOW_13); 

            			newLeafNode(otherlv_0, grammarAccess.getCallAccess().getCallKeyword_0());
            		
            // InternalMyDsl.g:919:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalMyDsl.g:920:4: (lv_name_1_0= RULE_ID )
            {
            // InternalMyDsl.g:920:4: (lv_name_1_0= RULE_ID )
            // InternalMyDsl.g:921:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_16); 

            					newLeafNode(lv_name_1_0, grammarAccess.getCallAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getCallRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_2=(Token)match(input,26,FOLLOW_17); 

            			newLeafNode(otherlv_2, grammarAccess.getCallAccess().getParametersKeyword_2());
            		
            // InternalMyDsl.g:941:3: ( (lv_param_3_0= ruleParameter ) )
            // InternalMyDsl.g:942:4: (lv_param_3_0= ruleParameter )
            {
            // InternalMyDsl.g:942:4: (lv_param_3_0= ruleParameter )
            // InternalMyDsl.g:943:5: lv_param_3_0= ruleParameter
            {

            					newCompositeNode(grammarAccess.getCallAccess().getParamParameterParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_2);
            lv_param_3_0=ruleParameter();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getCallRule());
            					}
            					set(
            						current,
            						"param",
            						lv_param_3_0,
            						"org.xtext.example.mydsl.MyDsl.Parameter");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCall"


    // $ANTLR start "entryRuleFunction"
    // InternalMyDsl.g:964:1: entryRuleFunction returns [EObject current=null] : iv_ruleFunction= ruleFunction EOF ;
    public final EObject entryRuleFunction() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleFunction = null;


        try {
            // InternalMyDsl.g:964:49: (iv_ruleFunction= ruleFunction EOF )
            // InternalMyDsl.g:965:2: iv_ruleFunction= ruleFunction EOF
            {
             newCompositeNode(grammarAccess.getFunctionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleFunction=ruleFunction();

            state._fsp--;

             current =iv_ruleFunction; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleFunction"


    // $ANTLR start "ruleFunction"
    // InternalMyDsl.g:971:1: ruleFunction returns [EObject current=null] : (otherlv_0= 'function' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'parameters' ( (lv_params_3_0= ruleParameter ) )+ otherlv_4= '{' ( (lv_instr_5_0= ruleInstruction ) )+ otherlv_6= '}' ) ;
    public final EObject ruleFunction() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        AntlrDatatypeRuleToken lv_params_3_0 = null;

        EObject lv_instr_5_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:977:2: ( (otherlv_0= 'function' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'parameters' ( (lv_params_3_0= ruleParameter ) )+ otherlv_4= '{' ( (lv_instr_5_0= ruleInstruction ) )+ otherlv_6= '}' ) )
            // InternalMyDsl.g:978:2: (otherlv_0= 'function' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'parameters' ( (lv_params_3_0= ruleParameter ) )+ otherlv_4= '{' ( (lv_instr_5_0= ruleInstruction ) )+ otherlv_6= '}' )
            {
            // InternalMyDsl.g:978:2: (otherlv_0= 'function' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'parameters' ( (lv_params_3_0= ruleParameter ) )+ otherlv_4= '{' ( (lv_instr_5_0= ruleInstruction ) )+ otherlv_6= '}' )
            // InternalMyDsl.g:979:3: otherlv_0= 'function' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= 'parameters' ( (lv_params_3_0= ruleParameter ) )+ otherlv_4= '{' ( (lv_instr_5_0= ruleInstruction ) )+ otherlv_6= '}'
            {
            otherlv_0=(Token)match(input,27,FOLLOW_13); 

            			newLeafNode(otherlv_0, grammarAccess.getFunctionAccess().getFunctionKeyword_0());
            		
            // InternalMyDsl.g:983:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalMyDsl.g:984:4: (lv_name_1_0= RULE_ID )
            {
            // InternalMyDsl.g:984:4: (lv_name_1_0= RULE_ID )
            // InternalMyDsl.g:985:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_16); 

            					newLeafNode(lv_name_1_0, grammarAccess.getFunctionAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getFunctionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_2=(Token)match(input,26,FOLLOW_17); 

            			newLeafNode(otherlv_2, grammarAccess.getFunctionAccess().getParametersKeyword_2());
            		
            // InternalMyDsl.g:1005:3: ( (lv_params_3_0= ruleParameter ) )+
            int cnt6=0;
            loop6:
            do {
                int alt6=2;
                int LA6_0 = input.LA(1);

                if ( ((LA6_0>=RULE_STRING && LA6_0<=RULE_ID)) ) {
                    alt6=1;
                }


                switch (alt6) {
            	case 1 :
            	    // InternalMyDsl.g:1006:4: (lv_params_3_0= ruleParameter )
            	    {
            	    // InternalMyDsl.g:1006:4: (lv_params_3_0= ruleParameter )
            	    // InternalMyDsl.g:1007:5: lv_params_3_0= ruleParameter
            	    {

            	    					newCompositeNode(grammarAccess.getFunctionAccess().getParamsParameterParserRuleCall_3_0());
            	    				
            	    pushFollow(FOLLOW_18);
            	    lv_params_3_0=ruleParameter();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getFunctionRule());
            	    					}
            	    					add(
            	    						current,
            	    						"params",
            	    						lv_params_3_0,
            	    						"org.xtext.example.mydsl.MyDsl.Parameter");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt6 >= 1 ) break loop6;
                        EarlyExitException eee =
                            new EarlyExitException(6, input);
                        throw eee;
                }
                cnt6++;
            } while (true);

            otherlv_4=(Token)match(input,28,FOLLOW_19); 

            			newLeafNode(otherlv_4, grammarAccess.getFunctionAccess().getLeftCurlyBracketKeyword_4());
            		
            // InternalMyDsl.g:1028:3: ( (lv_instr_5_0= ruleInstruction ) )+
            int cnt7=0;
            loop7:
            do {
                int alt7=2;
                int LA7_0 = input.LA(1);

                if ( ((LA7_0>=11 && LA7_0<=17)||(LA7_0>=19 && LA7_0<=21)||LA7_0==23||LA7_0==25||LA7_0==27) ) {
                    alt7=1;
                }


                switch (alt7) {
            	case 1 :
            	    // InternalMyDsl.g:1029:4: (lv_instr_5_0= ruleInstruction )
            	    {
            	    // InternalMyDsl.g:1029:4: (lv_instr_5_0= ruleInstruction )
            	    // InternalMyDsl.g:1030:5: lv_instr_5_0= ruleInstruction
            	    {

            	    					newCompositeNode(grammarAccess.getFunctionAccess().getInstrInstructionParserRuleCall_5_0());
            	    				
            	    pushFollow(FOLLOW_19);
            	    lv_instr_5_0=ruleInstruction();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getFunctionRule());
            	    					}
            	    					add(
            	    						current,
            	    						"instr",
            	    						lv_instr_5_0,
            	    						"org.xtext.example.mydsl.MyDsl.Instruction");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt7 >= 1 ) break loop7;
                        EarlyExitException eee =
                            new EarlyExitException(7, input);
                        throw eee;
                }
                cnt7++;
            } while (true);

            otherlv_6=(Token)match(input,29,FOLLOW_2); 

            			newLeafNode(otherlv_6, grammarAccess.getFunctionAccess().getRightCurlyBracketKeyword_6());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleFunction"


    // $ANTLR start "entryRuleName"
    // InternalMyDsl.g:1055:1: entryRuleName returns [EObject current=null] : iv_ruleName= ruleName EOF ;
    public final EObject entryRuleName() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleName = null;


        try {
            // InternalMyDsl.g:1055:45: (iv_ruleName= ruleName EOF )
            // InternalMyDsl.g:1056:2: iv_ruleName= ruleName EOF
            {
             newCompositeNode(grammarAccess.getNameRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleName=ruleName();

            state._fsp--;

             current =iv_ruleName; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleName"


    // $ANTLR start "ruleName"
    // InternalMyDsl.g:1062:1: ruleName returns [EObject current=null] : (otherlv_0= 'name' ( ( (lv_name_1_1= RULE_STRING | lv_name_1_2= RULE_ID ) ) ) ) ;
    public final EObject ruleName() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_1=null;
        Token lv_name_1_2=null;


        	enterRule();

        try {
            // InternalMyDsl.g:1068:2: ( (otherlv_0= 'name' ( ( (lv_name_1_1= RULE_STRING | lv_name_1_2= RULE_ID ) ) ) ) )
            // InternalMyDsl.g:1069:2: (otherlv_0= 'name' ( ( (lv_name_1_1= RULE_STRING | lv_name_1_2= RULE_ID ) ) ) )
            {
            // InternalMyDsl.g:1069:2: (otherlv_0= 'name' ( ( (lv_name_1_1= RULE_STRING | lv_name_1_2= RULE_ID ) ) ) )
            // InternalMyDsl.g:1070:3: otherlv_0= 'name' ( ( (lv_name_1_1= RULE_STRING | lv_name_1_2= RULE_ID ) ) )
            {
            otherlv_0=(Token)match(input,30,FOLLOW_17); 

            			newLeafNode(otherlv_0, grammarAccess.getNameAccess().getNameKeyword_0());
            		
            // InternalMyDsl.g:1074:3: ( ( (lv_name_1_1= RULE_STRING | lv_name_1_2= RULE_ID ) ) )
            // InternalMyDsl.g:1075:4: ( (lv_name_1_1= RULE_STRING | lv_name_1_2= RULE_ID ) )
            {
            // InternalMyDsl.g:1075:4: ( (lv_name_1_1= RULE_STRING | lv_name_1_2= RULE_ID ) )
            // InternalMyDsl.g:1076:5: (lv_name_1_1= RULE_STRING | lv_name_1_2= RULE_ID )
            {
            // InternalMyDsl.g:1076:5: (lv_name_1_1= RULE_STRING | lv_name_1_2= RULE_ID )
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==RULE_STRING) ) {
                alt8=1;
            }
            else if ( (LA8_0==RULE_ID) ) {
                alt8=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 8, 0, input);

                throw nvae;
            }
            switch (alt8) {
                case 1 :
                    // InternalMyDsl.g:1077:6: lv_name_1_1= RULE_STRING
                    {
                    lv_name_1_1=(Token)match(input,RULE_STRING,FOLLOW_2); 

                    						newLeafNode(lv_name_1_1, grammarAccess.getNameAccess().getNameSTRINGTerminalRuleCall_1_0_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getNameRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"name",
                    							lv_name_1_1,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:1092:6: lv_name_1_2= RULE_ID
                    {
                    lv_name_1_2=(Token)match(input,RULE_ID,FOLLOW_2); 

                    						newLeafNode(lv_name_1_2, grammarAccess.getNameAccess().getNameIDTerminalRuleCall_1_0_1());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getNameRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"name",
                    							lv_name_1_2,
                    							"org.eclipse.xtext.common.Terminals.ID");
                    					

                    }
                    break;

            }


            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleName"


    // $ANTLR start "entryRuleValue"
    // InternalMyDsl.g:1113:1: entryRuleValue returns [EObject current=null] : iv_ruleValue= ruleValue EOF ;
    public final EObject entryRuleValue() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleValue = null;


        try {
            // InternalMyDsl.g:1113:46: (iv_ruleValue= ruleValue EOF )
            // InternalMyDsl.g:1114:2: iv_ruleValue= ruleValue EOF
            {
             newCompositeNode(grammarAccess.getValueRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleValue=ruleValue();

            state._fsp--;

             current =iv_ruleValue; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleValue"


    // $ANTLR start "ruleValue"
    // InternalMyDsl.g:1120:1: ruleValue returns [EObject current=null] : (otherlv_0= 'value' ( ( (lv_string_1_0= RULE_STRING ) ) | ( (lv_id_2_0= RULE_ID ) ) ) ) ;
    public final EObject ruleValue() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_string_1_0=null;
        Token lv_id_2_0=null;


        	enterRule();

        try {
            // InternalMyDsl.g:1126:2: ( (otherlv_0= 'value' ( ( (lv_string_1_0= RULE_STRING ) ) | ( (lv_id_2_0= RULE_ID ) ) ) ) )
            // InternalMyDsl.g:1127:2: (otherlv_0= 'value' ( ( (lv_string_1_0= RULE_STRING ) ) | ( (lv_id_2_0= RULE_ID ) ) ) )
            {
            // InternalMyDsl.g:1127:2: (otherlv_0= 'value' ( ( (lv_string_1_0= RULE_STRING ) ) | ( (lv_id_2_0= RULE_ID ) ) ) )
            // InternalMyDsl.g:1128:3: otherlv_0= 'value' ( ( (lv_string_1_0= RULE_STRING ) ) | ( (lv_id_2_0= RULE_ID ) ) )
            {
            otherlv_0=(Token)match(input,31,FOLLOW_17); 

            			newLeafNode(otherlv_0, grammarAccess.getValueAccess().getValueKeyword_0());
            		
            // InternalMyDsl.g:1132:3: ( ( (lv_string_1_0= RULE_STRING ) ) | ( (lv_id_2_0= RULE_ID ) ) )
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==RULE_STRING) ) {
                alt9=1;
            }
            else if ( (LA9_0==RULE_ID) ) {
                alt9=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 9, 0, input);

                throw nvae;
            }
            switch (alt9) {
                case 1 :
                    // InternalMyDsl.g:1133:4: ( (lv_string_1_0= RULE_STRING ) )
                    {
                    // InternalMyDsl.g:1133:4: ( (lv_string_1_0= RULE_STRING ) )
                    // InternalMyDsl.g:1134:5: (lv_string_1_0= RULE_STRING )
                    {
                    // InternalMyDsl.g:1134:5: (lv_string_1_0= RULE_STRING )
                    // InternalMyDsl.g:1135:6: lv_string_1_0= RULE_STRING
                    {
                    lv_string_1_0=(Token)match(input,RULE_STRING,FOLLOW_2); 

                    						newLeafNode(lv_string_1_0, grammarAccess.getValueAccess().getStringSTRINGTerminalRuleCall_1_0_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getValueRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"string",
                    							lv_string_1_0,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:1152:4: ( (lv_id_2_0= RULE_ID ) )
                    {
                    // InternalMyDsl.g:1152:4: ( (lv_id_2_0= RULE_ID ) )
                    // InternalMyDsl.g:1153:5: (lv_id_2_0= RULE_ID )
                    {
                    // InternalMyDsl.g:1153:5: (lv_id_2_0= RULE_ID )
                    // InternalMyDsl.g:1154:6: lv_id_2_0= RULE_ID
                    {
                    lv_id_2_0=(Token)match(input,RULE_ID,FOLLOW_2); 

                    						newLeafNode(lv_id_2_0, grammarAccess.getValueAccess().getIdIDTerminalRuleCall_1_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getValueRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"id",
                    							lv_id_2_0,
                    							"org.eclipse.xtext.common.Terminals.ID");
                    					

                    }


                    }


                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleValue"


    // $ANTLR start "entryRuleParameter"
    // InternalMyDsl.g:1175:1: entryRuleParameter returns [String current=null] : iv_ruleParameter= ruleParameter EOF ;
    public final String entryRuleParameter() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleParameter = null;


        try {
            // InternalMyDsl.g:1175:49: (iv_ruleParameter= ruleParameter EOF )
            // InternalMyDsl.g:1176:2: iv_ruleParameter= ruleParameter EOF
            {
             newCompositeNode(grammarAccess.getParameterRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleParameter=ruleParameter();

            state._fsp--;

             current =iv_ruleParameter.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleParameter"


    // $ANTLR start "ruleParameter"
    // InternalMyDsl.g:1182:1: ruleParameter returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID ) ;
    public final AntlrDatatypeRuleToken ruleParameter() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_STRING_0=null;
        Token this_ID_1=null;


        	enterRule();

        try {
            // InternalMyDsl.g:1188:2: ( (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID ) )
            // InternalMyDsl.g:1189:2: (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID )
            {
            // InternalMyDsl.g:1189:2: (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID )
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( (LA10_0==RULE_STRING) ) {
                alt10=1;
            }
            else if ( (LA10_0==RULE_ID) ) {
                alt10=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 10, 0, input);

                throw nvae;
            }
            switch (alt10) {
                case 1 :
                    // InternalMyDsl.g:1190:3: this_STRING_0= RULE_STRING
                    {
                    this_STRING_0=(Token)match(input,RULE_STRING,FOLLOW_2); 

                    			current.merge(this_STRING_0);
                    		

                    			newLeafNode(this_STRING_0, grammarAccess.getParameterAccess().getSTRINGTerminalRuleCall_0());
                    		

                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:1198:3: this_ID_1= RULE_ID
                    {
                    this_ID_1=(Token)match(input,RULE_ID,FOLLOW_2); 

                    			current.merge(this_ID_1);
                    		

                    			newLeafNode(this_ID_1, grammarAccess.getParameterAccess().getIDTerminalRuleCall_1());
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleParameter"


    // $ANTLR start "entryRuleTypeElement"
    // InternalMyDsl.g:1209:1: entryRuleTypeElement returns [String current=null] : iv_ruleTypeElement= ruleTypeElement EOF ;
    public final String entryRuleTypeElement() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleTypeElement = null;


        try {
            // InternalMyDsl.g:1209:51: (iv_ruleTypeElement= ruleTypeElement EOF )
            // InternalMyDsl.g:1210:2: iv_ruleTypeElement= ruleTypeElement EOF
            {
             newCompositeNode(grammarAccess.getTypeElementRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTypeElement=ruleTypeElement();

            state._fsp--;

             current =iv_ruleTypeElement.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTypeElement"


    // $ANTLR start "ruleTypeElement"
    // InternalMyDsl.g:1216:1: ruleTypeElement returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_TypeLink_0= ruleTypeLink | this_TypeImage_1= ruleTypeImage | this_TypeText_2= ruleTypeText | this_TypeButton_3= ruleTypeButton | this_TypeTitle_4= ruleTypeTitle ) ;
    public final AntlrDatatypeRuleToken ruleTypeElement() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        AntlrDatatypeRuleToken this_TypeLink_0 = null;

        AntlrDatatypeRuleToken this_TypeImage_1 = null;

        AntlrDatatypeRuleToken this_TypeText_2 = null;

        AntlrDatatypeRuleToken this_TypeButton_3 = null;

        AntlrDatatypeRuleToken this_TypeTitle_4 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:1222:2: ( (this_TypeLink_0= ruleTypeLink | this_TypeImage_1= ruleTypeImage | this_TypeText_2= ruleTypeText | this_TypeButton_3= ruleTypeButton | this_TypeTitle_4= ruleTypeTitle ) )
            // InternalMyDsl.g:1223:2: (this_TypeLink_0= ruleTypeLink | this_TypeImage_1= ruleTypeImage | this_TypeText_2= ruleTypeText | this_TypeButton_3= ruleTypeButton | this_TypeTitle_4= ruleTypeTitle )
            {
            // InternalMyDsl.g:1223:2: (this_TypeLink_0= ruleTypeLink | this_TypeImage_1= ruleTypeImage | this_TypeText_2= ruleTypeText | this_TypeButton_3= ruleTypeButton | this_TypeTitle_4= ruleTypeTitle )
            int alt11=5;
            switch ( input.LA(1) ) {
            case 32:
                {
                alt11=1;
                }
                break;
            case 33:
                {
                alt11=2;
                }
                break;
            case 34:
                {
                alt11=3;
                }
                break;
            case 35:
                {
                alt11=4;
                }
                break;
            case 38:
                {
                alt11=5;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 11, 0, input);

                throw nvae;
            }

            switch (alt11) {
                case 1 :
                    // InternalMyDsl.g:1224:3: this_TypeLink_0= ruleTypeLink
                    {

                    			newCompositeNode(grammarAccess.getTypeElementAccess().getTypeLinkParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_TypeLink_0=ruleTypeLink();

                    state._fsp--;


                    			current.merge(this_TypeLink_0);
                    		

                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:1235:3: this_TypeImage_1= ruleTypeImage
                    {

                    			newCompositeNode(grammarAccess.getTypeElementAccess().getTypeImageParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_TypeImage_1=ruleTypeImage();

                    state._fsp--;


                    			current.merge(this_TypeImage_1);
                    		

                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalMyDsl.g:1246:3: this_TypeText_2= ruleTypeText
                    {

                    			newCompositeNode(grammarAccess.getTypeElementAccess().getTypeTextParserRuleCall_2());
                    		
                    pushFollow(FOLLOW_2);
                    this_TypeText_2=ruleTypeText();

                    state._fsp--;


                    			current.merge(this_TypeText_2);
                    		

                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 4 :
                    // InternalMyDsl.g:1257:3: this_TypeButton_3= ruleTypeButton
                    {

                    			newCompositeNode(grammarAccess.getTypeElementAccess().getTypeButtonParserRuleCall_3());
                    		
                    pushFollow(FOLLOW_2);
                    this_TypeButton_3=ruleTypeButton();

                    state._fsp--;


                    			current.merge(this_TypeButton_3);
                    		

                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 5 :
                    // InternalMyDsl.g:1268:3: this_TypeTitle_4= ruleTypeTitle
                    {

                    			newCompositeNode(grammarAccess.getTypeElementAccess().getTypeTitleParserRuleCall_4());
                    		
                    pushFollow(FOLLOW_2);
                    this_TypeTitle_4=ruleTypeTitle();

                    state._fsp--;


                    			current.merge(this_TypeTitle_4);
                    		

                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTypeElement"


    // $ANTLR start "entryRuleTypeProperty"
    // InternalMyDsl.g:1282:1: entryRuleTypeProperty returns [String current=null] : iv_ruleTypeProperty= ruleTypeProperty EOF ;
    public final String entryRuleTypeProperty() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleTypeProperty = null;


        try {
            // InternalMyDsl.g:1282:52: (iv_ruleTypeProperty= ruleTypeProperty EOF )
            // InternalMyDsl.g:1283:2: iv_ruleTypeProperty= ruleTypeProperty EOF
            {
             newCompositeNode(grammarAccess.getTypePropertyRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTypeProperty=ruleTypeProperty();

            state._fsp--;

             current =iv_ruleTypeProperty.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTypeProperty"


    // $ANTLR start "ruleTypeProperty"
    // InternalMyDsl.g:1289:1: ruleTypeProperty returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_TypeUrl_0= ruleTypeUrl | this_TypeText_1= ruleTypeText ) ;
    public final AntlrDatatypeRuleToken ruleTypeProperty() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        AntlrDatatypeRuleToken this_TypeUrl_0 = null;

        AntlrDatatypeRuleToken this_TypeText_1 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:1295:2: ( (this_TypeUrl_0= ruleTypeUrl | this_TypeText_1= ruleTypeText ) )
            // InternalMyDsl.g:1296:2: (this_TypeUrl_0= ruleTypeUrl | this_TypeText_1= ruleTypeText )
            {
            // InternalMyDsl.g:1296:2: (this_TypeUrl_0= ruleTypeUrl | this_TypeText_1= ruleTypeText )
            int alt12=2;
            int LA12_0 = input.LA(1);

            if ( (LA12_0==39) ) {
                alt12=1;
            }
            else if ( (LA12_0==34) ) {
                alt12=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 12, 0, input);

                throw nvae;
            }
            switch (alt12) {
                case 1 :
                    // InternalMyDsl.g:1297:3: this_TypeUrl_0= ruleTypeUrl
                    {

                    			newCompositeNode(grammarAccess.getTypePropertyAccess().getTypeUrlParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_TypeUrl_0=ruleTypeUrl();

                    state._fsp--;


                    			current.merge(this_TypeUrl_0);
                    		

                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:1308:3: this_TypeText_1= ruleTypeText
                    {

                    			newCompositeNode(grammarAccess.getTypePropertyAccess().getTypeTextParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_TypeText_1=ruleTypeText();

                    state._fsp--;


                    			current.merge(this_TypeText_1);
                    		

                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTypeProperty"


    // $ANTLR start "entryRuleTypeLink"
    // InternalMyDsl.g:1322:1: entryRuleTypeLink returns [String current=null] : iv_ruleTypeLink= ruleTypeLink EOF ;
    public final String entryRuleTypeLink() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleTypeLink = null;


        try {
            // InternalMyDsl.g:1322:48: (iv_ruleTypeLink= ruleTypeLink EOF )
            // InternalMyDsl.g:1323:2: iv_ruleTypeLink= ruleTypeLink EOF
            {
             newCompositeNode(grammarAccess.getTypeLinkRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTypeLink=ruleTypeLink();

            state._fsp--;

             current =iv_ruleTypeLink.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTypeLink"


    // $ANTLR start "ruleTypeLink"
    // InternalMyDsl.g:1329:1: ruleTypeLink returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : kw= 'link' ;
    public final AntlrDatatypeRuleToken ruleTypeLink() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalMyDsl.g:1335:2: (kw= 'link' )
            // InternalMyDsl.g:1336:2: kw= 'link'
            {
            kw=(Token)match(input,32,FOLLOW_2); 

            		current.merge(kw);
            		newLeafNode(kw, grammarAccess.getTypeLinkAccess().getLinkKeyword());
            	

            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTypeLink"


    // $ANTLR start "entryRuleTypeImage"
    // InternalMyDsl.g:1344:1: entryRuleTypeImage returns [String current=null] : iv_ruleTypeImage= ruleTypeImage EOF ;
    public final String entryRuleTypeImage() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleTypeImage = null;


        try {
            // InternalMyDsl.g:1344:49: (iv_ruleTypeImage= ruleTypeImage EOF )
            // InternalMyDsl.g:1345:2: iv_ruleTypeImage= ruleTypeImage EOF
            {
             newCompositeNode(grammarAccess.getTypeImageRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTypeImage=ruleTypeImage();

            state._fsp--;

             current =iv_ruleTypeImage.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTypeImage"


    // $ANTLR start "ruleTypeImage"
    // InternalMyDsl.g:1351:1: ruleTypeImage returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : kw= 'image' ;
    public final AntlrDatatypeRuleToken ruleTypeImage() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalMyDsl.g:1357:2: (kw= 'image' )
            // InternalMyDsl.g:1358:2: kw= 'image'
            {
            kw=(Token)match(input,33,FOLLOW_2); 

            		current.merge(kw);
            		newLeafNode(kw, grammarAccess.getTypeImageAccess().getImageKeyword());
            	

            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTypeImage"


    // $ANTLR start "entryRuleTypeText"
    // InternalMyDsl.g:1366:1: entryRuleTypeText returns [String current=null] : iv_ruleTypeText= ruleTypeText EOF ;
    public final String entryRuleTypeText() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleTypeText = null;


        try {
            // InternalMyDsl.g:1366:48: (iv_ruleTypeText= ruleTypeText EOF )
            // InternalMyDsl.g:1367:2: iv_ruleTypeText= ruleTypeText EOF
            {
             newCompositeNode(grammarAccess.getTypeTextRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTypeText=ruleTypeText();

            state._fsp--;

             current =iv_ruleTypeText.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTypeText"


    // $ANTLR start "ruleTypeText"
    // InternalMyDsl.g:1373:1: ruleTypeText returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : kw= 'text' ;
    public final AntlrDatatypeRuleToken ruleTypeText() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalMyDsl.g:1379:2: (kw= 'text' )
            // InternalMyDsl.g:1380:2: kw= 'text'
            {
            kw=(Token)match(input,34,FOLLOW_2); 

            		current.merge(kw);
            		newLeafNode(kw, grammarAccess.getTypeTextAccess().getTextKeyword());
            	

            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTypeText"


    // $ANTLR start "entryRuleTypeButton"
    // InternalMyDsl.g:1388:1: entryRuleTypeButton returns [String current=null] : iv_ruleTypeButton= ruleTypeButton EOF ;
    public final String entryRuleTypeButton() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleTypeButton = null;


        try {
            // InternalMyDsl.g:1388:50: (iv_ruleTypeButton= ruleTypeButton EOF )
            // InternalMyDsl.g:1389:2: iv_ruleTypeButton= ruleTypeButton EOF
            {
             newCompositeNode(grammarAccess.getTypeButtonRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTypeButton=ruleTypeButton();

            state._fsp--;

             current =iv_ruleTypeButton.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTypeButton"


    // $ANTLR start "ruleTypeButton"
    // InternalMyDsl.g:1395:1: ruleTypeButton returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : kw= 'button' ;
    public final AntlrDatatypeRuleToken ruleTypeButton() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalMyDsl.g:1401:2: (kw= 'button' )
            // InternalMyDsl.g:1402:2: kw= 'button'
            {
            kw=(Token)match(input,35,FOLLOW_2); 

            		current.merge(kw);
            		newLeafNode(kw, grammarAccess.getTypeButtonAccess().getButtonKeyword());
            	

            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTypeButton"


    // $ANTLR start "entryRuleTypeInput"
    // InternalMyDsl.g:1410:1: entryRuleTypeInput returns [String current=null] : iv_ruleTypeInput= ruleTypeInput EOF ;
    public final String entryRuleTypeInput() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleTypeInput = null;


        try {
            // InternalMyDsl.g:1410:49: (iv_ruleTypeInput= ruleTypeInput EOF )
            // InternalMyDsl.g:1411:2: iv_ruleTypeInput= ruleTypeInput EOF
            {
             newCompositeNode(grammarAccess.getTypeInputRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTypeInput=ruleTypeInput();

            state._fsp--;

             current =iv_ruleTypeInput.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTypeInput"


    // $ANTLR start "ruleTypeInput"
    // InternalMyDsl.g:1417:1: ruleTypeInput returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : kw= 'input' ;
    public final AntlrDatatypeRuleToken ruleTypeInput() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalMyDsl.g:1423:2: (kw= 'input' )
            // InternalMyDsl.g:1424:2: kw= 'input'
            {
            kw=(Token)match(input,36,FOLLOW_2); 

            		current.merge(kw);
            		newLeafNode(kw, grammarAccess.getTypeInputAccess().getInputKeyword());
            	

            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTypeInput"


    // $ANTLR start "entryRuleTypeCombo"
    // InternalMyDsl.g:1432:1: entryRuleTypeCombo returns [String current=null] : iv_ruleTypeCombo= ruleTypeCombo EOF ;
    public final String entryRuleTypeCombo() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleTypeCombo = null;


        try {
            // InternalMyDsl.g:1432:49: (iv_ruleTypeCombo= ruleTypeCombo EOF )
            // InternalMyDsl.g:1433:2: iv_ruleTypeCombo= ruleTypeCombo EOF
            {
             newCompositeNode(grammarAccess.getTypeComboRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTypeCombo=ruleTypeCombo();

            state._fsp--;

             current =iv_ruleTypeCombo.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTypeCombo"


    // $ANTLR start "ruleTypeCombo"
    // InternalMyDsl.g:1439:1: ruleTypeCombo returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : kw= 'combobox' ;
    public final AntlrDatatypeRuleToken ruleTypeCombo() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalMyDsl.g:1445:2: (kw= 'combobox' )
            // InternalMyDsl.g:1446:2: kw= 'combobox'
            {
            kw=(Token)match(input,37,FOLLOW_2); 

            		current.merge(kw);
            		newLeafNode(kw, grammarAccess.getTypeComboAccess().getComboboxKeyword());
            	

            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTypeCombo"


    // $ANTLR start "entryRuleTypeTitle"
    // InternalMyDsl.g:1454:1: entryRuleTypeTitle returns [String current=null] : iv_ruleTypeTitle= ruleTypeTitle EOF ;
    public final String entryRuleTypeTitle() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleTypeTitle = null;


        try {
            // InternalMyDsl.g:1454:49: (iv_ruleTypeTitle= ruleTypeTitle EOF )
            // InternalMyDsl.g:1455:2: iv_ruleTypeTitle= ruleTypeTitle EOF
            {
             newCompositeNode(grammarAccess.getTypeTitleRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTypeTitle=ruleTypeTitle();

            state._fsp--;

             current =iv_ruleTypeTitle.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTypeTitle"


    // $ANTLR start "ruleTypeTitle"
    // InternalMyDsl.g:1461:1: ruleTypeTitle returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : kw= 'title' ;
    public final AntlrDatatypeRuleToken ruleTypeTitle() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalMyDsl.g:1467:2: (kw= 'title' )
            // InternalMyDsl.g:1468:2: kw= 'title'
            {
            kw=(Token)match(input,38,FOLLOW_2); 

            		current.merge(kw);
            		newLeafNode(kw, grammarAccess.getTypeTitleAccess().getTitleKeyword());
            	

            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTypeTitle"


    // $ANTLR start "entryRuleTypeUrl"
    // InternalMyDsl.g:1476:1: entryRuleTypeUrl returns [String current=null] : iv_ruleTypeUrl= ruleTypeUrl EOF ;
    public final String entryRuleTypeUrl() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleTypeUrl = null;


        try {
            // InternalMyDsl.g:1476:47: (iv_ruleTypeUrl= ruleTypeUrl EOF )
            // InternalMyDsl.g:1477:2: iv_ruleTypeUrl= ruleTypeUrl EOF
            {
             newCompositeNode(grammarAccess.getTypeUrlRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTypeUrl=ruleTypeUrl();

            state._fsp--;

             current =iv_ruleTypeUrl.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTypeUrl"


    // $ANTLR start "ruleTypeUrl"
    // InternalMyDsl.g:1483:1: ruleTypeUrl returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : kw= 'url' ;
    public final AntlrDatatypeRuleToken ruleTypeUrl() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalMyDsl.g:1489:2: (kw= 'url' )
            // InternalMyDsl.g:1490:2: kw= 'url'
            {
            kw=(Token)match(input,39,FOLLOW_2); 

            		current.merge(kw);
            		newLeafNode(kw, grammarAccess.getTypeUrlAccess().getUrlKeyword());
            	

            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTypeUrl"


    // $ANTLR start "entryRuleTypeCheckBox"
    // InternalMyDsl.g:1498:1: entryRuleTypeCheckBox returns [String current=null] : iv_ruleTypeCheckBox= ruleTypeCheckBox EOF ;
    public final String entryRuleTypeCheckBox() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleTypeCheckBox = null;


        try {
            // InternalMyDsl.g:1498:52: (iv_ruleTypeCheckBox= ruleTypeCheckBox EOF )
            // InternalMyDsl.g:1499:2: iv_ruleTypeCheckBox= ruleTypeCheckBox EOF
            {
             newCompositeNode(grammarAccess.getTypeCheckBoxRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTypeCheckBox=ruleTypeCheckBox();

            state._fsp--;

             current =iv_ruleTypeCheckBox.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTypeCheckBox"


    // $ANTLR start "ruleTypeCheckBox"
    // InternalMyDsl.g:1505:1: ruleTypeCheckBox returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : kw= 'checkbox' ;
    public final AntlrDatatypeRuleToken ruleTypeCheckBox() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalMyDsl.g:1511:2: (kw= 'checkbox' )
            // InternalMyDsl.g:1512:2: kw= 'checkbox'
            {
            kw=(Token)match(input,40,FOLLOW_2); 

            		current.merge(kw);
            		newLeafNode(kw, grammarAccess.getTypeCheckBoxAccess().getCheckboxKeyword());
            	

            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTypeCheckBox"


    // $ANTLR start "entryRuleTypeSet"
    // InternalMyDsl.g:1520:1: entryRuleTypeSet returns [String current=null] : iv_ruleTypeSet= ruleTypeSet EOF ;
    public final String entryRuleTypeSet() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleTypeSet = null;


        try {
            // InternalMyDsl.g:1520:47: (iv_ruleTypeSet= ruleTypeSet EOF )
            // InternalMyDsl.g:1521:2: iv_ruleTypeSet= ruleTypeSet EOF
            {
             newCompositeNode(grammarAccess.getTypeSetRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTypeSet=ruleTypeSet();

            state._fsp--;

             current =iv_ruleTypeSet.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTypeSet"


    // $ANTLR start "ruleTypeSet"
    // InternalMyDsl.g:1527:1: ruleTypeSet returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_TypeInput_0= ruleTypeInput | this_TypeCombo_1= ruleTypeCombo ) ;
    public final AntlrDatatypeRuleToken ruleTypeSet() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        AntlrDatatypeRuleToken this_TypeInput_0 = null;

        AntlrDatatypeRuleToken this_TypeCombo_1 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:1533:2: ( (this_TypeInput_0= ruleTypeInput | this_TypeCombo_1= ruleTypeCombo ) )
            // InternalMyDsl.g:1534:2: (this_TypeInput_0= ruleTypeInput | this_TypeCombo_1= ruleTypeCombo )
            {
            // InternalMyDsl.g:1534:2: (this_TypeInput_0= ruleTypeInput | this_TypeCombo_1= ruleTypeCombo )
            int alt13=2;
            int LA13_0 = input.LA(1);

            if ( (LA13_0==36) ) {
                alt13=1;
            }
            else if ( (LA13_0==37) ) {
                alt13=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 13, 0, input);

                throw nvae;
            }
            switch (alt13) {
                case 1 :
                    // InternalMyDsl.g:1535:3: this_TypeInput_0= ruleTypeInput
                    {

                    			newCompositeNode(grammarAccess.getTypeSetAccess().getTypeInputParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_TypeInput_0=ruleTypeInput();

                    state._fsp--;


                    			current.merge(this_TypeInput_0);
                    		

                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:1546:3: this_TypeCombo_1= ruleTypeCombo
                    {

                    			newCompositeNode(grammarAccess.getTypeSetAccess().getTypeComboParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_TypeCombo_1=ruleTypeCombo();

                    state._fsp--;


                    			current.merge(this_TypeCombo_1);
                    		

                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTypeSet"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x000000000ABBF802L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000004F00000000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000040000000L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000003000000000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000080000000L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000010000000000L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000040040002L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000008400000000L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000001000000L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000000180000L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000004000000L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000000000030L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000010000030L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x000000002ABBF800L});

}